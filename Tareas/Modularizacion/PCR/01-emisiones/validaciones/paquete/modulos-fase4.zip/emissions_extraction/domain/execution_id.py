import re

ORIGIN_STEP_FUNCTION = "STEP_FUNCTION"
ORIGIN_GENERATED = "GENERADO_EN_EXTRACCION"
ORIGIN_REPLACED_INVALID = "GENERADO_POR_ID_INVALIDO"
TIMESTAMP_FORMAT = "%Y%m%dT%H%M%SZ"
SEPARATOR = "-"
SHORT_UNIQUE_LENGTH = 12
MAX_LENGTH = 80
VALID_ID = re.compile(rf"^[A-Za-z0-9_-]{{1,{MAX_LENGTH}}}$")


def build_execution_id(malla, periodo, now_utc, unique_hex):
    return SEPARATOR.join([
        str(malla).upper(),
        str(periodo),
        now_utc.strftime(TIMESTAMP_FORMAT),
        str(unique_hex)[:SHORT_UNIQUE_LENGTH].lower(),
    ])


def is_valid_execution_id(execution_id):
    return bool(VALID_ID.match(str(execution_id)))


def resolve_execution_id(argument, malla, periodo, now_utc, unique_hex_factory):
    received = (argument or "").strip()
    if received and is_valid_execution_id(received):
        return received, ORIGIN_STEP_FUNCTION
    origin = ORIGIN_REPLACED_INVALID if received else ORIGIN_GENERATED
    return build_execution_id(malla, periodo, now_utc, unique_hex_factory()), origin
