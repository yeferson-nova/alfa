import re
from datetime import datetime

DATE_TIME_FORMAT = "%Y-%m-%d %H:%M:%S"


def month_window(period):
    if not re.fullmatch(r"\d{6}", period):
        raise ValueError(f"periodo_negocio invalido: {period}")
    year, month = int(period[:4]), int(period[4:])
    start = datetime(year, month, 1)
    if month == 12:
        end = datetime(year + 1, 1, 1)
    else:
        end = datetime(year, month + 1, 1)
    return start.strftime(DATE_TIME_FORMAT), end.strftime(DATE_TIME_FORMAT)
