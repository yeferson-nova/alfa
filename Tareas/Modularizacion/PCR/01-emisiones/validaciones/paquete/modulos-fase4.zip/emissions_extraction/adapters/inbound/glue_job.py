ARG_JOB_NAME = "JOB_NAME"
ARG_ROUTES = "RUTAS_CONFIG_EXTRACCION"
ARG_EXECUTION_ID = "EJECUCION_ID"
ARG_JOB_RUN_ID = "JOB_RUN_ID"
ARG_PREFIX = "--"


def resolve_arguments(argv, get_resolved_options, required, optional):
    present = [name for name in optional if f"{ARG_PREFIX}{name}" in argv]
    return get_resolved_options(argv, list(required) + present)


class GlueJobEntry:
    def __init__(self, service, job):
        self._service = service
        self._job = job

    def handle(self, args):
        context = self._service.run(
            args[ARG_ROUTES],
            job_run_id=args.get(ARG_JOB_RUN_ID),
            ejecucion_id_argumento=args.get(ARG_EXECUTION_ID),
        )
        self._job.commit()
        return context
