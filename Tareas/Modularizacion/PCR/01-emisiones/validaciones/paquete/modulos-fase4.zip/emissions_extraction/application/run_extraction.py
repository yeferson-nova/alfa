import json
from copy import deepcopy
from functools import partial

from ..domain import concurrency_policy, configuration, execution, results
from ..domain import contract as c
from ..domain import log_contract as log
from ..domain.execution_id import resolve_execution_id
from ..domain.paths import configured_silver_base, derived_silver_base
from ..domain.execution_context import ExecutionContext
from ..domain.period import month_window
from . import events
from .parallel_runs import SEQUENTIAL, run_in_order, session_pool
from .spark_contexts import NO_CONTEXTS

CORE_CASE_NAME = c.CORE_CASE_NAME
FIRST_CASE = 0


class ExtractionService:
    def __init__(self, store, connections, phases, telemetry, clock, unique_ids, tracer, contexts=None):
        self._store = store
        self._connections = connections
        self._phases = phases
        self._telemetry = telemetry
        self._clock = clock
        self._unique_ids = unique_ids
        self._tracer = tracer
        self._contexts = contexts

    def load_active_configs(self, raw_routes):
        try:
            uris = json.loads(raw_routes)
        except json.JSONDecodeError as exc:
            raise ValueError("RUTAS_CONFIG_EXTRACCION debe ser una lista JSON") from exc
        configuration.validate_route_count(uris)
        configs = [configuration.normalize_config(self._store.read_json(uri), uri) for uri in uris]
        for config in configs:
            configuration.validate_config(config)
        configuration.validate_unique_cases(configs)
        return configs

    def run(self, raw_routes, job_run_id=None, ejecucion_id_argumento=None):
        with self._tracer.component() as component:
            with self._tracer.step(log.STEP_LOAD_CONFIG):
                configs = self.load_active_configs(raw_routes)
                check = execution.validate_execution(configs)
            identity, context = self._resolve_identity(configs, check, job_run_id, ejecucion_id_argumento)
            self._warn(configs, check)
            start, end = month_window(identity[c.KEY_PERIOD])
            with self._tracer.step(log.STEP_CONNECTION):
                jdbc = self._connections.jdbc_options(identity["connection_name"])
            self._telemetry.emit(events.extraction_started(identity, [cfg[c.KEY_CASE] for cfg in configs]))
            plan = concurrency_policy.execution_concurrency(configs)
            self._telemetry.emit(events.concurrency_applied(plan, configs))
            pool = session_pool(plan.oracle_sessions)
            core_results = self._extract_core(configs, jdbc, start, end, pool)
            tasks = [partial(self._extract_case, config, core_results, jdbc, start, end, pool) for config in configs]
            outcomes = run_in_order(tasks, len(configs) if plan.parallel_cases else SEQUENTIAL)
            summary = [case_summary for case_summary, _ in outcomes]
            extracted = list(core_results) + [result for _, branch in outcomes for result in branch]
            self._telemetry.emit(events.extraction_finished(identity, summary))
            component.update(results.totals(extracted))
            return context

    def _resolve_identity(self, configs, check, job_run_id, received_id):
        configuration_id = check.identity[c.KEY_EXECUTION_ID]
        execution_id, origin = resolve_execution_id(
            received_id, c.MALLA_CODE, check.identity[c.KEY_PERIOD],
            self._clock.now(), self._unique_ids.new_unique_hex,
        )
        self._telemetry.bind(**{
            log.FIELD_EXECUTION_ID: execution_id,
            log.FIELD_PERIOD: check.identity[c.KEY_PERIOD],
            log.FIELD_LOT: check.identity[c.KEY_LOT],
        })
        self._telemetry.emit(events.execution_id_resolved(execution_id, origin, configuration_id, received_id))
        identity = {**check.identity, c.KEY_EXECUTION_ID: execution_id}
        for config in configs:
            config[c.KEY_EXECUTION_ID] = execution_id
        context = ExecutionContext.from_identity(identity, job_run_id, received_id, origin, configuration_id)
        return identity, context

    def _extract_core(self, configs, jdbc, start, end, pool):
        carrier_source = configs[FIRST_CASE]
        carrier = deepcopy(carrier_source)
        carrier[c.KEY_CASE] = CORE_CASE_NAME
        with self._tracer.step(log.STEP_CORE, **{log.FIELD_CASE: CORE_CASE_NAME}) as step:
            core_results = self._phases.run(
                configuration.flatten_core_tables(carrier_source), carrier, configuration.table_map(carrier_source),
                jdbc, start, end, common=True, pool=pool,
            )
            step.update(results.totals(core_results))
        return core_results

    def _extract_case(self, config, core_results, jdbc, start, end, pool):
        case = config[c.KEY_CASE]
        with self._tracer.step(log.STEP_CASE, **{log.FIELD_CASE: case}) as step:
            contexts = self._contexts.for_case(config, jdbc, start, end) if self._contexts else NO_CONTEXTS
            try:
                branch_results = self._phases.run(
                    configuration.flatten_branch_tables(config), config, configuration.table_map(config),
                    jdbc, start, end, common=False, pool=pool, contexts=contexts,
                )
            finally:
                contexts.release()
            runtime = results.runtime_for(config, core_results, branch_results, self._clock.now_iso())
            runtime_uri = config[c.KEY_ROUTES][c.KEY_RUNTIME_ROUTE]
            with self._tracer.step(log.STEP_RUNTIME, **{log.FIELD_CASE: case}):
                self._store.write_json(runtime_uri, runtime)
            self._telemetry.emit(events.case_finished(runtime))
            skipped = results.skipped_tables(runtime)
            if skipped:
                self._telemetry.emit(events.incomplete_quality(case, skipped))
            step.update(results.totals(branch_results))
        return {
            "caso": case,
            "runtime": runtime_uri,
            "datasets": len(runtime["datasets_extraidos"]),
            "estado": results.EXTRACTION_SUCCESS,
        }, branch_results

    def _warn(self, configs, check):
        for warning in check.warnings:
            self._telemetry.emit(warning)
        for difference in check.core_differences:
            self._telemetry.emit(events.core_tables_differ(configs[FIRST_CASE][c.KEY_CASE], difference))
        for config in configs:
            if not configured_silver_base(config):
                self._telemetry.emit(events.silver_route_derived(config[c.KEY_CASE], derived_silver_base(config)))
            ignored = configuration.ignored_keys(config)
            if ignored:
                self._telemetry.emit(events.ignored_keys(config[c.KEY_CASE], ignored))
