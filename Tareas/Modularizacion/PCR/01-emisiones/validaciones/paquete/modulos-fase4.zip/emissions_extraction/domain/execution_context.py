from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class ExecutionContext:
    ejecucion_id: str
    periodo_negocio: str
    lote_cargue_id: int
    connection_name: str
    job_run_id: Optional[str] = None
    ejecucion_id_argumento: Optional[str] = None
    origen_id: Optional[str] = None
    id_ejecucion_configuracion: Optional[str] = None

    @classmethod
    def from_identity(cls, identity, job_run_id=None, ejecucion_id_argumento=None,
                      origen_id=None, id_ejecucion_configuracion=None):
        return cls(
            ejecucion_id=identity["id_ejecucion"],
            periodo_negocio=identity["periodo_negocio"],
            lote_cargue_id=identity["lote_cargue_id"],
            connection_name=identity["connection_name"],
            job_run_id=job_run_id,
            ejecucion_id_argumento=ejecucion_id_argumento,
            origen_id=origen_id,
            id_ejecucion_configuracion=id_ejecucion_configuracion,
        )
