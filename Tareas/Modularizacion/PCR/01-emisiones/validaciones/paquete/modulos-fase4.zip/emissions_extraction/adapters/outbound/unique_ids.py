import uuid


class UuidGenerator:
    def new_unique_hex(self):
        return uuid.uuid4().hex
