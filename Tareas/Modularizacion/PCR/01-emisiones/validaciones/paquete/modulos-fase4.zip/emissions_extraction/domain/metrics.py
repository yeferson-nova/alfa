from . import log_contract as log

NAMESPACE = "NIIF17/Extraccion"
AWS_KEY = "_aws"
UNIT_MILLISECONDS = "Milliseconds"
UNIT_COUNT = "Count"
METRIC_DURATION = "DuracionMs"
METRIC_ROWS_OUT = "FilasSalida"
METRIC_ERRORS = "Errores"
ERROR_INCREMENT = 1
MISSING_DIMENSION = "NO_DEFINIDO"
DIMENSION_KEYS = (log.FIELD_ENVIRONMENT, log.FIELD_MALLA, log.FIELD_STAGE, log.FIELD_STEP, log.FIELD_RESULT)


def dimensions_for(context, step, result):
    values = {**context, log.FIELD_STEP: step, log.FIELD_RESULT: result}
    return {key: str(values.get(key) or MISSING_DIMENSION) for key in DIMENSION_KEYS}


def emf_document(metrics, dimensions, timestamp_ms):
    return {
        log.FIELD_EVENT: log.EVENT_METRICS,
        AWS_KEY: {
            "Timestamp": timestamp_ms,
            "CloudWatchMetrics": [{
                "Namespace": NAMESPACE,
                "Dimensions": [list(dimensions)],
                "Metrics": [{"Name": name, "Unit": unit} for name, (_, unit) in metrics.items()],
            }],
        },
        **dimensions,
        **{name: value for name, (value, _) in metrics.items()},
    }


def step_metrics(duration_ms, rows_out=None):
    metrics = {METRIC_DURATION: (duration_ms, UNIT_MILLISECONDS)}
    if rows_out is not None:
        metrics[METRIC_ROWS_OUT] = (rows_out, UNIT_COUNT)
    return metrics


def error_metrics():
    return {METRIC_ERRORS: (ERROR_INCREMENT, UNIT_COUNT)}
