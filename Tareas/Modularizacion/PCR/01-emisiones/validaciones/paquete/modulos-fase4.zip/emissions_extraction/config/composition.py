import sys

from ..adapters.inbound.glue_job import ARG_JOB_NAME, ARG_JOB_RUN_ID, GlueJobEntry, resolve_arguments
from ..adapters.outbound.clock import UtcClock
from ..adapters.outbound.glue_connection import GlueConnectionResolver
from ..adapters.outbound.oracle_reader import SparkOracleReader
from ..adapters.outbound.parquet_writer import SparkParquetWriter
from ..adapters.outbound.s3_store import S3ObjectStore
from ..adapters.outbound.spark_operations import SparkDatasetOperations
from ..adapters.outbound.stdout_events import StdoutTelemetry
from ..adapters.outbound.unique_ids import UuidGenerator
from ..application.contract_telemetry import ContractTelemetry
from ..application.extract_table import TableExtractor
from ..application.run_extraction import ExtractionService
from ..application.run_phases import PhaseRunner
from ..application.spark_contexts import ContextLoader
from ..application.tracing import StepTracer
from ..domain import contract as c
from ..domain import log_contract as log
from . import settings

S3_SERVICE = "s3"
GLUE_SERVICE = "glue"
SECRETS_SERVICE = "secretsmanager"


def build_telemetry(sink, clock, job_name, job_run_id):
    return ContractTelemetry(sink, clock, {
        log.FIELD_COMPONENT: job_name,
        log.FIELD_ENVIRONMENT: log.environment_from_job_name(job_name),
        log.FIELD_REQUEST_ID: job_run_id,
        log.FIELD_MALLA: c.MALLA_CODE,
        log.FIELD_STAGE: log.STAGE_EXTRACTION,
    })


def build_service(spark, glue_context, s3_client, glue_client, secrets_client_factory, prepare,
                  clock=None, telemetry=None, job_name=None, job_run_id=None):
    clock = clock or UtcClock()
    telemetry = build_telemetry(telemetry or StdoutTelemetry(), clock, job_name, job_run_id)
    tracer = StepTracer(telemetry, clock, lambda: telemetry.context)
    store = S3ObjectStore(s3_client)
    reader = SparkOracleReader(spark, glue_context)
    operations = SparkDatasetOperations(spark)
    extractor = TableExtractor(
        store,
        reader,
        SparkParquetWriter(spark),
        prepare,
        clock,
        telemetry,
        settings,
        operations,
    )
    phases = PhaseRunner(extractor.extract, telemetry, clock, tracer)
    connections = GlueConnectionResolver(glue_client, secrets_client_factory)
    contexts = ContextLoader(reader, operations, telemetry, tracer, settings)
    return ExtractionService(store, connections, phases, telemetry, clock, UuidGenerator(), tracer, contexts)


def run_job(argv=None):
    import boto3
    from awsglue.context import GlueContext
    from awsglue.job import Job
    from awsglue.utils import getResolvedOptions
    from pyspark.context import SparkContext

    from ..transformations import prepare_for_bronze

    argv = sys.argv if argv is None else argv
    args = resolve_arguments(argv, getResolvedOptions, settings.REQUIRED_JOB_ARGS, settings.OPTIONAL_JOB_ARGS)
    spark_context = SparkContext.getOrCreate()
    glue_context = GlueContext(spark_context)
    spark = glue_context.spark_session
    job = Job(glue_context)
    job.init(args[ARG_JOB_NAME], args)
    region = settings.region()
    service = build_service(
        spark,
        glue_context,
        boto3.client(S3_SERVICE),
        boto3.client(GLUE_SERVICE),
        lambda: boto3.client(SECRETS_SERVICE, region_name=region),
        prepare_for_bronze,
        job_name=args[ARG_JOB_NAME],
        job_run_id=args.get(ARG_JOB_RUN_ID),
    )
    return GlueJobEntry(service, job).handle(args)
