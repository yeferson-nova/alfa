import json
import re

S3_URI_PATTERN = re.compile(r"^s3://([^/]+)/(.+)$")
JSON_CONTENT_TYPE = "application/json"
TEXT_ENCODING = "utf-8"
JSON_INDENT = 2
NOT_FOUND_CODES = frozenset({"404", "NoSuchKey", "NotFound"})


def parse_s3_uri(uri):
    match = S3_URI_PATTERN.match(str(uri))
    if not match:
        raise ValueError(f"URI S3 invalida: {uri}")
    return match.group(1), match.group(2)


class S3ObjectStore:
    def __init__(self, client):
        self._client = client

    def read_json(self, uri):
        bucket, key = parse_s3_uri(uri)
        body = self._client.get_object(Bucket=bucket, Key=key)["Body"].read()
        return json.loads(body.decode(TEXT_ENCODING))

    def write_json(self, uri, payload):
        bucket, key = parse_s3_uri(uri)
        self._client.put_object(
            Bucket=bucket,
            Key=key,
            Body=json.dumps(payload, ensure_ascii=False, indent=JSON_INDENT).encode(TEXT_ENCODING),
            ContentType=JSON_CONTENT_TYPE,
        )

    def exists(self, uri):
        bucket, key = parse_s3_uri(uri)
        try:
            self._client.head_object(Bucket=bucket, Key=key)
            return True
        except Exception as exc:
            code = str(getattr(exc, "response", {}).get("Error", {}).get("Code", ""))
            if code in NOT_FOUND_CODES:
                return False
            raise
