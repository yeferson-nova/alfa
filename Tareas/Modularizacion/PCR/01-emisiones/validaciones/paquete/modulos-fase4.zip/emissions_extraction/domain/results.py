from copy import deepcopy

from . import contract as c
from . import log_contract as log
from .configuration import flatten_branch_tables, flatten_core_tables
from .naming import table_relative
from .paths import data_uri, silver_destination

STATE_COMPLETE = c.STATE_COMPLETE
STATE_REUSED = c.STATE_REUSED
STATE_SKIPPED = c.STATE_SKIPPED
EXTRACTION_SUCCESS = c.EXTRACTION_SUCCESS
NO_EXCLUDED_ROWS = 0
NO_ROWS = 0


def reused_result(previous):
    previous["estado"] = STATE_REUSED
    previous["datos_nuevos"] = False
    return previous


def optional_table_result(table, config, destination, reason):
    return {
        "tabla_relativa": table_relative(table),
        "estado": STATE_SKIPPED,
        "ruta_dataset_origen": data_uri(destination),
        "ruta_dataset_destino": silver_destination(config, table),
        "lote_cargue_id_dataset": config["lote_cargue_id"],
        "datos_nuevos": False,
        "total_registros": NO_ROWS,
        "registros_excluidos_por_segmento": NO_EXCLUDED_ROWS,
        "segmentacion_horizontal": table.get("segmentacion_horizontal") or {},
        "motivo": reason,
    }


def completed_table_result(table, config, destination, common, row_count, count_rows, timings, finished_at):
    return {
        "tabla_relativa": table_relative(table),
        "estado": STATE_COMPLETE,
        "origen_compartido": bool(common),
        "ruta_dataset_origen": data_uri(destination),
        "ruta_dataset_destino": silver_destination(config, table),
        "lote_cargue_id_dataset": config["lote_cargue_id"],
        "datos_nuevos": True,
        "total_registros": row_count,
        "registros_excluidos_por_segmento": NO_EXCLUDED_ROWS,
        "segmentacion_horizontal": table.get("segmentacion_horizontal") or {},
        "fecha_inicio_conteo": timings["inicio_conteo"],
        "fecha_fin_conteo": timings["fin_conteo"],
        "fecha_inicio_escritura": timings["inicio_escritura"],
        "fecha_fin_escritura": timings["fin_escritura"],
        "nivel_persistencia": c.PERSISTENCE_NONE,
        "modo_conteo": c.COUNT_MODE_AFTER_WRITE if count_rows else c.COUNT_MODE_NONE,
        "origen_conteo": c.COUNT_SOURCE_PARQUET if count_rows else None,
        "fecha_fin": finished_at,
    }


def runtime_for(config, core_results, branch_results, finished_at):
    common = []
    for source in core_results:
        item = deepcopy(source)
        item["origen_compartido"] = True
        item["ruta_dataset_destino"] = silver_destination(config, {"tabla_relativa": item["tabla_relativa"]})
        common.append(item)
    datasets = common + branch_results
    expected = {table_relative(t) for t in flatten_core_tables(config) + flatten_branch_tables(config)}
    manifested = {str(d.get("tabla_relativa", "")).strip("/").lower() for d in datasets}
    missing = sorted(expected - manifested)
    if missing:
        raise ValueError(f"{config['nombre_caso']}: no se publica parametros_extraccion.json; faltan tablas: {missing}")
    quality = c.QUALITY_INCOMPLETE if any(d.get("estado") == STATE_SKIPPED for d in datasets) else c.QUALITY_COMPLETE
    return {
        "id_ejecucion": config["id_ejecucion"],
        "nombre_caso": config["nombre_caso"],
        "caso_uso": config["nombre_caso"],
        "periodo_negocio": config["periodo_negocio"],
        "lote_cargue_id": config["lote_cargue_id"],
        "estado_extraccion": EXTRACTION_SUCCESS,
        "calidad_fuentes": quality,
        "fecha_fin": finished_at,
        "configuracion": config[c.KEY_CONFIG_URI],
        "datasets_extraidos": datasets,
    }


def skipped_tables(runtime):
    return sorted(d["tabla_relativa"] for d in runtime["datasets_extraidos"] if d.get("estado") == STATE_SKIPPED)


def totals(table_results):
    states = [result.get("estado") for result in table_results]
    return {
        log.FIELD_RESULT: log.RESULT_PARTIAL if STATE_SKIPPED in states else log.RESULT_OK,
        log.FIELD_TABLES_COMPLETE: states.count(STATE_COMPLETE),
        log.FIELD_TABLES_REUSED: states.count(STATE_REUSED),
        log.FIELD_TABLES_SKIPPED: states.count(STATE_SKIPPED),
        log.FIELD_ROWS_OUT: sum(
            result.get("total_registros") or NO_ROWS for result in table_results if result.get("estado") == STATE_COMPLETE
        ),
    }


def table_outcome(result):
    return {
        log.FIELD_RESULT: log.RESULT_SKIPPED if result.get("estado") == STATE_SKIPPED else log.RESULT_OK,
        log.FIELD_STATE: result.get("estado"),
        log.FIELD_ROWS_OUT: result.get("total_registros"),
    }
