from . import contract as c


def table_phase(table):
    return int(table.get("fase", table.get("orden", c.DEFAULT_PHASE)))


def ordered_phases(tables):
    return sorted({table_phase(t) for t in tables})


def tables_in_phase(tables, phase):
    return [t for t in tables if table_phase(t) == phase]


def phase_mode(targets):
    return str(targets[0].get("modo_fase", c.DEFAULT_PHASE_MODE)).upper() if targets else c.DEFAULT_PHASE_MODE
