from pyspark import StorageLevel

from ...domain import contract as c

KEY_ALIAS_PREFIX = "_llave_"
SEMI_JOIN = "left_semi"


class SparkDatasetOperations:
    def __init__(self, spark):
        self._spark = spark

    def read_parquet(self, uri):
        return self._spark.read.parquet(uri)

    def semi_join(self, frame, parent, mappings):
        aliases = [f"{KEY_ALIAS_PREFIX}{index}" for index in range(len(mappings))]
        keys = parent.select(*[parent[source].alias(alias) for (source, _), alias in zip(mappings, aliases)]).distinct()
        condition = [frame[target] == keys[alias] for (_, target), alias in zip(mappings, aliases)]
        return frame.join(keys, condition, SEMI_JOIN)

    def distinct(self, frame):
        return frame.distinct()

    def persist(self, frame):
        return frame.persist(StorageLevel.MEMORY_AND_DISK)

    def unpersist(self, frame):
        frame.unpersist()

    def count(self, frame):
        return frame.count()

    def compare(self, expected, actual):
        aligned = actual.select(*expected.columns)
        return {
            c.FIELD_SQL_ROWS: expected.count(),
            c.FIELD_SPARK_ROWS: aligned.count(),
            c.FIELD_ONLY_SQL: expected.exceptAll(aligned).count(),
            c.FIELD_ONLY_SPARK: aligned.exceptAll(expected).count(),
        }
