from contextlib import contextmanager

from ..domain import error_taxonomy, metrics
from ..domain import log_contract as log
from . import events

MS_PER_SECOND = 1000
CLASSIFIED_MARK = "_niif_error_clasificado"


def no_context():
    return {}


class StepTracer:
    def __init__(self, telemetry, clock, context=no_context):
        self._telemetry = telemetry
        self._clock = clock
        self._context = context

    @contextmanager
    def component(self, **fields):
        with self._span(log.STEP_COMPONENT, fields, log.EVENT_COMPONENT_START, log.EVENT_COMPONENT_END) as outcome:
            yield outcome

    @contextmanager
    def step(self, name, **fields):
        with self._span(name, fields, log.EVENT_STEP_START, log.EVENT_STEP_END) as outcome:
            yield outcome

    @contextmanager
    def _span(self, name, fields, start_event, end_event):
        started = self._clock.monotonic()
        self._telemetry.emit(events.span(start_event, name, fields))
        outcome = {log.FIELD_RESULT: log.RESULT_OK}
        try:
            yield outcome
        except Exception as error:
            outcome[log.FIELD_RESULT] = log.RESULT_ERROR
            self._classify(name, fields, error)
            self._finish(end_event, name, fields, outcome, started)
            raise
        self._finish(end_event, name, fields, outcome, started)

    def _finish(self, end_event, name, fields, outcome, started):
        duration = self._elapsed_ms(started)
        self._telemetry.emit(events.span(end_event, name, {**fields, **outcome, log.FIELD_DURATION: duration}))
        if name in log.METRIC_STEPS:
            values = metrics.step_metrics(duration, outcome.get(log.FIELD_ROWS_OUT))
            self._emit_metrics(name, outcome[log.FIELD_RESULT], values)

    def _classify(self, name, fields, error):
        if getattr(error, CLASSIFIED_MARK, False):
            return
        self._telemetry.emit(events.error_classified(name, fields, error_taxonomy.error_fields(name, error)))
        self._emit_metrics(name, log.RESULT_ERROR, metrics.error_metrics())
        try:
            setattr(error, CLASSIFIED_MARK, True)
        except AttributeError:
            return

    def _emit_metrics(self, name, result, values):
        dimensions = metrics.dimensions_for(self._context(), name, result)
        self._telemetry.emit(metrics.emf_document(values, dimensions, self._timestamp_ms()))

    def _elapsed_ms(self, started):
        return int(round((self._clock.monotonic() - started) * MS_PER_SECOND))

    def _timestamp_ms(self):
        return int(self._clock.now().timestamp() * MS_PER_SECOND)
