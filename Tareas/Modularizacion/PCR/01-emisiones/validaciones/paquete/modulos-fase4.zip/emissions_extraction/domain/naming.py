from .contract import DEFAULT_SCHEMA_FOLDER

KEY_TABLE = "tabla"
KEY_RELATIVE = "tabla_relativa"
PATH_SEPARATOR = "/"


def table_name(table):
    value = table.get(KEY_TABLE) or str(table.get(KEY_RELATIVE, "")).strip(PATH_SEPARATOR).split(PATH_SEPARATOR)[-1]
    value = str(value).strip().upper()
    if not value:
        raise ValueError(f"Tabla sin nombre: {table}")
    return value


def table_relative(table):
    relative = table.get(KEY_RELATIVE) or f"{DEFAULT_SCHEMA_FOLDER}{PATH_SEPARATOR}{table_name(table).lower()}"
    return str(relative).strip(PATH_SEPARATOR).lower()
