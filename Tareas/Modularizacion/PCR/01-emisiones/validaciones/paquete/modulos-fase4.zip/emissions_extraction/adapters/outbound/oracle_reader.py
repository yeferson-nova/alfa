from ...domain.read_plan import METHOD_GLUE_HASH

JDBC_FORMAT = "jdbc"


class SparkOracleReader:
    def __init__(self, spark, glue_context):
        self._spark = spark
        self._glue_context = glue_context

    def read(self, plan, jdbc):
        if plan.method == METHOD_GLUE_HASH:
            return self._glue_context.create_dynamic_frame.from_options(
                connection_type=plan.connection_type,
                connection_options=plan.options,
                transformation_ctx=plan.transformation_ctx,
            ).toDF()
        options = dict(jdbc)
        options.update(plan.options)
        return self._spark.read.format(JDBC_FORMAT).options(**options).load()
