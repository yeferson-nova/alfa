import json

from ...application.events import UNESCAPED_EVENTS

EVENT_KEY = "evento"


class StdoutTelemetry:
    def __init__(self, printer=print):
        self._print = printer

    def emit(self, event):
        escape = event.get(EVENT_KEY) not in UNESCAPED_EVENTS
        self._print(json.dumps(event, ensure_ascii=escape), flush=True)
