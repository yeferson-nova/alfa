from . import contract as c
from .naming import PATH_SEPARATOR, table_relative

SILVER_ROUTE_KEYS = c.SILVER_ROUTE_KEYS


def common_bronze_base(config):
    return config[c.KEY_ROUTES][c.KEY_COMMON_BRONZE]


def output_path(config, table, common=False):
    root = common_bronze_base(config) if common else config[c.KEY_ROUTES][c.KEY_BRONZE_BASE]
    base = (
        root.rstrip(PATH_SEPARATOR)
        + PATH_SEPARATOR
        + table_relative(table)
        + f"{PATH_SEPARATOR}{c.PARTITION_PERIOD}={config[c.KEY_PERIOD]}"
        + f"{PATH_SEPARATOR}{c.PARTITION_LOT}={config[c.KEY_LOT]}"
    )
    if not common:
        base += f"{PATH_SEPARATOR}{c.PARTITION_CASE}={config[c.KEY_CASE]}"
    return base


def configured_silver_base(config):
    routes = config.get(c.KEY_ROUTES, {})
    return next((routes.get(key) for key in SILVER_ROUTE_KEYS if routes.get(key)), None)


def derived_silver_base(config):
    bronze = config[c.KEY_ROUTES][c.KEY_BRONZE_BASE].rstrip(PATH_SEPARATOR)
    return bronze.replace(c.BRONZE_BUCKET_SUFFIX, c.SILVER_BUCKET_SUFFIX, 1)


def silver_destination(config, table):
    explicit = table.get(c.KEY_TABLE_SILVER)
    if explicit:
        return str(explicit).rstrip(PATH_SEPARATOR) + PATH_SEPARATOR
    base = configured_silver_base(config) or derived_silver_base(config)
    return base.rstrip(PATH_SEPARATOR) + PATH_SEPARATOR + table_relative(table) + PATH_SEPARATOR


def checkpoint_uri(destination):
    return destination.rstrip(PATH_SEPARATOR) + c.CHECKPOINT_SUFFIX


def data_uri(destination):
    return destination.rstrip(PATH_SEPARATOR) + PATH_SEPARATOR + c.DATA_FOLDER + PATH_SEPARATOR
