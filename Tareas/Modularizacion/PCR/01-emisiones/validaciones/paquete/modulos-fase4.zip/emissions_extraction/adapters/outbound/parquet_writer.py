WRITE_MODE = "overwrite"
WRITE_FORMAT = "parquet"
COMPRESSION_OPTION = "compression"
COMPRESSION = "snappy"
COUNT_EXPRESSION = "1 AS registro"


class SparkParquetWriter:
    def __init__(self, spark):
        self._spark = spark

    def write_parquet(self, dataframe, uri):
        dataframe.write.mode(WRITE_MODE).format(WRITE_FORMAT).option(COMPRESSION_OPTION, COMPRESSION).save(uri)

    def count_parquet(self, uri):
        return self._spark.read.parquet(uri).selectExpr(COUNT_EXPRESSION).count()
