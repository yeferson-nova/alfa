from ..domain import log_contract as log


class ContractTelemetry:
    def __init__(self, sink, clock, static_fields):
        self._sink = sink
        self._clock = clock
        self._context = {log.FIELD_SCHEMA: log.SCHEMA, **static_fields}

    @property
    def context(self):
        return dict(self._context)

    def bind(self, **fields):
        self._context.update(fields)

    def emit(self, event):
        name = event.get(log.FIELD_EVENT)
        self._sink.emit({
            log.FIELD_TIMESTAMP: self._clock.now_iso(),
            log.FIELD_LEVEL: log.level_for(name),
            log.FIELD_MESSAGE: log.message_for(name),
            **self._context,
            **event,
        })
