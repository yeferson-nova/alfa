from copy import deepcopy

from . import contract as c
from .concurrency_policy import policy_for
from .phase_plan import table_phase
from .spark_filter import validate_spark_filters
from .naming import table_name, table_relative
from .period import month_window

SUPPORTED_CASES = c.SUPPORTED_CASES
SUPPORTED_STRATEGIES = c.SUPPORTED_STRATEGIES
CONFIG_URI_KEY = c.KEY_CONFIG_URI
MIN_ACTIVE_CASES = 1
MAX_ACTIVE_CASES = 3
REQUIRED_ROUTE_KEYS = (c.KEY_RUNTIME_ROUTE, c.KEY_BRONZE_BASE, c.KEY_COMMON_BRONZE)


def flatten_branch_tables(config):
    rows = []
    for cycle in config.get("ciclos", []):
        for segment in cycle.get("segmentos", []):
            for table in segment.get("tablas", []):
                item = deepcopy(table)
                item.setdefault("fase", item.get("orden", c.DEFAULT_PHASE))
                item.setdefault("modo_fase", segment.get("forma", c.DEFAULT_PHASE_MODE))
                rows.append(item)
    return rows


def flatten_core_tables(config):
    rows = []
    phases = sorted(config.get("nucleo_comun", {}).get("fases", []), key=lambda x: x.get("fase", 0))
    for phase in phases:
        for table in sorted(phase.get("tablas", []), key=lambda x: x.get("orden", 0)):
            item = deepcopy(table)
            item["fase"] = phase.get("fase", item.get("fase", c.DEFAULT_PHASE))
            item["modo_fase"] = phase.get("modo", item.get("modo_fase", c.DEFAULT_PHASE_MODE))
            rows.append(item)
    return rows


def normalize_config(raw, uri):
    config = deepcopy(raw)
    config[c.KEY_CONFIG_URI] = uri
    config[c.KEY_CASE] = str(config.get(c.KEY_CASE, "")).strip().lower()
    config[c.KEY_PERIOD] = str(config.get(c.KEY_PERIOD, "")).strip()
    config[c.KEY_EXECUTION_ID] = str(config.get(c.KEY_EXECUTION_ID, "")).strip()
    try:
        config[c.KEY_LOT] = int(config[c.KEY_LOT])
    except Exception as exc:
        raise ValueError(f"{uri}: lote_cargue_id debe ser numerico y efectivo") from exc
    return config


def validate_config(config):
    case = config[c.KEY_CASE]
    if case not in c.SUPPORTED_CASES:
        raise ValueError(f"Caso no soportado: {case}")
    if not config[c.KEY_EXECUTION_ID]:
        raise ValueError(f"{case}: id_ejecucion obligatorio")
    month_window(config[c.KEY_PERIOD])
    source = config.get(c.KEY_SOURCE, {})
    if not source.get("connection_name"):
        raise ValueError(f"{case}: fuente.connection_name obligatorio")
    routes = config.get(c.KEY_ROUTES, {})
    for key in REQUIRED_ROUTE_KEYS:
        if not routes.get(key):
            raise ValueError(f"{case}: {c.KEY_ROUTES}.{key} obligatoria")
    policy_for(config.get(c.KEY_CONTROL, {}))
    if not flatten_core_tables(config):
        raise ValueError(f"{case}: nucleo_comun.fases vacio")
    for table in flatten_core_tables(config) + flatten_branch_tables(config):
        strategy = table.get(c.KEY_STRATEGY, c.DEFAULT_STRATEGY)
        if strategy not in c.SUPPORTED_STRATEGIES:
            raise ValueError(f"{case}/{table_name(table)}: estrategia no soportada {strategy}")
        if strategy in c.SQL_STRATEGIES and not table.get("consulta_sql"):
            raise ValueError(f"{case}/{table_name(table)}: consulta_sql obligatoria")
        if strategy == c.STRATEGY_DEPENDENCY and not table.get("dependencias_lectura"):
            raise ValueError(f"{case}/{table_name(table)}: dependencias_lectura obligatoria")
    validate_spark_filters(config, flatten_core_tables(config), flatten_branch_tables(config), table_phase)


def table_map(config):
    mapping = {}
    for table in flatten_core_tables(config) + flatten_branch_tables(config):
        mapping[table_relative(table)] = table
    return mapping


def validate_route_count(uris):
    if not isinstance(uris, list) or not MIN_ACTIVE_CASES <= len(uris) <= MAX_ACTIVE_CASES:
        raise ValueError("RUTAS_CONFIG_EXTRACCION debe contener entre 1 y 3 rutas")


def validate_unique_cases(configs):
    if len({cfg[c.KEY_CASE] for cfg in configs}) != len(configs):
        raise ValueError("Hay casos activos duplicados")


def ignored_keys(config):
    found = [key for key in c.IGNORED_CONFIG_KEYS if key in config]
    control = config.get(c.KEY_CONTROL, {})
    found += [c.KEY_CONTROL + c.KEY_PATH_SEPARATOR + key for key in c.IGNORED_CONTROL_KEYS if key in control]
    tables = flatten_core_tables(config) + flatten_branch_tables(config)
    found += [
        c.TABLES_KEY_PREFIX + c.KEY_PATH_SEPARATOR + key
        for key in c.IGNORED_TABLE_KEYS
        if any(key in table for table in tables)
    ]
    return found
