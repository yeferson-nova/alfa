from functools import partial

from ..domain import concurrency_policy
from ..domain import contract as c
from ..domain import log_contract as log
from ..domain import phase_plan, results
from ..domain.naming import table_name, table_relative
from ..domain.read_plan import planned_partitions
from . import events
from .parallel_runs import run_in_order, session_pool
from .spark_contexts import NO_CONTEXTS

NO_SESSION_LIMIT = None


class PhaseRunner:
    def __init__(self, extract, telemetry, clock, tracer):
        self._extract = extract
        self._telemetry = telemetry
        self._clock = clock
        self._tracer = tracer

    def run(self, tables, config, table_map, jdbc, start, end, common=False, pool=None, contexts=NO_CONTEXTS):
        pool = pool or session_pool(NO_SESSION_LIMIT)
        policy = concurrency_policy.policy_for(config.get(c.KEY_CONTROL, {}))
        case = config[c.KEY_CASE]
        arguments = (config, table_map, jdbc, start, end, common, contexts)
        collected = []
        for position, phase in enumerate(phase_plan.ordered_phases(tables)):
            if position and policy.phase_pause_seconds:
                self._clock.sleep(policy.phase_pause_seconds)
            targets = phase_plan.tables_in_phase(tables, phase)
            mode = phase_plan.phase_mode(targets)
            workers = policy.workers_for(mode, len(targets))
            self._telemetry.emit(events.phase_started(case, phase, mode, workers, [table_name(t) for t in targets]))
            with self._tracer.step(log.STEP_PHASE, **{log.FIELD_CASE: case, log.FIELD_PHASE: phase}) as step:
                tasks = [partial(self._run_table, table, case, phase, arguments, pool, policy) for table in targets]
                phase_results = run_in_order(tasks, workers, partial(self._table_done, case))
                step.update(results.totals(phase_results))
            collected.extend(phase_results)
        return collected

    def _table_done(self, case, result):
        self._telemetry.emit(events.table_finished(case, result))

    def _run_table(self, table, case, phase, arguments, pool, policy):
        config, table_map, jdbc, start, end, common, contexts = arguments
        fields = {log.FIELD_CASE: case, log.FIELD_PHASE: phase, log.FIELD_TABLE: table_relative(table)}
        with pool.hold(planned_partitions(table, policy.max_partitions)):
            with self._tracer.step(log.STEP_TABLE, **fields) as step:
                result = self._extract(table, config, table_map, jdbc, start, end, common=common, contexts=contexts)
                step.update(results.table_outcome(result))
        return result
