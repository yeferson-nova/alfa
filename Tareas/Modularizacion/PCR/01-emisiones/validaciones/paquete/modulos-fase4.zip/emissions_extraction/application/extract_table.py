from ..domain import concurrency_policy, configuration, spark_filter
from ..domain import contract as c
from ..domain import read_plan as plans
from ..domain import results
from ..domain.naming import table_name, table_relative
from ..domain.paths import checkpoint_uri, data_uri, output_path
from ..domain.sql_compiler import compile_sql, render_sql, unresolved_markers
from . import events
from .spark_contexts import NO_CONTEXTS

REASON_CONTEXT = "contexto no disponible"
REASON_ORIGIN = "tabla de origen no disponible"
REASON_ROWS = "la lectura completa supera max_filas"
USABLE_STATES = frozenset({c.STATE_COMPLETE, c.STATE_REUSED})


class TableExtractor:
    def __init__(self, store, reader, writer, prepare, clock, telemetry, settings, operations=None):
        self._store = store
        self._reader = reader
        self._writer = writer
        self._prepare = prepare
        self._clock = clock
        self._telemetry = telemetry
        self._operations = operations
        self._default_fetchsize = settings.DEFAULT_FETCHSIZE

    def extract(self, table, config, table_map, jdbc, start, end, common=False, contexts=NO_CONTEXTS):
        destination = output_path(config, table, common=common)
        checkpoint = checkpoint_uri(destination)
        control = config.get(c.KEY_CONTROL, {})
        if control.get(c.KEY_ALLOW_RESUME, c.DEFAULT_ALLOW_RESUME) and self._store.exists(checkpoint):
            self._telemetry.emit(events.checkpoint_reused(config[c.KEY_CASE], table_relative(table), checkpoint))
            return results.reused_result(self._store.read_json(checkpoint))
        sql = compile_sql(table, table_map, config, start, end)
        unresolved = unresolved_markers(sql)
        if unresolved:
            raise ValueError(f"{table_relative(table)}: marcadores SQL sin resolver: {unresolved}")
        spec = None if common else spark_filter.filter_spec(table)
        retained = []
        try:
            dataframe = self._read_table(sql, table, config, table_map, jdbc, (start, end), spec, contexts, retained)
        except Exception as exc:
            self._release(retained)
            if not self._is_allowed_absence(table, exc):
                raise
            result = results.optional_table_result(table, config, destination, str(exc))
            self._store.write_json(checkpoint, result)
            return result
        dataframe = self._prepare(
            dataframe,
            table.get(c.KEY_DEDUP, []),
            config[c.KEY_PERIOD],
            config[c.KEY_EXECUTION_ID],
            config[c.KEY_LOT],
            None if common else config[c.KEY_CASE],
        )
        count_rows = bool(control.get(c.KEY_COUNT_ROWS, c.DEFAULT_COUNT_ROWS))
        target = data_uri(destination)
        timings = {"inicio_escritura": self._clock.now_iso()}
        try:
            self._writer.write_parquet(dataframe, target)
        finally:
            self._release(retained)
        timings["fin_escritura"] = self._clock.now_iso()
        timings["inicio_conteo"] = self._clock.now_iso()
        row_count = self._writer.count_parquet(target) if count_rows else None
        timings["fin_conteo"] = self._clock.now_iso()
        result = results.completed_table_result(
            table, config, destination, common, row_count, count_rows, timings, self._clock.now_iso()
        )
        self._store.write_json(checkpoint, result)
        return result

    def _read_table(self, sql, table, config, table_map, jdbc, window, spec, contexts, retained):
        if spec is None:
            return self._read(sql, table, config, jdbc)
        case, relative = config[c.KEY_CASE], table_relative(table)
        if spec.active:
            filtered = self._spark_filtered(table, spec, config, table_map, jdbc, window, contexts, retained)
            if filtered is None:
                return self._read(sql, table, config, jdbc)
            self._telemetry.emit(events.filter_applied(case, relative, spec.mode))
            return filtered
        baseline = self._retain(self._operations.persist(self._read(sql, table, config, jdbc)), retained)
        filtered = self._spark_filtered(table, spec, config, table_map, jdbc, window, contexts, retained)
        if filtered is not None:
            comparison = self._operations.compare(baseline, filtered)
            self._telemetry.emit(events.filter_equivalence(case, relative, comparison))
        return baseline

    def _spark_filtered(self, table, spec, config, table_map, jdbc, window, contexts, retained):
        case, relative = config[c.KEY_CASE], table_relative(table)
        parents = []
        for join in spec.joins:
            parent = contexts.get(join.context_name) if join.uses_context else self._extracted(config, table_map, join.origin)
            if parent is None:
                reason = REASON_CONTEXT if join.uses_context else REASON_ORIGIN
                self._telemetry.emit(events.filter_fallback(case, relative, f"{reason}: {join.origin}"))
                return None
            parents.append((join, parent))
        start, end = window
        frame = self._read(render_sql(spec.read_sql, config, start, end), table, config, jdbc)
        if spec.max_rows is not None:
            frame = self._retain(self._operations.persist(frame), retained)
            if self._operations.count(frame) > spec.max_rows:
                self._telemetry.emit(events.filter_fallback(case, relative, REASON_ROWS))
                return None
        for join, parent in parents:
            frame = self._operations.semi_join(frame, parent, join.mappings)
        return self._operations.distinct(frame) if spec.distinct else frame

    def _extracted(self, config, table_map, origin):
        table = table_map.get(origin)
        if table is None:
            return None
        common = origin in {table_relative(t) for t in configuration.flatten_core_tables(config)}
        destination = output_path(config, table, common=common)
        checkpoint = checkpoint_uri(destination)
        if not self._store.exists(checkpoint):
            return None
        if self._store.read_json(checkpoint).get(c.FIELD_STATE) not in USABLE_STATES:
            return None
        return self._operations.read_parquet(data_uri(destination))

    def _retain(self, frame, retained):
        retained.append(frame)
        return frame

    def _release(self, retained):
        while retained:
            self._operations.unpersist(retained.pop())

    def _read(self, sql, table, config, jdbc):
        max_partitions = concurrency_policy.policy_for(config.get(c.KEY_CONTROL, {})).max_partitions
        plan = plans.build_read_plan(sql, table, config.get(c.KEY_SOURCE, {}), self._default_fetchsize, max_partitions)
        if plan.method == plans.METHOD_GLUE_HASH:
            self._telemetry.emit(events.jdbc_partitioned(table_name(table), plan.method, plan.partitions))
        return self._reader.read(plan, jdbc)

    @staticmethod
    def _is_allowed_absence(table, exc):
        availability = table.get(c.KEY_AVAILABILITY, {})
        allowed = [
            str(code)
            for code in (availability.get(c.KEY_ALLOWED_ERRORS) or availability.get(c.KEY_ALLOWED_CODES) or [])
        ]
        return not availability.get(c.KEY_REQUIRED, c.DEFAULT_TABLE_REQUIRED) and bool(allowed) and any(code in str(exc) for code in allowed)
