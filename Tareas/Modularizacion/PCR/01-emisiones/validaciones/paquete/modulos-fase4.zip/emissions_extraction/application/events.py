from ..domain import contract as c
from ..domain import log_contract as log
from ..domain.concurrency_policy import policy_for

EXTRACTION_STARTED = "EMISIONES_INICIO"
PHASE_STARTED = "FASE_INICIO"
TABLE_FINISHED = "TABLA_FIN"
JDBC_PARTITIONED = "JDBC_PARTICIONADA"
CASE_FINISHED = "CASO_EXTRACCION_OK"
EXTRACTION_FINISHED = "EMISIONES_EXTRACCION_OK"
CORE_SQL_DIFFERS = "ADVERTENCIA_NUCLEO_COMUN_SQL_DIFERENTE"
EXECUTION_ID_RESOLVED = "EJECUCION_ID_RESUELTO"
SILVER_ROUTE_DERIVED = "ADVERTENCIA_RUTA_SILVER_DERIVADA"
CHECKPOINT_REUSED = "CHECKPOINT_REUTILIZADO"
INCOMPLETE_QUALITY = "ADVERTENCIA_CALIDAD_INCOMPLETA"
CORE_TABLES_DIFFER = "ADVERTENCIA_NUCLEO_COMUN_TABLAS"
IGNORED_KEYS = "ADVERTENCIA_CLAVES_SIN_EFECTO"
CONCURRENCY_APPLIED = "CONCURRENCIA_APLICADA"
CONTEXT_LOADED = "CONTEXTO_SPARK_CARGADO"
CONTEXT_OVER_LIMIT = "ADVERTENCIA_CONTEXTO_SPARK_EXCEDIDO"
FILTER_APPLIED = "FILTRO_SPARK_APLICADO"
FILTER_FALLBACK = "ADVERTENCIA_FILTRO_SPARK_RESPALDO"
FILTER_EQUIVALENT = "EQUIVALENCIA_FILTRO_SPARK"
FILTER_DIFFERENT = "ADVERTENCIA_EQUIVALENCIA_FILTRO_SPARK"

UNESCAPED_EVENTS = frozenset({TABLE_FINISHED, CASE_FINISHED, EXTRACTION_FINISHED, CORE_SQL_DIFFERS})


def execution_id_resolved(execution_id, origin, configuration_id, received_id):
    return {
        "evento": EXECUTION_ID_RESOLVED,
        "id_ejecucion": execution_id,
        "origen": origin,
        "id_ejecucion_configuracion": configuration_id,
        "id_ejecucion_recibido": received_id,
    }


def extraction_started(identity, case_names):
    return {
        "evento": EXTRACTION_STARTED,
        "id_ejecucion": identity["id_ejecucion"],
        "periodo_negocio": identity["periodo_negocio"],
        "lote_cargue_id": identity["lote_cargue_id"],
        "casos_activos": list(case_names),
    }


def phase_started(case, phase, mode, workers, table_names):
    return {"evento": PHASE_STARTED, "caso": case, "fase": phase, "modo": mode,
            "concurrencia_jdbc": workers, "tablas": list(table_names)}


def table_finished(case, result):
    return {"evento": TABLE_FINISHED, "caso": case, **result}


def jdbc_partitioned(table, method, partitions):
    return {"evento": JDBC_PARTITIONED, "tabla": table, "metodo": method, "particiones": partitions}


def case_finished(runtime):
    return {"evento": CASE_FINISHED, **runtime}


def extraction_finished(identity, summary):
    return {
        "evento": EXTRACTION_FINISHED,
        "id_ejecucion": identity["id_ejecucion"],
        "periodo_negocio": identity["periodo_negocio"],
        "lote_cargue_id": identity["lote_cargue_id"],
        "runtimes": summary,
    }


def silver_route_derived(case, silver_base):
    return {"evento": SILVER_ROUTE_DERIVED, "caso": case, "s3_silver_base": silver_base}


def checkpoint_reused(case, table, checkpoint):
    return {"evento": CHECKPOINT_REUSED, "caso": case, "tabla_relativa": table, "checkpoint": checkpoint}


def incomplete_quality(case, skipped_tables):
    return {"evento": INCOMPLETE_QUALITY, "caso": case, "tablas_omitidas": skipped_tables}


def core_tables_differ(carrier_case, difference):
    return {"evento": CORE_TABLES_DIFFER, "caso_portador": carrier_case, **difference}


def ignored_keys(case, keys):
    return {"evento": IGNORED_KEYS, "caso": case, "claves": keys}


def concurrency_applied(plan, configs):
    return {
        "evento": CONCURRENCY_APPLIED,
        c.KEY_PARALLEL_CASES: plan.parallel_cases,
        c.KEY_ORACLE_SESSIONS: plan.oracle_sessions,
        "casos": [
            {"caso": config[c.KEY_CASE], **policy_for(config.get(c.KEY_CONTROL, {})).as_event_fields()}
            for config in configs
        ],
    }


def context_loaded(case, name, rows):
    return {"evento": CONTEXT_LOADED, "caso": case, "contexto": name, "filas": rows}


def context_over_limit(case, name, rows, limit):
    return {"evento": CONTEXT_OVER_LIMIT, "caso": case, "contexto": name, "filas": rows,
            c.KEY_MAX_ROWS: limit}


def filter_applied(case, table, mode):
    return {"evento": FILTER_APPLIED, "caso": case, "tabla_relativa": table, "modo": mode}


def filter_fallback(case, table, reason):
    return {"evento": FILTER_FALLBACK, "caso": case, "tabla_relativa": table, "motivo": reason}


def filter_equivalence(case, table, comparison):
    equivalent = (
        comparison[c.FIELD_ONLY_SQL] == 0 and comparison[c.FIELD_ONLY_SPARK] == 0
        and comparison[c.FIELD_SQL_ROWS] == comparison[c.FIELD_SPARK_ROWS]
    )
    name = FILTER_EQUIVALENT if equivalent else FILTER_DIFFERENT
    return {"evento": name, "caso": case, "tabla_relativa": table, "equivalente": equivalent, **comparison}


def span(event_name, step, fields):
    return {log.FIELD_EVENT: event_name, log.FIELD_STEP: step, **fields}


def error_classified(step, fields, error_fields):
    return {log.FIELD_EVENT: log.EVENT_ERROR, log.FIELD_STEP: step, **fields, **error_fields}
