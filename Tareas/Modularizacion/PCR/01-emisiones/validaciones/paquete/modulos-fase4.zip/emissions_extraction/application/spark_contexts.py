import threading
from functools import partial

from ..domain import concurrency_policy
from ..domain import contract as c
from ..domain import log_contract as log
from ..domain import read_plan as plans
from ..domain.spark_filter import context_specs
from ..domain.sql_compiler import render_sql
from . import events

CONTEXT_TABLE_PREFIX = "contexto_"


class NoContexts:
    def get(self, name):
        return None

    def release(self):
        return None


NO_CONTEXTS = NoContexts()


class CaseContexts:
    def __init__(self, specs, load, operations):
        self._specs = specs
        self._load = load
        self._operations = operations
        self._loaded = {}
        self._lock = threading.Lock()

    def get(self, name):
        with self._lock:
            if name not in self._loaded:
                self._loaded[name] = self._load(self._specs[name])
            return self._loaded[name]

    def release(self):
        with self._lock:
            for frame in self._loaded.values():
                if frame is not None:
                    self._operations.unpersist(frame)
            self._loaded.clear()


class ContextLoader:
    def __init__(self, reader, operations, telemetry, tracer, settings):
        self._reader = reader
        self._operations = operations
        self._telemetry = telemetry
        self._tracer = tracer
        self._default_fetchsize = settings.DEFAULT_FETCHSIZE

    def for_case(self, config, jdbc, start, end):
        specs = context_specs(config)
        if not specs:
            return NO_CONTEXTS
        return CaseContexts(specs, partial(self._load, config, jdbc, start, end), self._operations)

    def _load(self, config, jdbc, start, end, spec):
        case = config[c.KEY_CASE]
        max_partitions = concurrency_policy.policy_for(config.get(c.KEY_CONTROL, {})).max_partitions
        table = {c.KEY_TABLE_NAME: f"{CONTEXT_TABLE_PREFIX}{spec.name}", c.KEY_PARALLEL_READ: spec.parallel}
        with self._tracer.step(log.STEP_CONTEXT, **{log.FIELD_CASE: case, log.FIELD_CONTEXT: spec.name}) as step:
            sql = render_sql(spec.sql, config, start, end)
            plan = plans.build_read_plan(sql, table, config.get(c.KEY_SOURCE, {}), self._default_fetchsize, max_partitions)
            frame = self._operations.persist(self._reader.read(plan, jdbc))
            rows = self._operations.count(frame)
            step.update({log.FIELD_ROWS_OUT: rows})
        if rows > spec.max_rows:
            self._operations.unpersist(frame)
            self._telemetry.emit(events.context_over_limit(case, spec.name, rows, spec.max_rows))
            return None
        self._telemetry.emit(events.context_loaded(case, spec.name, rows))
        return frame
