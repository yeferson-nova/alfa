from pyspark.sql import functions as F

COLUMN_PERIOD = "periodo_negocio"
COLUMN_EXECUTION_ID = "id_ejecucion"
COLUMN_LOT = "lote_cargue_id"
COLUMN_CASE = "caso_uso"
LOT_TYPE = "long"


def prepare_for_bronze(dataframe, dedup_keys, periodo, id_ejecucion, lote, caso):
    keys = [key for key in dedup_keys if key in dataframe.columns]
    if keys:
        dataframe = dataframe.dropDuplicates(keys)
    dataframe = (
        dataframe
        .withColumn(COLUMN_PERIOD, F.lit(periodo))
        .withColumn(COLUMN_EXECUTION_ID, F.lit(id_ejecucion))
        .withColumn(COLUMN_LOT, F.lit(lote).cast(LOT_TYPE))
    )
    if caso is not None:
        dataframe = dataframe.withColumn(COLUMN_CASE, F.lit(caso))
    return dataframe
