import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import contextmanager

SEQUENTIAL = 1


def ignore(_):
    return None


def run_in_order(tasks, workers, on_done=ignore):
    if workers <= SEQUENTIAL:
        outcomes = []
        for task in tasks:
            outcome = task()
            outcomes.append(outcome)
            on_done(outcome)
        return outcomes
    ordered = {}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(task): index for index, task in enumerate(tasks)}
        for future in as_completed(futures):
            index = futures[future]
            ordered[index] = future.result()
            on_done(ordered[index])
    return [ordered[index] for index in sorted(ordered)]


class OracleSessionPool:
    def __init__(self, capacity):
        self._capacity = capacity
        self._available = capacity
        self._condition = threading.Condition()

    @property
    def capacity(self):
        return self._capacity

    @contextmanager
    def hold(self, sessions):
        needed = min(sessions, self._capacity)
        with self._condition:
            self._condition.wait_for(lambda: self._available >= needed)
            self._available -= needed
        try:
            yield needed
        finally:
            with self._condition:
                self._available += needed
                self._condition.notify_all()


class UnboundedSessionPool:
    capacity = None

    @contextmanager
    def hold(self, sessions):
        yield sessions


def session_pool(capacity):
    if capacity is None:
        return UnboundedSessionPool()
    return OracleSessionPool(capacity)
