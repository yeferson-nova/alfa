from dataclasses import dataclass
from typing import FrozenSet, Optional

from . import contract as c

MIN_COUNT = 1
MIN_PAUSE = 0


@dataclass(frozen=True)
class ConcurrencyPolicy:
    max_tables: int
    parallel_modes: FrozenSet[str]
    max_partitions: int
    parallel_cases: bool
    oracle_sessions: Optional[int]
    phase_pause_seconds: float

    def workers_for(self, mode, table_count):
        if mode in self.parallel_modes:
            return max(MIN_COUNT, min(self.max_tables, table_count))
        return MIN_COUNT

    def as_event_fields(self):
        return {
            c.KEY_MAX_CONCURRENCY: self.max_tables,
            c.KEY_PARALLEL_MODES: sorted(self.parallel_modes),
            c.KEY_MAX_PARTITIONS: self.max_partitions,
            c.KEY_PHASE_PAUSE: self.phase_pause_seconds,
        }


@dataclass(frozen=True)
class ExecutionConcurrency:
    parallel_cases: bool
    oracle_sessions: Optional[int]


def _invalid(key, expected):
    return ValueError(f"{c.KEY_CONTROL}.{key} debe ser {expected}")


def _positive_int(control, key, default):
    value = control.get(key)
    if value is None:
        return default
    if isinstance(value, bool):
        raise _invalid(key, "un entero positivo")
    try:
        number = int(value)
    except (TypeError, ValueError) as exc:
        raise _invalid(key, "un entero positivo") from exc
    if number < MIN_COUNT:
        raise _invalid(key, "un entero positivo")
    return number


def _pause(control):
    value = control.get(c.KEY_PHASE_PAUSE)
    if value is None:
        return c.DEFAULT_PHASE_PAUSE_SECONDS
    if isinstance(value, bool):
        raise _invalid(c.KEY_PHASE_PAUSE, "un numero mayor o igual a cero")
    try:
        seconds = float(value)
    except (TypeError, ValueError) as exc:
        raise _invalid(c.KEY_PHASE_PAUSE, "un numero mayor o igual a cero") from exc
    if seconds < MIN_PAUSE:
        raise _invalid(c.KEY_PHASE_PAUSE, "un numero mayor o igual a cero")
    return seconds


def _parallel_modes(control):
    value = control.get(c.KEY_PARALLEL_MODES)
    if value is None:
        return c.PARALLEL_MODES
    if not isinstance(value, list) or not all(isinstance(mode, str) and mode.strip() for mode in value):
        raise _invalid(c.KEY_PARALLEL_MODES, "una lista de modos de fase")
    return frozenset(mode.strip().upper() for mode in value)


def _parallel_cases(control):
    value = control.get(c.KEY_PARALLEL_CASES, c.DEFAULT_PARALLEL_CASES)
    if not isinstance(value, bool):
        raise _invalid(c.KEY_PARALLEL_CASES, "true o false")
    return value


def policy_for(control):
    control = control or {}
    return ConcurrencyPolicy(
        max_tables=_positive_int(control, c.KEY_MAX_CONCURRENCY, c.DEFAULT_MAX_CONCURRENCY),
        parallel_modes=_parallel_modes(control),
        max_partitions=_positive_int(control, c.KEY_MAX_PARTITIONS, c.DEFAULT_MAX_PARTITIONS),
        parallel_cases=_parallel_cases(control),
        oracle_sessions=_positive_int(control, c.KEY_ORACLE_SESSIONS, c.DEFAULT_ORACLE_SESSIONS),
        phase_pause_seconds=_pause(control),
    )


def execution_concurrency(configs):
    policies = [policy_for(config.get(c.KEY_CONTROL, {})) for config in configs]
    limits = [policy.oracle_sessions for policy in policies if policy.oracle_sessions is not None]
    return ExecutionConcurrency(
        parallel_cases=all(policy.parallel_cases for policy in policies),
        oracle_sessions=min(limits) if limits else None,
    )
