from dataclasses import dataclass
from typing import Optional, Tuple

from . import contract as c
from .naming import table_name, table_relative

MIN_ROWS = 1


@dataclass(frozen=True)
class JoinSpec:
    origin: str
    mappings: Tuple[Tuple[str, str], ...]

    @property
    def uses_context(self):
        return self.origin.startswith(c.CONTEXT_ORIGIN_PREFIX)

    @property
    def context_name(self):
        return self.origin[len(c.CONTEXT_ORIGIN_PREFIX):]


@dataclass(frozen=True)
class FilterSpec:
    mode: str
    read_sql: str
    joins: Tuple[JoinSpec, ...]
    distinct: bool
    max_rows: Optional[int]

    @property
    def active(self):
        return self.mode == c.FILTER_MODE_ACTIVE

    @property
    def shadow(self):
        return self.mode == c.FILTER_MODE_SHADOW


@dataclass(frozen=True)
class ContextSpec:
    name: str
    sql: str
    max_rows: int
    parallel: dict


def _fail(owner, message):
    return ValueError(f"{owner}: {c.KEY_SPARK_FILTER} {message}")


def _max_rows(owner, value, default):
    if value is None:
        return default
    if isinstance(value, bool):
        raise _fail(owner, f"{c.KEY_MAX_ROWS} debe ser un entero positivo")
    try:
        number = int(value)
    except (TypeError, ValueError) as exc:
        raise _fail(owner, f"{c.KEY_MAX_ROWS} debe ser un entero positivo") from exc
    if number < MIN_ROWS:
        raise _fail(owner, f"{c.KEY_MAX_ROWS} debe ser un entero positivo")
    return number


def _join(owner, raw):
    origin = str((raw or {}).get(c.KEY_JOIN_ORIGIN, "")).strip().strip("/").lower()
    mappings = tuple(
        (str(m.get(c.KEY_MAPPING_ORIGIN, "")).strip().upper(), str(m.get(c.KEY_MAPPING_TARGET, "")).strip().upper())
        for m in (raw or {}).get(c.KEY_MAPPING, []) or []
    )
    if not origin:
        raise _fail(owner, f"tiene un cruce sin {c.KEY_JOIN_ORIGIN}")
    if not mappings or any(not source or not target for source, target in mappings):
        raise _fail(owner, f"tiene un cruce sin {c.KEY_MAPPING} completo hacia {origin}")
    return JoinSpec(origin=origin, mappings=mappings)


def filter_spec(table):
    raw = table.get(c.KEY_SPARK_FILTER)
    if not raw:
        return None
    owner = table_relative(table)
    mode = str(raw.get(c.KEY_FILTER_MODE, c.DEFAULT_FILTER_MODE)).strip().upper()
    if mode not in c.FILTER_MODES:
        raise _fail(owner, f"{c.KEY_FILTER_MODE} no soportado: {mode}")
    if mode == c.FILTER_MODE_OFF:
        return None
    read_sql = str(raw.get(c.KEY_READ_SQL) or "").strip()
    if not read_sql:
        raise _fail(owner, f"sin {c.KEY_READ_SQL}")
    joins = tuple(_join(owner, item) for item in raw.get(c.KEY_JOINS, []) or [])
    if not joins:
        raise _fail(owner, f"sin {c.KEY_JOINS}")
    distinct = raw.get(c.KEY_DISTINCT, False)
    if not isinstance(distinct, bool):
        raise _fail(owner, f"{c.KEY_DISTINCT} debe ser true o false")
    return FilterSpec(
        mode=mode,
        read_sql=read_sql,
        joins=joins,
        distinct=distinct,
        max_rows=_max_rows(owner, raw.get(c.KEY_MAX_ROWS), None),
    )


def context_specs(config):
    specs = {}
    for name, raw in (config.get(c.KEY_SPARK_CONTEXTS) or {}).items():
        owner = f"{config.get(c.KEY_CASE)}/{c.KEY_SPARK_CONTEXTS}.{name}"
        sql = str((raw or {}).get(c.KEY_CONTEXT_SQL) or "").strip()
        if not sql:
            raise ValueError(f"{owner}: sin {c.KEY_CONTEXT_SQL}")
        specs[str(name).strip().lower()] = ContextSpec(
            name=str(name).strip().lower(),
            sql=sql,
            max_rows=_max_rows(owner, (raw or {}).get(c.KEY_MAX_ROWS), c.DEFAULT_CONTEXT_MAX_ROWS),
            parallel=dict((raw or {}).get(c.KEY_PARALLEL_READ) or {}),
        )
    return specs


def validate_spark_filters(config, core_tables, branch_tables, phase_of):
    contexts = context_specs(config)
    core = {table_relative(t) for t in core_tables}
    phases = {table_relative(t): phase_of(t) for t in branch_tables}
    for table in core_tables:
        if filter_spec(table):
            raise _fail(f"{config.get(c.KEY_CASE)}/{table_name(table)}", "no aplica a tablas del nucleo comun")
    for table in branch_tables:
        spec = filter_spec(table)
        if not spec:
            continue
        owner = f"{config.get(c.KEY_CASE)}/{table_name(table)}"
        for join in spec.joins:
            if join.uses_context:
                if join.context_name not in contexts:
                    raise _fail(owner, f"usa un contexto no configurado: {join.context_name}")
                continue
            if join.origin in core:
                continue
            if join.origin not in phases:
                raise _fail(owner, f"cruza con una tabla no configurada: {join.origin}")
            if phases[join.origin] >= phase_of(table):
                raise _fail(owner, f"cruza con {join.origin}, que no se extrae en una fase anterior")
