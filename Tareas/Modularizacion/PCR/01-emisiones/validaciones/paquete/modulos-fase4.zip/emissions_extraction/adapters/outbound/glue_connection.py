import json

PROP_URL = "JDBC_CONNECTION_URL"
PROP_USER = "USERNAME"
PROP_PASSWORD = "PASSWORD"
PROP_SECRET = "SECRET_ID"
PROP_DRIVER = "JDBC_DRIVER_CLASS_NAME"
DEFAULT_DRIVER = "oracle.jdbc.OracleDriver"
SECRET_USER_KEYS = ("username", "user")
SECRET_PASSWORD_KEYS = ("password", "passwd")


def _first(values, keys):
    for key in keys:
        if values.get(key):
            return values.get(key)
    return None


class GlueConnectionResolver:
    def __init__(self, glue_client, secrets_client_factory):
        self._glue = glue_client
        self._secrets_client_factory = secrets_client_factory

    def jdbc_options(self, connection_name):
        connection = self._glue.get_connection(Name=connection_name)["Connection"]
        props = connection.get("ConnectionProperties", {})
        url = props.get(PROP_URL)
        user = props.get(PROP_USER)
        password = props.get(PROP_PASSWORD)
        secret_id = props.get(PROP_SECRET)
        if not url:
            raise ValueError("La Glue Connection " + connection_name + " no contiene JDBC_CONNECTION_URL")
        if secret_id:
            secret_text = self._secrets_client_factory().get_secret_value(SecretId=secret_id).get("SecretString")
            if not secret_text:
                raise ValueError("El secreto de la conexion " + connection_name + " no contiene SecretString")
            secret = json.loads(secret_text)
            user = _first(secret, SECRET_USER_KEYS)
            password = _first(secret, SECRET_PASSWORD_KEYS)
            if not user or not password:
                raise ValueError("El secreto de la conexion " + connection_name + " no contiene username/password")
        if not user or not password:
            raise ValueError("La Glue Connection " + connection_name + " no permite resolver credenciales")
        return {
            "url": url,
            "driver": props.get(PROP_DRIVER, DEFAULT_DRIVER),
            "user": user,
            "password": password,
        }
