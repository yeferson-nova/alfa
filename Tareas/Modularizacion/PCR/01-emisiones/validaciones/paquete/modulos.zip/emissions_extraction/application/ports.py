from typing import Any, Callable, Optional

try:
    from typing import Protocol
except ImportError:
    Protocol = object


class ObjectStore(Protocol):
    def exists(self, uri: str) -> bool: ...

    def read_json(self, uri: str) -> dict: ...

    def write_json(self, uri: str, payload: dict) -> None: ...


class ConnectionResolver(Protocol):
    def jdbc_options(self, connection_name: str) -> dict: ...


class OracleReader(Protocol):
    def read(self, plan: Any, jdbc: dict) -> Any: ...


class DatasetWriter(Protocol):
    def write_parquet(self, dataframe: Any, uri: str) -> None: ...

    def count_parquet(self, uri: str) -> int: ...


class Clock(Protocol):
    def now(self) -> Any: ...

    def now_iso(self) -> str: ...

    def monotonic(self) -> float: ...


class UniqueIdGenerator(Protocol):
    def new_unique_hex(self) -> str: ...


class EventSink(Protocol):
    def emit(self, event: dict) -> None: ...


class Telemetry(Protocol):
    def emit(self, event: dict) -> None: ...

    def bind(self, **fields: Any) -> None: ...


PrepareForBronze = Callable[[Any, list, str, str, int, Optional[str]], Any]
