from copy import deepcopy

from . import contract as c
from .naming import table_name, table_relative
from .period import month_window

SUPPORTED_CASES = c.SUPPORTED_CASES
SUPPORTED_STRATEGIES = c.SUPPORTED_STRATEGIES
CONFIG_URI_KEY = c.KEY_CONFIG_URI
MIN_ACTIVE_CASES = 1
MAX_ACTIVE_CASES = 3


def flatten_branch_tables(config):
    rows = []
    for cycle in config.get("ciclos", []):
        for segment in cycle.get("segmentos", []):
            for table in segment.get("tablas", []):
                item = deepcopy(table)
                item.setdefault("fase", item.get("orden", c.DEFAULT_PHASE))
                item.setdefault("modo_fase", segment.get("forma", c.DEFAULT_PHASE_MODE))
                rows.append(item)
    return rows


def flatten_core_tables(config):
    rows = []
    phases = sorted(config.get("nucleo_comun", {}).get("fases", []), key=lambda x: x.get("fase", 0))
    for phase in phases:
        for table in sorted(phase.get("tablas", []), key=lambda x: x.get("orden", 0)):
            item = deepcopy(table)
            item["fase"] = phase.get("fase", item.get("fase", c.DEFAULT_PHASE))
            item["modo_fase"] = phase.get("modo", item.get("modo_fase", c.DEFAULT_PHASE_MODE))
            rows.append(item)
    return rows


def normalize_config(raw, uri):
    config = deepcopy(raw)
    config[c.KEY_CONFIG_URI] = uri
    config[c.KEY_CASE] = str(config.get(c.KEY_CASE, "")).strip().lower()
    config[c.KEY_PERIOD] = str(config.get(c.KEY_PERIOD, "")).strip()
    config[c.KEY_EXECUTION_ID] = str(config.get(c.KEY_EXECUTION_ID, "")).strip()
    try:
        config[c.KEY_LOT] = int(config[c.KEY_LOT])
    except Exception as exc:
        raise ValueError(f"{uri}: lote_cargue_id debe ser numerico y efectivo") from exc
    return config


def validate_config(config):
    case = config[c.KEY_CASE]
    if case not in c.SUPPORTED_CASES:
        raise ValueError(f"Caso no soportado: {case}")
    if not config[c.KEY_EXECUTION_ID]:
        raise ValueError(f"{case}: id_ejecucion obligatorio")
    month_window(config[c.KEY_PERIOD])
    source = config.get(c.KEY_SOURCE, {})
    if not source.get("connection_name"):
        raise ValueError(f"{case}: fuente.connection_name obligatorio")
    routes = config.get(c.KEY_ROUTES, {})
    if not routes.get("ruta_parametros_extraccion"):
        raise ValueError(f"{case}: rutas.ruta_parametros_extraccion obligatoria")
    if not routes.get("s3_bronze_base"):
        raise ValueError(f"{case}: rutas.s3_bronze_base obligatoria")
    if not flatten_core_tables(config):
        raise ValueError(f"{case}: nucleo_comun.fases vacio")
    for table in flatten_core_tables(config) + flatten_branch_tables(config):
        strategy = table.get(c.KEY_STRATEGY, c.DEFAULT_STRATEGY)
        if strategy not in c.SUPPORTED_STRATEGIES:
            raise ValueError(f"{case}/{table_name(table)}: estrategia no soportada {strategy}")
        if strategy in c.SQL_STRATEGIES and not table.get("consulta_sql"):
            raise ValueError(f"{case}/{table_name(table)}: consulta_sql obligatoria")
        if strategy == c.STRATEGY_DEPENDENCY and not table.get("dependencias_lectura"):
            raise ValueError(f"{case}/{table_name(table)}: dependencias_lectura obligatoria")


def table_map(config):
    mapping = {}
    for table in flatten_core_tables(config) + flatten_branch_tables(config):
        mapping[table_relative(table)] = table
    return mapping


def validate_route_count(uris):
    if not isinstance(uris, list) or not MIN_ACTIVE_CASES <= len(uris) <= MAX_ACTIVE_CASES:
        raise ValueError("RUTAS_CONFIG_EXTRACCION debe contener entre 1 y 3 rutas")


def validate_unique_cases(configs):
    if len({cfg[c.KEY_CASE] for cfg in configs}) != len(configs):
        raise ValueError("Hay casos activos duplicados")
