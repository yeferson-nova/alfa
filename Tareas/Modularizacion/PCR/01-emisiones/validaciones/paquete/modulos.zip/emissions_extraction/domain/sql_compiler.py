import html
import re

from . import contract as c
from .naming import table_name, table_relative

DEFAULT_SCHEMA = c.DEFAULT_SCHEMA
TARGET_ALIAS = c.TARGET_ALIAS
HINT_PATTERN = re.compile(r"/\*\+.*?\*/", flags=re.S)
UNRESOLVED_MARKER = re.compile(r"\{[A-Z0-9_]+\}")


def normalize_sql(text):
    return (
        html.unescape(str(text or ""))
        .replace("{schema}", "{SCHEMA}")
        .replace(" ", " ")
        .strip()
    )


def _schema(table, config):
    return table.get("schema") or config.get("fuente", {}).get("schema", c.DEFAULT_SCHEMA)


def render_sql(sql, config, start, end):
    schema = config.get("fuente", {}).get("schema", c.DEFAULT_SCHEMA)
    replacements = {
        "{SCHEMA}": schema,
        "{START}": start,
        "{END}": end,
        "{START_DATE}": start.strftime("%Y-%m-%d") if hasattr(start, "strftime") else str(start)[:10],
        "{END_DATE}": end.strftime("%Y-%m-%d") if hasattr(end, "strftime") else str(end)[:10],
        "{PERIODO_NEGOCIO}": config["periodo_negocio"],
        "{LOTE_CARGUE_ID}": str(config["lote_cargue_id"]),
        "{ID_EJECUCION}": config["id_ejecucion"],
    }
    rendered = normalize_sql(sql)
    for token, value in replacements.items():
        rendered = rendered.replace(token, str(value))
    return rendered


def oracle_projection(table, alias=TARGET_ALIAS):
    columns = table.get("columnas") or []
    if not columns:
        return f"{alias}.*"
    return ", ".join(f"{alias}.{str(column).upper()}" for column in columns)


def dependency_operator(dependencies):
    if len(dependencies) <= 1:
        return c.SQL_AND
    destination_sets = [tuple(sorted(m["destino"] for m in dep.get("mapeo", []))) for dep in dependencies]
    return c.SQL_OR if len(set(destination_sets)) == 1 else c.SQL_AND


def _exists_group(origin_schema, origin, origin_alias, conditions):
    return (
        "EXISTS (SELECT 1 FROM "
        f"{origin_schema}.{table_name(origin)} {origin_alias} WHERE "
        + " AND ".join(f"({value})" for value in conditions)
        + ")"
    )


def compile_dependency_sql(target, table_map, config, start, end, stack=None):
    stack = list(stack or [])
    target_key = table_relative(target)
    if target_key in stack:
        raise ValueError(f"Dependencia ciclica detectada: {' -> '.join(stack + [target_key])}")
    stack.append(target_key)
    schema = _schema(target, config)
    alias = TARGET_ALIAS
    predicates = []
    where = normalize_sql(target.get("where"))
    if where:
        predicates.append(where.replace(c.ALIAS_MARKER, alias))
    dependencies = target.get("dependencias_lectura", [])
    groups = []
    for index, dep in enumerate(dependencies, 1):
        origin_key = str(dep.get("tabla_origen", "")).strip("/").lower()
        origin = table_map.get(origin_key)
        if not origin:
            raise ValueError(f"{target_key}: tabla_origen no configurada: {origin_key}")
        origin_alias = f"D{index}"
        mappings = dep.get("mapeo", [])
        if not mappings:
            raise ValueError(f"{target_key}: dependencia sin mapeo hacia {origin_key}")
        correlations = [f"{origin_alias}.{m['origen']} = {alias}.{m['destino']}" for m in mappings]
        origin_where = normalize_sql(origin.get("where"))
        if origin_where:
            correlations.append(origin_where.replace(c.ALIAS_MARKER, origin_alias))
        if origin.get("dependencias_lectura", []):
            nested = compile_dependency_predicate(origin, origin_alias, table_map, config, start, end, stack)
            if nested:
                correlations.append(nested)
        groups.append(_exists_group(_schema(origin, config), origin, origin_alias, correlations))
    if groups:
        predicates.append("(" + f" {dependency_operator(dependencies)} ".join(groups) + ")")
    if not predicates:
        predicates.append(c.TRUE_PREDICATE)
    parallel = int(target.get(c.KEY_ORACLE_PARALLEL, c.DEFAULT_ORACLE_PARALLEL) or c.DEFAULT_ORACLE_PARALLEL)
    if parallel not in c.ALLOWED_ORACLE_PARALLEL:
        raise ValueError(f"{target_key}: oracle_parallel no permitido: {parallel}")
    hint = f"/*+ parallel({parallel}) */ " if parallel else ""
    use_distinct = target.get(c.KEY_USE_DISTINCT, c.DEFAULT_USE_DISTINCT)
    if not isinstance(use_distinct, bool):
        raise ValueError(f"{target_key}: usar_distinct debe ser booleano")
    distinct = c.DISTINCT_KEYWORD if use_distinct else ""
    return (
        f"SELECT {hint}{distinct}"
        f"{oracle_projection(target, alias)} "
        f"FROM {schema}.{table_name(target)} {alias} WHERE "
        + " AND ".join(f"({value})" for value in predicates)
    )


def compile_dependency_predicate(target, alias, table_map, config, start, end, stack):
    dependencies = target.get("dependencias_lectura", [])
    groups = []
    for index, dep in enumerate(dependencies, 1):
        origin_key = str(dep.get("tabla_origen", "")).strip("/").lower()
        origin = table_map.get(origin_key)
        if not origin:
            raise ValueError(f"{table_relative(target)}: origen no configurado {origin_key}")
        origin_alias = f"{alias}_D{index}"
        conditions = [f"{origin_alias}.{m['origen']} = {alias}.{m['destino']}" for m in dep.get("mapeo", [])]
        origin_where = normalize_sql(origin.get("where"))
        if origin_where:
            conditions.append(origin_where.replace(c.ALIAS_MARKER, origin_alias))
        if origin.get("dependencias_lectura"):
            nested_stack = list(stack) + [table_relative(target)]
            nested = compile_dependency_predicate(origin, origin_alias, table_map, config, start, end, nested_stack)
            if nested:
                conditions.append(nested)
        groups.append(_exists_group(_schema(origin, config), origin, origin_alias, conditions))
    if not groups:
        return ""
    return "(" + f" {dependency_operator(dependencies)} ".join(groups) + ")"


def compile_sql(table, table_map, config, start, end):
    strategy = table.get(c.KEY_STRATEGY, c.DEFAULT_STRATEGY)
    if strategy in c.SQL_STRATEGIES:
        return render_sql(table["consulta_sql"], config, start, end)
    if strategy == c.STRATEGY_DEPENDENCY:
        return render_sql(compile_dependency_sql(table, table_map, config, start, end), config, start, end)
    alias = TARGET_ALIAS
    where = normalize_sql(table.get("where"))
    clause = c.TRUE_PREDICATE if not where else where.replace(c.ALIAS_MARKER, alias)
    return f"SELECT {oracle_projection(table, alias)} FROM {_schema(table, config)}.{table_name(table)} {alias} WHERE {clause}"


def strip_oracle_hints(sql):
    return HINT_PATTERN.sub("", sql)


def unresolved_markers(sql):
    return sorted(set(UNRESOLVED_MARKER.findall(sql)))
