import re

SCHEMA = "niif17-log/1"
STAGE_EXTRACTION = "extraccion"

FIELD_TIMESTAMP = "marcaTiempo"
FIELD_LEVEL = "nivel"
FIELD_EVENT = "evento"
FIELD_MESSAGE = "mensaje"
FIELD_COMPONENT = "funcion"
FIELD_SCHEMA = "esquema"
FIELD_ENVIRONMENT = "ambiente"
FIELD_EXECUTION_ID = "ejecucion_id"
FIELD_REQUEST_ID = "request_id"
FIELD_MALLA = "malla"
FIELD_STAGE = "etapa"
FIELD_STEP = "paso"
FIELD_PERIOD = "periodo_negocio"
FIELD_LOT = "lote_cargue_id"
FIELD_DURATION = "duracion_ms"
FIELD_RESULT = "resultado"
FIELD_ROWS_OUT = "filas_salida"
FIELD_CASE = "caso"
FIELD_PHASE = "fase"
FIELD_TABLE = "tabla_relativa"
FIELD_STATE = "estado"
FIELD_TABLES_COMPLETE = "tablas_completas"
FIELD_TABLES_REUSED = "tablas_reutilizadas"
FIELD_TABLES_SKIPPED = "tablas_omitidas"

LEVEL_INFO = "INFO"
LEVEL_WARN = "WARN"
LEVEL_ERROR = "ERROR"
WARNING_PREFIX = "ADVERTENCIA_"

RESULT_OK = "OK"
RESULT_ERROR = "ERROR"
RESULT_PARTIAL = "PARCIAL"
RESULT_SKIPPED = "OMITIDO"

EVENT_COMPONENT_START = "COMPONENTE_INICIO"
EVENT_COMPONENT_END = "COMPONENTE_FIN"
EVENT_STEP_START = "PASO_INICIO"
EVENT_STEP_END = "PASO_FIN"
EVENT_ERROR = "ERROR_CLASIFICADO"
EVENT_METRICS = "METRICAS"

STEP_COMPONENT = "extraccion_emisiones"
STEP_LOAD_CONFIG = "cargar_configuracion"
STEP_CONNECTION = "resolver_conexion"
STEP_CORE = "extraer_nucleo"
STEP_CASE = "extraer_caso"
STEP_PHASE = "extraer_fase"
STEP_TABLE = "extraer_tabla"
STEP_RUNTIME = "publicar_runtime"
METRIC_STEPS = frozenset({STEP_COMPONENT, STEP_CASE, STEP_TABLE})

JOB_NAME_PATTERN = re.compile(r"^niif-(?P<ambiente>[a-z0-9]+)-")
ENVIRONMENT_GROUP = "ambiente"

MESSAGES = {
    EVENT_COMPONENT_START: "Inicia la extraccion de Emisiones",
    EVENT_COMPONENT_END: "Termina la extraccion de Emisiones",
    EVENT_STEP_START: "Inicia un paso de la extraccion",
    EVENT_STEP_END: "Termina un paso de la extraccion",
    EVENT_ERROR: "Error clasificado en la extraccion",
    EVENT_METRICS: "Metricas de la extraccion",
}


def environment_from_job_name(job_name):
    match = JOB_NAME_PATTERN.match(str(job_name or ""))
    return match.group(ENVIRONMENT_GROUP) if match else None


def level_for(event_name):
    if event_name == EVENT_ERROR:
        return LEVEL_ERROR
    if str(event_name or "").startswith(WARNING_PREFIX):
        return LEVEL_WARN
    return LEVEL_INFO


def message_for(event_name):
    return MESSAGES.get(event_name, event_name)
