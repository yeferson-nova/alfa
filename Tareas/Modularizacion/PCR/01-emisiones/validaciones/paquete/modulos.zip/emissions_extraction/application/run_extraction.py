import json
from copy import deepcopy

from ..domain import configuration, execution, results
from ..domain import contract as c
from ..domain.execution_id import resolve_execution_id
from ..domain.execution_context import ExecutionContext
from ..domain.period import month_window
from . import events

CORE_CASE_NAME = c.CORE_CASE_NAME
FIRST_CASE = 0


class ExtractionService:
    def __init__(self, store, connections, phases, telemetry, clock, unique_ids):
        self._store = store
        self._connections = connections
        self._phases = phases
        self._telemetry = telemetry
        self._clock = clock
        self._unique_ids = unique_ids

    def load_active_configs(self, raw_routes):
        try:
            uris = json.loads(raw_routes)
        except json.JSONDecodeError as exc:
            raise ValueError("RUTAS_CONFIG_EXTRACCION debe ser una lista JSON") from exc
        configuration.validate_route_count(uris)
        configs = [configuration.normalize_config(self._store.read_json(uri), uri) for uri in uris]
        for config in configs:
            configuration.validate_config(config)
        configuration.validate_unique_cases(configs)
        return configs

    def run(self, raw_routes, job_run_id=None, ejecucion_id_argumento=None):
        configs = self.load_active_configs(raw_routes)
        check = execution.validate_execution(configs)
        for warning in check.warnings:
            self._telemetry.emit(warning)
        configuration_id = check.identity[c.KEY_EXECUTION_ID]
        execution_id, origin = resolve_execution_id(
            ejecucion_id_argumento, c.MALLA_CODE, check.identity[c.KEY_PERIOD],
            self._clock.now(), self._unique_ids.new_unique_hex,
        )
        self._telemetry.emit(events.execution_id_resolved(execution_id, origin, configuration_id, ejecucion_id_argumento))
        identity = {**check.identity, c.KEY_EXECUTION_ID: execution_id}
        for config in configs:
            config[c.KEY_EXECUTION_ID] = execution_id
        context = ExecutionContext.from_identity(
            identity, job_run_id, ejecucion_id_argumento, origin, configuration_id
        )
        start, end = month_window(identity[c.KEY_PERIOD])
        jdbc = self._connections.jdbc_options(identity["connection_name"])
        self._telemetry.emit(events.extraction_started(identity, [cfg[c.KEY_CASE] for cfg in configs]))

        carrier_source = configs[FIRST_CASE]
        carrier = deepcopy(carrier_source)
        carrier[c.KEY_CASE] = CORE_CASE_NAME
        core_results = self._phases.run(
            configuration.flatten_core_tables(carrier_source), carrier, configuration.table_map(carrier_source),
            jdbc, start, end, common=True,
        )

        summary = []
        for config in configs:
            branch_results = self._phases.run(
                configuration.flatten_branch_tables(config), config, configuration.table_map(config),
                jdbc, start, end, common=False,
            )
            runtime = results.runtime_for(config, core_results, branch_results, self._clock.now_iso())
            runtime_uri = config[c.KEY_ROUTES]["ruta_parametros_extraccion"]
            self._store.write_json(runtime_uri, runtime)
            summary.append({
                "caso": config[c.KEY_CASE],
                "runtime": runtime_uri,
                "datasets": len(runtime["datasets_extraidos"]),
                "estado": results.EXTRACTION_SUCCESS,
            })
            self._telemetry.emit(events.case_finished(runtime))

        self._telemetry.emit(events.extraction_finished(identity, summary))
        return context
