from ..domain import contract as c
from ..domain import read_plan as plans
from ..domain import results
from ..domain.naming import table_name, table_relative
from ..domain.paths import checkpoint_uri, data_uri, output_path
from ..domain.sql_compiler import compile_sql, unresolved_markers
from . import events


class TableExtractor:
    def __init__(self, store, reader, writer, prepare, clock, telemetry, settings):
        self._store = store
        self._reader = reader
        self._writer = writer
        self._prepare = prepare
        self._clock = clock
        self._telemetry = telemetry
        self._default_fetchsize = settings.DEFAULT_FETCHSIZE
        self._max_partitions = settings.MAX_JDBC_PARTITIONS
        self._default_common_bronze = settings.DEFAULT_COMMON_BRONZE

    def extract(self, table, config, table_map, jdbc, start, end, common=False):
        destination = output_path(config, table, self._default_common_bronze, common=common)
        checkpoint = checkpoint_uri(destination)
        control = config.get(c.KEY_CONTROL, {})
        if control.get(c.KEY_ALLOW_RESUME, c.DEFAULT_ALLOW_RESUME) and self._store.exists(checkpoint):
            return results.reused_result(self._store.read_json(checkpoint))
        sql = compile_sql(table, table_map, config, start, end)
        unresolved = unresolved_markers(sql)
        if unresolved:
            raise ValueError(f"{table_relative(table)}: marcadores SQL sin resolver: {unresolved}")
        try:
            dataframe = self._read(sql, table, config, jdbc)
        except Exception as exc:
            if not self._is_allowed_absence(table, exc):
                raise
            result = results.optional_table_result(table, config, destination, str(exc))
            self._store.write_json(checkpoint, result)
            return result
        dataframe = self._prepare(
            dataframe,
            table.get(c.KEY_DEDUP, []),
            config[c.KEY_PERIOD],
            config[c.KEY_EXECUTION_ID],
            config[c.KEY_LOT],
            None if common else config[c.KEY_CASE],
        )
        count_rows = bool(control.get(c.KEY_COUNT_ROWS, c.DEFAULT_COUNT_ROWS))
        target = data_uri(destination)
        timings = {"inicio_escritura": self._clock.now_iso()}
        self._writer.write_parquet(dataframe, target)
        timings["fin_escritura"] = self._clock.now_iso()
        timings["inicio_conteo"] = self._clock.now_iso()
        row_count = self._writer.count_parquet(target) if count_rows else None
        timings["fin_conteo"] = self._clock.now_iso()
        result = results.completed_table_result(
            table, config, destination, common, row_count, count_rows, timings, self._clock.now_iso()
        )
        self._store.write_json(checkpoint, result)
        return result

    def _read(self, sql, table, config, jdbc):
        plan = plans.build_read_plan(sql, table, config.get(c.KEY_SOURCE, {}), self._default_fetchsize, self._max_partitions)
        if plan.method == plans.METHOD_GLUE_HASH:
            self._telemetry.emit(events.jdbc_partitioned(table_name(table), plan.method, plan.partitions))
        return self._reader.read(plan, jdbc)

    @staticmethod
    def _is_allowed_absence(table, exc):
        availability = table.get(c.KEY_AVAILABILITY, {})
        allowed = [
            str(code)
            for code in (availability.get(c.KEY_ALLOWED_ERRORS) or availability.get(c.KEY_ALLOWED_CODES) or [])
        ]
        return not availability.get(c.KEY_REQUIRED, c.DEFAULT_TABLE_REQUIRED) and bool(allowed) and any(code in str(exc) for code in allowed)
