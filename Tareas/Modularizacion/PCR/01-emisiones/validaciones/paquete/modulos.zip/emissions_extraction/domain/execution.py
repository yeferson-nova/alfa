import json
from dataclasses import dataclass, field
from typing import List

from .configuration import CONFIG_URI_KEY, flatten_core_tables
from .naming import table_name, table_relative
from .sql_compiler import normalize_sql

WARNING_CORE_SQL_DIFFERS = "ADVERTENCIA_NUCLEO_COMUN_SQL_DIFERENTE"
SINGLE_VALUE = 1


@dataclass(frozen=True)
class ExecutionCheck:
    identity: dict
    warnings: List[dict] = field(default_factory=list)


def _core_rows(config, with_sql):
    rows = []
    for table in flatten_core_tables(config):
        row = {
            "fase": table.get("fase"),
            "tabla": table_name(table),
            "relativa": table_relative(table),
            "estrategia": table.get("estrategia_lectura"),
        }
        if with_sql:
            row["sql"] = normalize_sql(table.get("consulta_sql"))
        rows.append(row)
    return json.dumps(rows, sort_keys=True)


def core_signature(config):
    return _core_rows(config, with_sql=True)


def core_structure_signature(config):
    return _core_rows(config, with_sql=False)


def validate_execution(configs):
    periods = {c["periodo_negocio"] for c in configs}
    lots = {c["lote_cargue_id"] for c in configs}
    executions = {c["id_ejecucion"] for c in configs}
    connections = {c["fuente"]["connection_name"] for c in configs}
    signatures = {core_signature(c) for c in configs}
    structural_signatures = {core_structure_signature(c) for c in configs}
    if len(periods) != SINGLE_VALUE or len(lots) != SINGLE_VALUE or len(executions) != SINGLE_VALUE:
        raise ValueError("Los casos activos deben compartir periodo, lote e id_ejecucion")
    if len(connections) != SINGLE_VALUE:
        raise ValueError(f"Los casos activos usan conexiones diferentes: {connections}")
    if len(structural_signatures) != SINGLE_VALUE:
        raise ValueError(
            "Los casos activos no contienen la misma estructura de nucleo comun "
            "(fase, tabla, ruta relativa o estrategia)"
        )
    warnings = []
    if len(signatures) != SINGLE_VALUE:
        warnings.append({
            "evento": WARNING_CORE_SQL_DIFFERS,
            "mensaje": (
                "Los casos activos tienen diferencias en el SQL del nucleo comun. "
                "Se usara el nucleo del primer caso activo."
            ),
            "caso_portador": configs[0]["nombre_caso"],
            "config_portadora": configs[0][CONFIG_URI_KEY],
        })
    identity = {
        "periodo_negocio": next(iter(periods)),
        "lote_cargue_id": next(iter(lots)),
        "id_ejecucion": next(iter(executions)),
        "connection_name": next(iter(connections)),
    }
    return ExecutionCheck(identity=identity, warnings=warnings)
