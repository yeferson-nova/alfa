import re
from dataclasses import dataclass

from . import contract as c
from .naming import table_name
from .sql_compiler import strip_oracle_hints

METHOD_JDBC = "SPARK_JDBC"
METHOD_GLUE_HASH = "GLUE_HASH"
DEFAULT_CONNECTION_TYPE = c.DEFAULT_CONNECTION_TYPE
MIN_PARTITIONS_TO_SPLIT = 2
NO_PARTITIONS = 0
SINGLE_PARTITION = 1
_COLUMN_REFERENCE = re.compile(r"(?:[A-Za-z][A-Za-z0-9_]*\.)?([A-Za-z][A-Za-z0-9_]*)")


@dataclass(frozen=True)
class ReadPlan:
    method: str
    options: dict
    partitions: int
    connection_type: str = DEFAULT_CONNECTION_TYPE
    transformation_ctx: str = ""


def _partition_count(parallel):
    return int(
        parallel.get("hashpartitions")
        or parallel.get("numero_particiones")
        or parallel.get("numPartitions")
        or NO_PARTITIONS
    )


def build_read_plan(sql, table, source, default_fetchsize, max_partitions):
    sql = strip_oracle_hints(sql)
    fetchsize = str(source.get("fetchsize", default_fetchsize))
    parallel = table.get("lectura_paralela", {}) or {}
    enabled = bool(parallel.get("habilitada"))
    parts = _partition_count(parallel)
    expression = parallel.get("hashexpression")
    field = parallel.get("hashfield")
    subquery = f"({sql}) {c.SUBQUERY_ALIAS}"
    if enabled and parts >= MIN_PARTITIONS_TO_SPLIT and (expression or field):
        options = {
            "useConnectionProperties": c.GLUE_USE_CONNECTION_PROPERTIES,
            "connectionName": source["connection_name"],
            "dbtable": subquery,
            "fetchsize": fetchsize,
            "hashpartitions": str(min(parts, max_partitions)),
        }
        if expression:
            match = _COLUMN_REFERENCE.fullmatch(str(expression).strip())
            options["hashexpression"] = match.group(1).upper() if match else str(expression)
        else:
            options["hashfield"] = str(field)
        return ReadPlan(
            method=METHOD_GLUE_HASH,
            options=options,
            partitions=int(options["hashpartitions"]),
            connection_type=str(source.get("connection_type") or DEFAULT_CONNECTION_TYPE),
            transformation_ctx=f"{c.TRANSFORMATION_CTX_PREFIX}{table_name(table).lower()}",
        )
    options = {"dbtable": subquery, "fetchsize": fetchsize}
    column = parallel.get("partitionColumn") or parallel.get("columna_particion")
    lower = parallel.get("lowerBound") or parallel.get("limite_inferior")
    upper = parallel.get("upperBound") or parallel.get("limite_superior")
    partitions = SINGLE_PARTITION
    if enabled and parts >= MIN_PARTITIONS_TO_SPLIT and column and lower is not None and upper is not None:
        partitions = min(parts, max_partitions)
        options.update({
            "partitionColumn": str(column),
            "lowerBound": str(lower),
            "upperBound": str(upper),
            "numPartitions": str(partitions),
        })
    return ReadPlan(method=METHOD_JDBC, options=options, partitions=partitions)
