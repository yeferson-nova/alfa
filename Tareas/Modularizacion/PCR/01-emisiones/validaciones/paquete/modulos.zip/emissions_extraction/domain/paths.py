from . import contract as c
from .naming import PATH_SEPARATOR, table_relative

SILVER_ROUTE_KEYS = ("s3_silver_base", "s3_silver_base_path", "s3_silver_destino")


def common_bronze_base(config, default_common_bronze):
    return config.get(c.KEY_ROUTES, {}).get("s3_bronze_comun") or default_common_bronze


def output_path(config, table, default_common_bronze, common=False):
    root = common_bronze_base(config, default_common_bronze) if common else config[c.KEY_ROUTES]["s3_bronze_base"]
    base = (
        root.rstrip(PATH_SEPARATOR)
        + PATH_SEPARATOR
        + table_relative(table)
        + f"{PATH_SEPARATOR}{c.PARTITION_PERIOD}={config[c.KEY_PERIOD]}"
        + f"{PATH_SEPARATOR}{c.PARTITION_LOT}={config[c.KEY_LOT]}"
    )
    if not common:
        base += f"{PATH_SEPARATOR}{c.PARTITION_CASE}={config[c.KEY_CASE]}"
    return base


def silver_destination(config, table):
    relative = table_relative(table)
    explicit = table.get("ruta_dataset_destino")
    if explicit:
        return str(explicit).rstrip(PATH_SEPARATOR) + PATH_SEPARATOR
    routes = config.get(c.KEY_ROUTES, {})
    base = next((routes.get(key) for key in SILVER_ROUTE_KEYS if routes.get(key)), None)
    if base:
        return base.rstrip(PATH_SEPARATOR) + PATH_SEPARATOR + relative + PATH_SEPARATOR
    bronze = config[c.KEY_ROUTES]["s3_bronze_base"].rstrip(PATH_SEPARATOR)
    silver = bronze.replace(c.BRONZE_BUCKET_SUFFIX, c.SILVER_BUCKET_SUFFIX, 1)
    return silver + PATH_SEPARATOR + relative + PATH_SEPARATOR


def checkpoint_uri(destination):
    return destination.rstrip(PATH_SEPARATOR) + c.CHECKPOINT_SUFFIX


def data_uri(destination):
    return destination.rstrip(PATH_SEPARATOR) + PATH_SEPARATOR + c.DATA_FOLDER + PATH_SEPARATOR
