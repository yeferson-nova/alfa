from concurrent.futures import ThreadPoolExecutor, as_completed

from ..domain import contract as c
from ..domain import log_contract as log
from ..domain import phase_plan, results
from ..domain.naming import table_name, table_relative
from . import events


class PhaseRunner:
    def __init__(self, extract, telemetry, settings, tracer):
        self._extract = extract
        self._telemetry = telemetry
        self._tracer = tracer
        self._default_concurrency = settings.MAX_JDBC_CONCURRENCY
        self._max_concurrency = settings.MAX_JDBC_CONCURRENCY

    def run(self, tables, config, table_map, jdbc, start, end, common=False):
        collected = []
        limit = phase_plan.concurrency_limit(
            config.get(c.KEY_CONTROL, {}), self._default_concurrency, self._max_concurrency
        )
        case = config[c.KEY_CASE]
        for phase in phase_plan.ordered_phases(tables):
            targets = phase_plan.tables_in_phase(tables, phase)
            mode = phase_plan.phase_mode(targets)
            workers = phase_plan.workers_for(mode, len(targets), limit)
            self._telemetry.emit(events.phase_started(case, phase, mode, workers, [table_name(t) for t in targets]))
            with self._tracer.step(log.STEP_PHASE, **{log.FIELD_CASE: case, log.FIELD_PHASE: phase}) as step:
                phase_results = self._run_phase(targets, workers, case, phase, (config, table_map, jdbc, start, end, common))
                step.update(results.totals(phase_results))
            collected.extend(phase_results)
        return collected

    def _run_phase(self, targets, workers, case, phase, arguments):
        if workers == phase_plan.MIN_WORKERS:
            phase_results = []
            for table in targets:
                result = self._run_table(table, case, phase, arguments)
                phase_results.append(result)
                self._telemetry.emit(events.table_finished(case, result))
            return phase_results
        ordered = {}
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(self._run_table, t, case, phase, arguments): i for i, t in enumerate(targets)}
            for future in as_completed(futures):
                index = futures[future]
                ordered[index] = future.result()
                self._telemetry.emit(events.table_finished(case, ordered[index]))
        return [ordered[i] for i in sorted(ordered)]

    def _run_table(self, table, case, phase, arguments):
        config, table_map, jdbc, start, end, common = arguments
        fields = {log.FIELD_CASE: case, log.FIELD_PHASE: phase, log.FIELD_TABLE: table_relative(table)}
        with self._tracer.step(log.STEP_TABLE, **fields) as step:
            result = self._extract(table, config, table_map, jdbc, start, end, common=common)
            step.update(results.table_outcome(result))
        return result
