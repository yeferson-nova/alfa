from concurrent.futures import ThreadPoolExecutor, as_completed

from ..domain import contract as c
from ..domain import phase_plan
from ..domain.naming import table_name
from . import events


class PhaseRunner:
    def __init__(self, extract, telemetry, settings):
        self._extract = extract
        self._telemetry = telemetry
        self._default_concurrency = settings.MAX_JDBC_CONCURRENCY
        self._max_concurrency = settings.MAX_JDBC_CONCURRENCY

    def run(self, tables, config, table_map, jdbc, start, end, common=False):
        collected = []
        limit = phase_plan.concurrency_limit(
            config.get(c.KEY_CONTROL, {}), self._default_concurrency, self._max_concurrency
        )
        case = config[c.KEY_CASE]
        for phase in phase_plan.ordered_phases(tables):
            targets = phase_plan.tables_in_phase(tables, phase)
            mode = phase_plan.phase_mode(targets)
            workers = phase_plan.workers_for(mode, len(targets), limit)
            self._telemetry.emit(events.phase_started(case, phase, mode, workers, [table_name(t) for t in targets]))
            if workers == phase_plan.MIN_WORKERS:
                for table in targets:
                    result = self._extract(table, config, table_map, jdbc, start, end, common=common)
                    collected.append(result)
                    self._telemetry.emit(events.table_finished(case, result))
                continue
            ordered = {}
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = {
                    pool.submit(self._extract, t, config, table_map, jdbc, start, end, common): i
                    for i, t in enumerate(targets)
                }
                for future in as_completed(futures):
                    index = futures[future]
                    ordered[index] = future.result()
                    self._telemetry.emit(events.table_finished(case, ordered[index]))
            collected.extend(ordered[i] for i in sorted(ordered))
        return collected
