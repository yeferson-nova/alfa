EXTRACTION_STARTED = "EMISIONES_INICIO"
PHASE_STARTED = "FASE_INICIO"
TABLE_FINISHED = "TABLA_FIN"
JDBC_PARTITIONED = "JDBC_PARTICIONADA"
CASE_FINISHED = "CASO_EXTRACCION_OK"
EXTRACTION_FINISHED = "EMISIONES_EXTRACCION_OK"
CORE_SQL_DIFFERS = "ADVERTENCIA_NUCLEO_COMUN_SQL_DIFERENTE"
EXECUTION_ID_RESOLVED = "EJECUCION_ID_RESUELTO"

UNESCAPED_EVENTS = frozenset({TABLE_FINISHED, CASE_FINISHED, EXTRACTION_FINISHED, CORE_SQL_DIFFERS})


def execution_id_resolved(execution_id, origin, configuration_id, received_id):
    return {
        "evento": EXECUTION_ID_RESOLVED,
        "id_ejecucion": execution_id,
        "origen": origin,
        "id_ejecucion_configuracion": configuration_id,
        "id_ejecucion_recibido": received_id,
    }


def extraction_started(identity, case_names):
    return {
        "evento": EXTRACTION_STARTED,
        "id_ejecucion": identity["id_ejecucion"],
        "periodo_negocio": identity["periodo_negocio"],
        "lote_cargue_id": identity["lote_cargue_id"],
        "casos_activos": list(case_names),
    }


def phase_started(case, phase, mode, workers, table_names):
    return {"evento": PHASE_STARTED, "caso": case, "fase": phase, "modo": mode,
            "concurrencia_jdbc": workers, "tablas": list(table_names)}


def table_finished(case, result):
    return {"evento": TABLE_FINISHED, "caso": case, **result}


def jdbc_partitioned(table, method, partitions):
    return {"evento": JDBC_PARTITIONED, "tabla": table, "metodo": method, "particiones": partitions}


def case_finished(runtime):
    return {"evento": CASE_FINISHED, **runtime}


def extraction_finished(identity, summary):
    return {
        "evento": EXTRACTION_FINISHED,
        "id_ejecucion": identity["id_ejecucion"],
        "periodo_negocio": identity["periodo_negocio"],
        "lote_cargue_id": identity["lote_cargue_id"],
        "runtimes": summary,
    }
