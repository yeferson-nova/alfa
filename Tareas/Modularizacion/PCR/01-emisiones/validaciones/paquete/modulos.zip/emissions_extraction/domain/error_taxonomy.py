from dataclasses import dataclass

from . import log_contract as log

MAX_MESSAGE_LENGTH = 300
LINE_BREAK = "\n"
SEVERITY_HIGH = "ALTA"
TEAM_SUPPORT = "SOPORTE"


@dataclass(frozen=True)
class ErrorClass:
    codigo: str
    dominio: str
    severidad: str
    recuperable: bool
    accion: str
    destinatario: str


CONFIGURATION = ErrorClass("EXT-CFG-001", "CONFIGURACION", SEVERITY_HIGH, False,
                           "Corregir la configuracion del caso publicada por la configuradora", "CONFIGURACION")
CONNECTIVITY = ErrorClass("EXT-CON-001", "CONECTIVIDAD", SEVERITY_HIGH, True,
                          "Revisar la conexion de Glue y el secreto de Oracle", TEAM_SUPPORT)
SOURCE = ErrorClass("EXT-ORI-001", "ORIGEN", SEVERITY_HIGH, True,
                    "Revisar la tabla y la consulta en Oracle", TEAM_SUPPORT)
WRITE = ErrorClass("EXT-ESC-001", "ESCRITURA", SEVERITY_HIGH, True,
                   "Revisar el bucket de destino y el runtime del caso", TEAM_SUPPORT)
PERMISSIONS = ErrorClass("EXT-PER-001", "PERMISOS", SEVERITY_HIGH, False,
                         "Revisar los permisos del rol del job", "SEGURIDAD")
PLATFORM = ErrorClass("EXT-PLA-001", "PLATAFORMA", SEVERITY_HIGH, False,
                      "Revisar el detalle del error en el log del job", TEAM_SUPPORT)

PERMISSION_MARKERS = ("AccessDenied", "ORA-01031", "ORA-01017")
CLASS_BY_STEP = {
    log.STEP_LOAD_CONFIG: CONFIGURATION,
    log.STEP_CONNECTION: CONNECTIVITY,
    log.STEP_TABLE: SOURCE,
    log.STEP_RUNTIME: WRITE,
}


def classify(step, error):
    text = f"{type(error).__name__} {error}"
    if any(marker in text for marker in PERMISSION_MARKERS):
        return PERMISSIONS
    if isinstance(error, (ValueError, KeyError)):
        return CONFIGURATION
    return CLASS_BY_STEP.get(step, PLATFORM)


def short_message(error):
    first_line = str(error).strip().split(LINE_BREAK)[0]
    return first_line[:MAX_MESSAGE_LENGTH]


def error_fields(step, error):
    found = classify(step, error)
    return {
        "error_codigo": found.codigo,
        "error_dominio": found.dominio,
        "error_severidad": found.severidad,
        "error_recuperable": found.recuperable,
        "error_accion": found.accion,
        "error_destinatario": found.destinatario,
        "error_tipo": type(error).__name__,
        "error_detalle": short_message(error),
    }
