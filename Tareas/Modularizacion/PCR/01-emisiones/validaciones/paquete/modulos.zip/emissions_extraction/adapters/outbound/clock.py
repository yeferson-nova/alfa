import time
from datetime import datetime, timezone


class UtcClock:
    def now(self):
        return datetime.now(timezone.utc)

    def now_iso(self):
        return self.now().isoformat()

    def monotonic(self):
        return time.monotonic()
