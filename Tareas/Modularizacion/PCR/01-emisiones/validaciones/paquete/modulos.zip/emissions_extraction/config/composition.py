import sys

from ..adapters.inbound.glue_job import ARG_JOB_NAME, GlueJobEntry, resolve_arguments
from ..adapters.outbound.clock import UtcClock
from ..adapters.outbound.glue_connection import GlueConnectionResolver
from ..adapters.outbound.oracle_reader import SparkOracleReader
from ..adapters.outbound.parquet_writer import SparkParquetWriter
from ..adapters.outbound.s3_store import S3ObjectStore
from ..adapters.outbound.stdout_events import StdoutTelemetry
from ..adapters.outbound.unique_ids import UuidGenerator
from ..application.extract_table import TableExtractor
from ..application.run_extraction import ExtractionService
from ..application.run_phases import PhaseRunner
from . import settings

S3_SERVICE = "s3"
GLUE_SERVICE = "glue"
SECRETS_SERVICE = "secretsmanager"


def build_service(spark, glue_context, s3_client, glue_client, secrets_client_factory, prepare,
                  clock=None, telemetry=None):
    clock = clock or UtcClock()
    telemetry = telemetry or StdoutTelemetry()
    store = S3ObjectStore(s3_client)
    extractor = TableExtractor(
        store,
        SparkOracleReader(spark, glue_context),
        SparkParquetWriter(spark),
        prepare,
        clock,
        telemetry,
        settings,
    )
    phases = PhaseRunner(extractor.extract, telemetry, settings)
    connections = GlueConnectionResolver(glue_client, secrets_client_factory)
    return ExtractionService(store, connections, phases, telemetry, clock, UuidGenerator())


def run_job(argv=None):
    import boto3
    from awsglue.context import GlueContext
    from awsglue.job import Job
    from awsglue.utils import getResolvedOptions
    from pyspark.context import SparkContext

    from ..transformations import prepare_for_bronze

    argv = sys.argv if argv is None else argv
    args = resolve_arguments(argv, getResolvedOptions, settings.REQUIRED_JOB_ARGS, settings.OPTIONAL_JOB_ARGS)
    spark_context = SparkContext.getOrCreate()
    glue_context = GlueContext(spark_context)
    spark = glue_context.spark_session
    job = Job(glue_context)
    job.init(args[ARG_JOB_NAME], args)
    region = settings.region()
    service = build_service(
        spark,
        glue_context,
        boto3.client(S3_SERVICE),
        boto3.client(GLUE_SERVICE),
        lambda: boto3.client(SECRETS_SERVICE, region_name=region),
        prepare_for_bronze,
    )
    return GlueJobEntry(service, job).handle(args)
