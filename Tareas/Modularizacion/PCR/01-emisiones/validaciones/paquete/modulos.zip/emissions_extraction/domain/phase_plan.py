from . import contract as c

MIN_WORKERS = 1


def table_phase(table):
    return int(table.get("fase", table.get("orden", c.DEFAULT_PHASE)))


def ordered_phases(tables):
    return sorted({table_phase(t) for t in tables})


def tables_in_phase(tables, phase):
    return [t for t in tables if table_phase(t) == phase]


def phase_mode(targets):
    return str(targets[0].get("modo_fase", c.DEFAULT_PHASE_MODE)).upper() if targets else c.DEFAULT_PHASE_MODE


def concurrency_limit(control, default_concurrency, max_concurrency):
    configured = int(control.get(c.KEY_MAX_CONCURRENCY, default_concurrency) or default_concurrency)
    return max(MIN_WORKERS, min(configured, max_concurrency))


def workers_for(mode, table_count, limit):
    return min(limit, table_count) if mode in c.PARALLEL_MODES else MIN_WORKERS
