"""Filtros comunes para PCR Vida, Generales y Satelites.

Contrato:
- listas ausentes/null/vacias => sin filtro;
- fechas ausentes => ventana mensual derivada de periodoNegocio;
- persiste filtros efectivos en CNF/EXTRACCION;
- actualiza exclusivamente el WHERE tecnico de CONTEXTOPERATION.
"""

import copy
import os
import re
from datetime import date
from decimal import Decimal

import boto3


def normalizar_lista(valor):
    if valor is None:
        return []
    valores = valor if isinstance(valor, list) else [valor]
    salida = []
    vistos = set()
    for item in valores:
        if item is None:
            continue
        texto = str(item).strip()
        if not texto or texto in vistos:
            continue
        vistos.add(texto)
        salida.append(texto)
    return salida


def escapar_sql(valor):
    return str(valor).replace("'", "''")


def lista_numerica_sql(valores, campo):
    if not valores:
        return None
    numeros = []
    for valor in valores:
        if not re.fullmatch(r"-?\d+(?:\.\d+)?", str(valor)):
            raise ValueError(f"Valor no numerico para {campo}: {valor}")
        numeros.append(str(valor))
    return f"{campo} IN ({','.join(numeros)})"


def lista_texto_sql(valores, campo):
    if not valores:
        return None
    literales = ",".join(f"'{escapar_sql(valor)}'" for valor in valores)
    return f"{campo} IN ({literales})"


def ventana_periodo(periodo, fecha_inicio=None, fecha_fin=None):
    periodo = str(periodo or "").strip()
    if not re.fullmatch(r"\d{6}", periodo):
        raise ValueError("periodoNegocio debe tener formato YYYYMM")
    anio, mes = int(periodo[:4]), int(periodo[4:])
    if mes < 1 or mes > 12:
        raise ValueError("periodoNegocio contiene mes invalido")
    inicio = date(anio, mes, 1)
    siguiente = date(anio + 1, 1, 1) if mes == 12 else date(anio, mes + 1, 1)
    inicio_texto = str(fecha_inicio or inicio.isoformat() + " 00:00:00")
    fin_texto = str(fecha_fin or siguiente.isoformat() + " 00:00:00")
    if inicio_texto >= fin_texto:
        raise ValueError("fechaInicio debe ser menor que fechaFin")
    return inicio_texto, fin_texto


def leer_prg(prg_pk):
    tabla = boto3.resource("dynamodb").Table(os.environ["PRG_TABLE"])
    item = tabla.get_item(
        Key={"PK": prg_pk, "SK": os.environ.get("PRG_SK", "METADATA")},
        ConsistentRead=True,
    ).get("Item")
    if not item:
        raise ValueError(f"No existe {prg_pk}/METADATA")
    return item


def filtros_desde_prg(item_prg, periodo):
    status = normalizar_lista(item_prg.get("status"))
    productos = normalizar_lista(item_prg.get("productos"))
    companias = normalizar_lista(item_prg.get("companias"))

    # Compatibilidad con programaciones antiguas escalares.
    if not productos and item_prg.get("producto") is not None:
        productos = normalizar_lista(item_prg.get("producto"))
    if not companias and item_prg.get("compania") is not None:
        companias = normalizar_lista(item_prg.get("compania"))

    fecha_inicio, fecha_fin = ventana_periodo(
        periodo,
        item_prg.get("fechaInicio"),
        item_prg.get("fechaFin"),
    )
    return {
        "periodoNegocio": periodo,
        "fechaInicio": fecha_inicio,
        "fechaFin": fecha_fin,
        "status": [int(valor) for valor in status],
        "productos": productos,
        "companias": companias,
        "aplicarFiltroStatus": bool(status),
        "aplicarFiltroProductos": bool(productos),
        "aplicarFiltroCompanias": bool(companias),
        "origen": "PRG",
    }


def construir_where_pivote(filtros, tipo_caso):
    condiciones = [
        "{ALIAS}.TIME_STAMP >= TO_DATE('" + filtros["fechaInicio"] + "','YYYY-MM-DD HH24:MI:SS')",
        "{ALIAS}.TIME_STAMP < TO_DATE('" + filtros["fechaFin"] + "','YYYY-MM-DD HH24:MI:SS')",
    ]
    status = filtros["status"]
    if status:
        condiciones.append(
            "{ALIAS}.STATUS IN (" + ",".join(str(valor) for valor in status) + ")"
        )

    productos = filtros["productos"]
    companias = filtros["companias"]
    dominio = []

    if tipo_caso in {"PCR_VIDA", "GENERALES"}:
        producto_sql = lista_numerica_sql(productos, "AP.PRODUCTID")
    else:
        producto_sql = lista_texto_sql(productos, "PR.DESCRIPTION")

    campo_compania = (
        "PRP.COMPANIAINPUT" if tipo_caso == "GENERALES" else "PRP.COMPANIAVALUE"
    )
    compania_sql = lista_texto_sql(companias, campo_compania)

    if producto_sql:
        dominio.append(producto_sql)
    if compania_sql:
        dominio.append(compania_sql)

    if dominio:
        joins = (
            "FROM ACSELE_ALFA.POLICYDCO PD "
            "JOIN ACSELE_ALFA.AGREGATEDPOLICY AP "
            "ON AP.AGREGATEDPOLICYID = PD.AGREGATEDOBJECTID "
            "JOIN ACSELE_ALFA.PREPRODUCT PRP ON PRP.STATIC = AP.PRODUCTID "
        )
        if tipo_caso == "SATELITES":
            joins += (
                "JOIN ACSELE_ALFA.PRODUCT PR ON PR.PRODUCTID = AP.PRODUCTID "
            )
        condiciones.append(
            "EXISTS (SELECT 1 "
            + joins
            + "WHERE PD.OPERATIONPK = {ALIAS}.ID AND "
            + " AND ".join(dominio)
            + ")"
        )

    return " AND ".join(condiciones)


def preparar_cnf(
    cnf,
    prg_pk,
    tipo_caso,
    segmento_sufijo,
):
    item_prg = leer_prg(prg_pk)

    periodo = str(
        item_prg.get("periodoNegocio")
        or ""
    ).strip()

    filtros = filtros_desde_prg(
        item_prg,
        periodo,
    )

    where_pivote = construir_where_pivote(
        filtros,
        tipo_caso,
    )

    antes = copy.deepcopy(cnf)
    salida = copy.deepcopy(cnf)

    extraccion = salida.setdefault(
        "EXTRACCION",
        {},
    )

    control = extraccion.setdefault(
        "controlExtraccion",
        {},
    )

    control["periodo_negocio"] = periodo
    control["period_source"] = "PRG"
    control["filtrosEfectivos"] = (
        copy.deepcopy(filtros)
    )

    actualizadas = 0

    for clave, item in salida.items():
        if not clave.startswith("CICLO#"):
            continue

        ciclo = item.get("ciclo", item)

        for segmento in ciclo.get(
            "segmentos",
            [],
        ):
            for tabla in segmento.get(
                "tablas",
                [],
            ):
                nombre = str(
                    tabla.get("tabla")
                    or ""
                ).upper()

                if nombre != "CONTEXTOPERATION":
                    continue

                tabla["where"] = where_pivote

                segmentacion = tabla.setdefault(
                    "segmentacion_horizontal",
                    {},
                )

                segmentacion[
                    "periodo_negocio"
                ] = periodo

                segmentacion["segmento_id"] = (
                    "niif17_"
                    + periodo
                    + "_acsele_contextoperation_"
                    + segmento_sufijo
                )

                actualizadas += 1

    if actualizadas != 1:
        raise ValueError(
            "Se esperaba actualizar una "
            "CONTEXTOPERATION y se actualizaron "
            + str(actualizadas)
        )

    return salida, antes, filtros
