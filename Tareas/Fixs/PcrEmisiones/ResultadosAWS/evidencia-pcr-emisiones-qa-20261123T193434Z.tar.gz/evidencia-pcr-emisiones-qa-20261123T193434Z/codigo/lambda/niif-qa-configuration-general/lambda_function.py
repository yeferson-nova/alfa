import importlib
import os
import re

import boto3

from case_registry import CASES


PATRON = re.compile(r"^[A-Z0-9_]+$")

# Patron ARN Lambda: arn:aws:lambda:<region>:<account_id>:function:<name>
_PATRON_ARN_LAMBDA = re.compile(
    r"^arn:aws:lambda:"
    r"(?P<region>[a-z0-9-]+):"
    r"(?P<account_id>\d{12}):"
    r"function:.+$"
)

# Solo se aceptan estos ambientes
_AMBIENTES_VALIDOS = {"dev", "qa", "prod"}

_PATRON_ENV_FUNCION = re.compile(
    r"^niif-(?P<env>[a-z0-9]+)-configuration-general$",
    re.IGNORECASE,
)

# Marcadores que deben ser reemplazados antes de usar un valor
_PATRON_MARCADORES = re.compile(
    r"\{(?:env|region|account_id)\}"
)


def resolver_contexto_aws(contexto_lambda):
    """Extrae env, region y account_id desde el contexto Lambda.

    Args:
        contexto_lambda: objeto de contexto Lambda con atributo
            ``invoked_function_arn``.

    Returns:
        dict con claves ``env``, ``region`` y ``account_id``.

    Raises:
        ValueError: si la región, el nombre de función o el ARN no son válidos.
    """
    region = (
        os.environ.get("AWS_REGION")
        or os.environ.get("AWS_DEFAULT_REGION")
    )

    if not region:
        raise ValueError(
            "No fue posible obtener la region AWS desde las variables "
            "de entorno AWS_REGION o AWS_DEFAULT_REGION."
        )

    function_name = os.environ.get(
        "AWS_LAMBDA_FUNCTION_NAME",
        "",
    ).lower()

    coincidencia_fn = _PATRON_ENV_FUNCION.fullmatch(function_name)

    if not coincidencia_fn:
        raise ValueError(
            "El nombre de la funcion Lambda no permite determinar el ambiente. "
            "Se esperaba niif-{dev|qa|prod}-configuration-general. "
            f"Nombre recibido: {function_name}"
        )

    env = coincidencia_fn.group("env")

    if env not in _AMBIENTES_VALIDOS:
        raise ValueError(
            f"El ambiente '{env}' no es valido. "
            f"Valores permitidos: {sorted(_AMBIENTES_VALIDOS)}."
        )

    arn = getattr(contexto_lambda, "invoked_function_arn", "")
    coincidencia_arn = _PATRON_ARN_LAMBDA.fullmatch(arn)

    if not coincidencia_arn:
        raise ValueError(
            "No fue posible obtener el account_id desde el ARN de la funcion. "
            f"ARN recibido: {arn}"
        )

    account_id = coincidencia_arn.group("account_id")
    region_arn = coincidencia_arn.group("region")

    if region_arn != region:
        raise ValueError(
            f"La region del ARN '{region_arn}' no coincide con la region "
            f"de entorno '{region}'."
        )

    return {
        "env": env,
        "region": region,
        "account_id": account_id,
    }


def reemplazar_marcadores_aws(valor, contexto):
    """Reemplaza ``{env}``, ``{region}`` y ``{account_id}`` recursivamente.

    Soporta str, dict, list y tuple. Otros tipos (int, bool, None, etc.)
    se devuelven sin modificar.

    Args:
        valor: valor a procesar.
        contexto: dict con claves ``env``, ``region`` y ``account_id``.

    Returns:
        El valor con los marcadores reemplazados.
    """
    env = str(contexto["env"])
    region = str(contexto["region"])
    account_id = str(contexto["account_id"])

    if isinstance(valor, str):
        return (
            valor
            .replace("{env}", env)
            .replace("{region}", region)
            .replace("{account_id}", account_id)
        )

    if isinstance(valor, dict):
        return {
            reemplazar_marcadores_aws(k, contexto): reemplazar_marcadores_aws(v, contexto)
            for k, v in valor.items()
        }

    if isinstance(valor, tuple):
        return tuple(
            reemplazar_marcadores_aws(item, contexto)
            for item in valor
        )

    if isinstance(valor, list):
        return [
            reemplazar_marcadores_aws(item, contexto)
            for item in valor
        ]

    return valor


def buscar_marcadores_aws_pendientes(entrada, _prefijo="$"):
    """Devuelve una lista de paths (notación JSONPath) con marcadores sin resolver.

    Args:
        entrada: estructura a inspeccionar (str, dict, list, tuple u otro).
        _prefijo: prefijo acumulado del path (uso interno).

    Returns:
        Lista de strings con los paths que contienen ``{env}``,
        ``{region}`` o ``{account_id}``.
    """
    pendientes = []

    if isinstance(entrada, str):
        if _PATRON_MARCADORES.search(entrada):
            pendientes.append(_prefijo)

    elif isinstance(entrada, dict):
        for clave, valor in entrada.items():
            pendientes.extend(
                buscar_marcadores_aws_pendientes(
                    valor,
                    f"{_prefijo}.{clave}",
                )
            )

    elif isinstance(entrada, (list, tuple)):
        for indice, item in enumerate(entrada):
            pendientes.extend(
                buscar_marcadores_aws_pendientes(
                    item,
                    f"{_prefijo}[{indice}]",
                )
            )

    return pendientes


def validar_marcadores_aws_resueltos(entrada):
    """Valida que no queden marcadores ``{env}``, ``{region}`` o ``{account_id}``.

    Args:
        entrada: estructura a validar.

    Returns:
        ``True`` si no hay marcadores pendientes.

    Raises:
        ValueError: si se encuentran marcadores sin resolver, indicando
            los paths afectados.
    """
    pendientes = buscar_marcadores_aws_pendientes(entrada)

    if pendientes:
        raise ValueError(
            "Se encontraron marcadores AWS sin resolver en: "
            + ", ".join(pendientes)
        )

    return True


def validar_codigo(event):
    if not isinstance(event, dict):
        raise ValueError(
            "El evento debe ser un objeto JSON."
        )

    codigo = str(
        event.get(
            "codigoMalla",
            ""
        )
    ).strip().upper()

    if (
        not codigo
        or not PATRON.fullmatch(codigo)
    ):
        raise ValueError(
            "codigoMalla invalido."
        )

    if codigo not in CASES:
        raise ValueError(
            "codigoMalla no soportado: "
            + codigo
        )

    return codigo


def configurar_entorno(codigo):
    caso = CASES[codigo]

    from case_registry import _CONTEXTO_AWS

    env = _CONTEXTO_AWS["env"] if _CONTEXTO_AWS else "dev"

    # Si las tablas no están definidas como variables de entorno se derivan
    # del ambiente (comportamiento por defecto en Lambda desplegada).
    defaults_tablas = {
        "CNF_TABLE": f"niif-{env}-cnf-mallas",
        "PRS_TABLE": f"niif-{env}-prs-estructuras",
        "PRG_TABLE": f"niif-{env}-prg-programaciones",
        "EJC_TABLE": f"niif-{env}-ejc-ejecuciones",
    }

    for variable, valor_default in defaults_tablas.items():
        if not os.environ.get(variable):
            os.environ[variable] = valor_default

    os.environ["PRG_SK"] = "METADATA"
    os.environ["MALLA_PK"] = (
        caso["malla_pk"]
    )
    os.environ["PRG_PK"] = (
        caso["prg_pk"]
    )
    os.environ["STATE_MACHINE_ARN"] = (
        caso["state_machine_arn"]
    )

    return caso


def leer_periodo_prg(caso):
    tabla = boto3.resource(
        "dynamodb"
    ).Table(
        os.environ["PRG_TABLE"]
    )

    item = tabla.get_item(
        Key={
            "PK": caso["prg_pk"],
            "SK": "METADATA",
        },
        ConsistentRead=True,
    ).get(
        "Item",
        {},
    )

    if not item:
        raise ValueError(
            "No existe PRG: "
            + caso["prg_pk"]
        )

    periodo = str(
        item.get(
            "periodoNegocio"
        )
        or ""
    ).strip()

    if (
        len(periodo) != 6
        or not periodo.isdigit()
    ):
        raise ValueError(
            "periodoNegocio del PRG "
            "debe tener formato YYYYMM."
        )

    mes = int(periodo[4:6])

    if mes < 1 or mes > 12:
        raise ValueError(
            "Mes invalido en "
            "periodoNegocio del PRG."
        )

    return periodo


def lambda_handler(event, context):
    codigo = validar_codigo(event)

    caso = configurar_entorno(
        codigo
    )

    periodo = leer_periodo_prg(
        caso
    )

    modulo = importlib.import_module(
        caso["module"]
    )

    delegado = dict(event)

    delegado["codigoMalla"] = codigo
    delegado["periodoNegocio"] = periodo

    resultado = modulo.lambda_handler(
        delegado,
        context,
    )

    return {
        "configuradoraGeneral": True,
        "codigoMalla": codigo,
        "periodoNegocio": periodo,
        "origenPeriodoNegocio": "PRG",
        "moduloDelegado":
            caso["module"],
        "resultado": resultado,
    }
