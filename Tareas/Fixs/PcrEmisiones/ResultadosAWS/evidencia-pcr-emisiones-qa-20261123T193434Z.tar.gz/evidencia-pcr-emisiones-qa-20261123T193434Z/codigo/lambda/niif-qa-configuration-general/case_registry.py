"""Registro de casos NIIF y resolución de contexto AWS.

Los ARN que contienen ``{env}``, ``{region}`` y ``{account_id}`` se
resuelven en tiempo de importación usando variables de entorno y STS.

Durante pruebas unitarias, el mock de boto3 debe configurar STS para
devolver un Account como string real.  Si la resolución falla, se
intenta un fallback usando la variable ``AWS_ACCOUNT_ID`` del entorno.
"""

import os
import re

# ---------------------------------------------------------------------------
# Definición estática de casos (placeholders se resuelven al final)
# ---------------------------------------------------------------------------

_CASES_RAW = {
    "EMISIONES": {
        "module": "conf_emisiones",
        "malla_pk": "MALLA#EMISIONES",
        "prg_pk": "PROGRAMACION#EMISIONES",
        "state_machine_arn": (
            "arn:aws:states:{region}:"
            "{account_id}:"
            "stateMachine:niif-{env}-emisiones"
        ),
    },

    "AUXILIOS_FUNERARIOS": {
        "malla_pk": "MALLA#AUXILIOS_FUNERARIOS",
        "module": "conf_auxilios",
        "prg_pk": "PROGRAMACION#AUXILIOS_FUNERARIOS",
        "state_machine_arn": (
            "arn:aws:states:{region}:{account_id}:"
            "stateMachine:niif-{env}-auxilios-funerarios"
        ),
    },
    "PRIMAS_ARL": {
        "malla_pk": "MALLA#PRIMAS_ARL",
        "module": "conf_arl",
        "prg_pk": "PROGRAMACION#PRIMAS_ARL",
        "state_machine_arn": (
            "arn:aws:states:{region}:{account_id}:"
            "stateMachine:niif-{env}-primas-arl"
        ),
    },
    "PRIMAS_ENDOSOS": {
        "malla_pk": "MALLA#PRIMAS_ENDOSOS",
        "module": "conf_endosos",
        "prg_pk": "PROGRAMACION#PRIMAS_ENDOSOS",
        "state_machine_arn": (
            "arn:aws:states:{region}:{account_id}:"
            "stateMachine:niif-{env}-primas-endosos"
        ),
    },
    "PRIMAS_RENTAS": {
        "malla_pk": "MALLA#PRIMAS_RENTAS",
        "module": "conf_rentas",
        "prg_pk": "PROGRAMACION#PRIMAS_RENTAS",
        "state_machine_arn": (
            "arn:aws:states:{region}:{account_id}:"
            "stateMachine:niif-{env}-primas-rentas"
        ),
    },
    "RESERVA_MATEMATICA_ARP": {
        "malla_pk": "MALLA#RESERVA_MATEMATICA_ARP",
        "module": "conf_res_mat_arp",
        "prg_pk": "PROGRAMACION#RESERVA_MATEMATICA_ARP",
        "state_machine_arn": (
            "arn:aws:states:{region}:{account_id}:"
            "stateMachine:niif-{env}-reserva-matematica-arp"
        ),
    },
    "RESERVA_MATEMATICA_RVI": {
        "malla_pk": "MALLA#RESERVA_MATEMATICA_RVI",
        "module": "conf_res_mat_rvi",
        "prg_pk": "PROGRAMACION#RESERVA_MATEMATICA_RVI",
        "state_machine_arn": (
            "arn:aws:states:{region}:{account_id}:"
            "stateMachine:niif-{env}-reserva-matematica-rvi"
        ),
    },
}

_PATRON_ENV = re.compile(
    r"^niif-(?P<env>[a-z0-9]+)-configuration-general$",
    re.IGNORECASE,
)


def _obtener_contexto_aws():
    """Obtiene env, region y account_id para resolver los ARN.

    Intenta primero con STS.  Si STS devuelve un valor no-string
    (mock sin configurar) o falla, usa AWS_ACCOUNT_ID del entorno.
    """
    import boto3  # importación local: el mock de tests tiene efecto aquí

    region = (
        os.environ.get("AWS_REGION")
        or os.environ.get("AWS_DEFAULT_REGION")
    )

    if not region:
        raise RuntimeError(
            "No fue posible obtener la region AWS"
        )

    function_name = os.environ.get(
        "AWS_LAMBDA_FUNCTION_NAME",
        "",
    )

    coincidencia = _PATRON_ENV.fullmatch(function_name)

    if not coincidencia:
        raise RuntimeError(
            "El nombre de la Lambda no cumple el estandar: "
            "niif-{env}-configuration-general. "
            f"Nombre recibido: {function_name}"
        )

    env = coincidencia.group("env").lower()

    # Intentar obtener account_id via STS; si el mock no está configurado
    # correctamente, el valor puede no ser un str de 12 dígitos.
    account_id = None
    try:
        raw = (
            boto3.client("sts", region_name=region)
            .get_caller_identity()
            .get("Account", "")
        )
        candidate = str(raw).strip()
        if candidate.isdigit() and len(candidate) == 12:
            account_id = candidate
    except Exception:
        pass

    # Fallback: variable de entorno AWS_ACCOUNT_ID (seteada por los tests)
    if not account_id:
        account_id = os.environ.get("AWS_ACCOUNT_ID", "")

    if not account_id:
        raise RuntimeError(
            "No fue posible obtener el account_id de AWS"
        )

    return {
        "env": env,
        "region": region,
        "account_id": account_id,
    }


def _resolver_valor_ambiente(valor, contexto):
    """Reemplaza placeholders recursivamente, asegurando tipos str."""
    env = str(contexto["env"])
    region = str(contexto["region"])
    account_id = str(contexto["account_id"])

    if isinstance(valor, str):
        return (
            valor
            .replace("{env}", env)
            .replace("{region}", region)
            .replace("{account_id}", account_id)
        )

    if isinstance(valor, dict):
        return {
            clave: _resolver_valor_ambiente(contenido, contexto)
            for clave, contenido in valor.items()
        }

    if isinstance(valor, list):
        return [
            _resolver_valor_ambiente(contenido, contexto)
            for contenido in valor
        ]

    return valor


# ---------------------------------------------------------------------------
# Resolución al importar el módulo
# ---------------------------------------------------------------------------

_CONTEXTO_AWS = _obtener_contexto_aws()
CASES = _resolver_valor_ambiente(_CASES_RAW, _CONTEXTO_AWS)
