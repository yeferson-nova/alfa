"""Configurador consolidado de EXTRACCION para Emisiones.

Este modulo atiende solo codigoMalla=EMISIONES. No invoca ni modifica los
configuradores historicos de PCR Vida, Generales o Satelites. Lee PRG, combina
los registros CNF EXTRACCION + CICLO#001, aplica filtros efectivos, publica los
tres JSON oficiales y devuelve sus rutas al orquestador.
"""

import copy
import json
import os
import re
from datetime import datetime, timezone
from decimal import Decimal

import boto3

REGION = os.environ.get("AWS_REGION", "us-east-1")
FUNCTION_NAME = os.environ.get(
    "AWS_LAMBDA_FUNCTION_NAME",
    "",
)

FUNCTION_PARTS = FUNCTION_NAME.split("-")

ENV = (
    FUNCTION_PARTS[1]
    if (
        len(FUNCTION_PARTS) > 1
        and FUNCTION_PARTS[0] == "niif"
    )
    else os.environ.get("ENV", "dev")
)

if ENV not in {"dev", "qa", "prod"}:
    raise ValueError(
        f"Ambiente no soportado en "
        f"AWS_LAMBDA_FUNCTION_NAME: {ENV}"
    )

CNF_TABLE = os.environ.get(
    "CNF_TABLE",
    f"niif-{ENV}-cnf-mallas",
)

PRG_TABLE = os.environ.get(
    "PRG_TABLE",
    f"niif-{ENV}-prg-programaciones",
)

CASES = {
    "pcr_vida": {
        "code": "PCR_VIDA",
        "pk": "MALLA#PCR_VIDA",
        "uri": f"s3://niif-{ENV}-assets/pcr-vida/config_extraccion_pcr_vida.json",
        "product_type": "NUMERIC",
        "company_column": "COMPANIAVALUE",
    },
    "generales": {
        "code": "GENERALES",
        "pk": "MALLA#GENERALES",
        "uri": f"s3://niif-{ENV}-assets/generales/config_extraccion_generales.json",
        "product_type": "NUMERIC",
        "company_column": "COMPANIAINPUT",
    },
    "satelites": {
        "code": "SATELITES",
        "pk": "MALLA#SATELITES",
        "uri": f"s3://niif-{ENV}-assets/satelites/config_extraccion_satelites.json",
        "product_type": "TEXT",
        "company_column": "COMPANIAVALUE",
    },
}

DDB = boto3.resource("dynamodb", region_name=REGION)
CNF = DDB.Table(CNF_TABLE)
PRG = DDB.Table(PRG_TABLE)
S3 = boto3.client("s3", region_name=REGION)



def json_compatible(valor):
    """Convierte tipos DynamoDB a tipos JSON nativos."""
    if isinstance(valor, Decimal):
        if valor == valor.to_integral_value():
            return int(valor)

        return float(valor)

    if isinstance(valor, dict):
        return {
            clave: json_compatible(contenido)
            for clave, contenido in valor.items()
        }

    if isinstance(valor, list):
        return [
            json_compatible(contenido)
            for contenido in valor
        ]

    if isinstance(valor, tuple):
        return [
            json_compatible(contenido)
            for contenido in valor
        ]

    if isinstance(valor, set):
        return [
            json_compatible(contenido)
            for contenido in sorted(
                valor,
                key=str,
            )
        ]

    return valor



def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def normalize_list(value):
    if value is None:
        return []
    values = value if isinstance(value, list) else [value]
    result = []
    seen = set()
    for item in values:
        if item is None:
            continue
        text = str(item).strip()
        if text and text not in seen:
            seen.add(text)
            result.append(text)
    return result


def month_window(period):
    if not re.fullmatch(r"\d{6}", str(period or "")):
        raise ValueError("periodoNegocio debe tener formato YYYYMM")
    year, month = int(period[:4]), int(period[4:])
    if not 1 <= month <= 12:
        raise ValueError("periodoNegocio contiene mes invalido")
    start = datetime(year, month, 1)
    end = datetime(year + 1, 1, 1) if month == 12 else datetime(year, month + 1, 1)
    return start.strftime("%Y-%m-%d 00:00:00"), end.strftime("%Y-%m-%d 00:00:00")


def read_program():
    item = PRG.get_item(
        Key={"PK": "PROGRAMACION#EMISIONES", "SK": "METADATA"},
        ConsistentRead=True,
    ).get("Item")
    if not item:
        raise ValueError("No existe PROGRAMACION#EMISIONES/METADATA")
    if item.get("activo") is False:
        raise ValueError("PROGRAMACION#EMISIONES esta inactiva")
    return item


def execution_identity(program, period):
    current = datetime.now(timezone.utc)
    execution_id = program.get("idEjecucion") or (
        f"EMISIONES-{period}-{current.strftime('%Y%m%dT%H%M%SZ')}"
    )
    lot = program.get("loteCargueId")
    lot = int(lot) if lot is not None else int(current.strftime("%Y%m%d%H%M%S"))
    return str(execution_id), lot


def read_cnf(pk, sk):
    item = CNF.get_item(Key={"PK": pk, "SK": sk}, ConsistentRead=True).get("Item")
    if not item:
        raise ValueError(f"No existe {pk}/{sk}")
    if item.get("versionModelo") != "EMISIONES_EXTRACCION_V1":
        raise ValueError(f"{pk}/{sk} no usa EMISIONES_EXTRACCION_V1")
    return item


def s3_parts(uri):
    if not uri.startswith("s3://"):
        raise ValueError(f"URI S3 invalida: {uri}")
    return uri[5:].split("/", 1)


def sql_quote(value):
    return "'" + str(value).replace("'", "''") + "'"


def numeric_values(values, field):
    result = []
    for value in values:
        text = str(value).strip()
        if not re.fullmatch(r"-?\d+(?:\.\d+)?", text):
            raise ValueError(f"{field} contiene valor no numerico: {value}")
        result.append(text)
    return result


def condition_in(alias_column, values, numeric=False):
    if not values:
        return "1=1"
    rendered = numeric_values(values, alias_column) if numeric else [sql_quote(v) for v in values]
    return f"{alias_column} IN ({','.join(rendered)})"


def render_values(
    values,
    numeric=False,
):
    if not values:
        raise ValueError(
            "No se recibieron valores para "
            "materializar el marcador SQL."
        )

    if numeric:
        return ",".join(
            numeric_values(
                values,
                "marcador_sql",
            )
        )

    return ",".join(
        sql_quote(value)
        for value in values
    )


def apply_sql_filters(
    sql,
    common,
    domain,
    meta,
    apply_domain=True,
):
    text = str(sql)

    replacements = {
        "${FECHA_INICIO}":
            common["fechaInicio"],
        "${FECHA_FIN}":
            common["fechaFin"],
        "${STATUS_OPERACION}":
            render_values(
                common["status"],
                numeric=True,
            ),
    }

    if apply_domain:
        if "${PRODUCTOS}" in text:
            replacements["${PRODUCTOS}"] = (
                render_values(
                    domain["productos"],
                    numeric=(
                        meta["product_type"]
                        == "NUMERIC"
                    ),
                )
            )

        if "${COMPANIAS}" in text:
            replacements["${COMPANIAS}"] = (
                render_values(
                    domain["companias"],
                    numeric=False,
                )
            )

    for marker, value in replacements.items():
        text = text.replace(
            marker,
            value,
        )

    pendientes = sorted(
        set(
            re.findall(
                r"\$\{[A-Z0-9_]+\}",
                text,
            )
        )
    )

    if pendientes:
        raise ValueError(
            "Marcadores SQL sin resolver: "
            + ", ".join(pendientes)
        )

    return text


def walk_tables(config):
    for phase in config["nucleo_comun"]["fases"]:
        for table in phase["tablas"]:
            yield table
    for cycle in config["ciclos"]:
        for segment in cycle["segmentos"]:
            for table in segment["tablas"]:
                yield table


def build_config(
    case,
    meta,
    extraction,
    cycle,
    common,
    domain,
    core_domain,
    execution_id,
    lot,
    mode,
):
    config = {
        "nombre_caso": extraction["nombreCaso"],
        "id_ejecucion": execution_id,
        "periodo_negocio": common["periodoNegocio"],
        "lote_cargue_id": lot,
        "modo_ejecucion": mode,
        "ventana_extraccion": {
            "fecha_inicio": common["fechaInicio"],
            "fecha_fin": common["fechaFin"],
            "fecha_fin_exclusiva": True,
        },
        "fuente": copy.deepcopy(extraction["fuente"]),
        "rutas": copy.deepcopy(extraction["rutas"]),
        "control_extraccion": copy.deepcopy(extraction["controlExtraccion"]),
        "salida_runtime": copy.deepcopy(extraction["salidaRuntime"]),
        "clasificacion_caso": copy.deepcopy(extraction["clasificacionCaso"]),
        "reglas_arquitectura": copy.deepcopy(extraction.get("reglasArquitectura", {})),
        "filtros_efectivos": {
            "status": common["status"],
            "aplicar_status": bool(common["status"]),
            "productos": domain["productos"],
            "aplicar_productos": bool(domain["productos"]),
            "companias": domain["companias"],
            "aplicar_companias": bool(domain["companias"]),
            "origen": "PRG",
        },
        "nucleo_comun": copy.deepcopy(cycle["nucleoComun"]),
        "ciclos": copy.deepcopy(cycle["ciclos"]),
        "archivo_activo_uri": extraction["archivoActivoUri"],
        "version_modelo": "EMISIONES_EXTRACCION_V1",
    }
    config["control_extraccion"]["periodo_negocio"] = common["periodoNegocio"]
    config["control_extraccion"]["period_source"] = "PRG"

    core_tables = [
        table
        for phase in config[
            "nucleo_comun"
        ]["fases"]
        for table in phase["tablas"]
    ]

    branch_tables = [
        table
        for cycle in config["ciclos"]
        for segment in cycle["segmentos"]
        for table in segment["tablas"]
    ]

    # El núcleo debe ser idéntico en los tres casos.
    # Solo recibe período y status.
    for table in core_tables:
        if table.get("consulta_sql"):
            table["consulta_sql"] = (
                apply_sql_filters(
                    table["consulta_sql"],
                    common,
                    core_domain,
                    {
                        **meta,
                        "product_type": "TEXT",
                    },
                    apply_domain=True,
                )
            )

        if (
            str(table.get("tabla", "")).upper()
            == "CONTEXTOPERATION"
        ):
            predicates = [
                "{ALIAS}.TIME_STAMP >= TO_DATE("
                + sql_quote(common["fechaInicio"])
                + ",'YYYY-MM-DD HH24:MI:SS')",
                "{ALIAS}.TIME_STAMP < TO_DATE("
                + sql_quote(common["fechaFin"])
                + ",'YYYY-MM-DD HH24:MI:SS')",
            ]

            if common["status"]:
                predicates.append(
                    condition_in(
                        "{ALIAS}.STATUS",
                        common["status"],
                        numeric=True,
                    )
                )

            table["where"] = " AND ".join(
                predicates
            )

            segmentation = table.setdefault(
                "segmentacion_horizontal",
                {},
            )

            segmentation[
                "periodo_negocio"
            ] = common["periodoNegocio"]

    # Producto y compañía se aplican únicamente
    # a las tablas de la rama.
    for table in branch_tables:
        if table.get("consulta_sql"):
            table["consulta_sql"] = (
                apply_sql_filters(
                    table["consulta_sql"],
                    common,
                    domain,
                    meta,
                    apply_domain=True,
                )
            )


    # ContextOperation pertenece al núcleo consolidado
    # de Emisiones.
    for table in core_tables:
        if (
            str(
                table.get("tabla")
                or ""
            ).upper()
            != "CONTEXTOPERATION"
        ):
            continue

        segmentacion = table.setdefault(
            "segmentacion_horizontal",
            {},
        )

        segmentacion[
            "periodo_negocio"
        ] = common["periodoNegocio"]

        segmentacion[
            "id_negocio"
        ] = "emisiones"

        segmentacion[
            "segmento_id"
        ] = (
            "niif17_"
            + common["periodoNegocio"]
            + "_acsele_contextoperation_emisiones"
        )

    return config


def validate_config(case, config):
    core = [t for p in config["nucleo_comun"]["fases"] for t in p["tablas"]]
    branch = [t for c in config["ciclos"] for s in c["segmentos"] for t in s["tablas"]]
    phases = sorted({int(t["fase"]) for t in branch})
    if not core:
        raise ValueError(
            f"{case}: nucleo comun vacio"
        )
    if not branch:
        raise ValueError(
            f"{case}: rama de extraccion vacia"
        )

    names = [
        str(t.get("tabla", "")).strip().upper()
        for t in core + branch
    ]

    if any(not name for name in names):
        raise ValueError(
            f"{case}: existen tablas sin nombre"
        )

    duplicates = sorted({
        name
        for name in names
        if names.count(name) > 1
    })

    if duplicates:
        raise ValueError(
            f"{case}: tablas duplicadas {duplicates}"
        )
    if phases != [4, 5, 6, 7, 8, 9]:
        raise ValueError(f"{case}: fases invalidas {phases}")

    if any("{START}" in str(t.get("consulta_sql", "")) or "{END}" in str(t.get("consulta_sql", "")) for t in core + branch):
        raise ValueError(f"{case}: quedaron marcadores de fecha")








def read_contract(pk, sk):
    item = CNF.get_item(
        Key={
            "PK": pk,
            "SK": sk,
        },
        ConsistentRead=True,
    ).get("Item")

    if not item:
        raise ValueError(
            f"No existe {pk}/{sk}"
        )

    if item.get("activo") is False:
        raise ValueError(
            f"{pk}/{sk} esta inactiva"
        )

    return item


def require_contract_value(
    item,
    attribute,
    pk,
    sk,
):
    if (
        attribute not in item
        or item.get(attribute) is None
    ):
        raise ValueError(
            f"{pk}/{sk} no contiene "
            f"{attribute}"
        )

    return copy.deepcopy(
        item[attribute]
    )


def build_validation_config(
    meta,
    general,
    config,
):
    pk = meta["pk"]
    sk = "VALIDACION"

    result = {
        "nombre_caso": general["nombreCaso"],
        "parametros_extraccion":
            require_contract_value(
                config,
                "parametrosExtraccion",
                pk,
                sk,
            ),
        "salida":
            require_contract_value(
                config,
                "salida",
                pk,
                sk,
            ),
        "datasets":
            require_contract_value(
                config,
                "datasets",
                pk,
                sk,
            ),
    }

    optional = (
        (
            "datasetsNoDisponibles",
            "datasets_no_disponibles",
        ),
        (
            "politicaDatasetsNoDisponibles",
            "politica_datasets_no_disponibles",
        ),
        (
            "origenEsquemaReglas",
            "origen_esquema_reglas",
        ),
        (
            "reglaNulabilidadGenerada",
            "regla_nulabilidad_generada",
        ),
        (
            "reglasCompartidasReutilizadasDesde",
            "reglas_compartidas_reutilizadas_desde",
        ),
        (
            "totalDatasetsParametros",
            "total_datasets_parametros",
        ),
        (
            "totalDatasetsValidables",
            "total_datasets_validables",
        ),
        (
            "totalDatasetsNoDisponibles",
            "total_datasets_no_disponibles",
        ),
        (
            "lecturaRecursivaLotes",
            "lectura_recursiva_lotes",
        ),
    )

    for source, target in optional:
        if source in config:
            result[target] = copy.deepcopy(
                config[source]
            )

    return json_compatible(result)


def build_remediation_config(
    meta,
    config,
):
    pk = meta["pk"]
    sk = "REMEDIACION"
    arguments = config.get(
        "argumentosJob",
        {},
    )

    result = {
        "codigo_malla": (
            config.get("codigoMalla")
            or meta["code"]
        ),
        "job_name": require_contract_value(
            config,
            "jobName",
            pk,
            sk,
        ),
        "modo": require_contract_value(
            config,
            "modoRemediacion",
            pk,
            sk,
        ),
        "consume_config_en_runtime": bool(
            config.get(
                "consumeConfigRemediacion",
                False,
            )
        ),
        "ruta_parametros_extraccion": (
            arguments.get(
                "RUTA_PARAMETROS_EXTRACCION"
            )
        ),
        "ruta_origen_remediacion": (
            arguments.get(
                "RUTA_ORIGEN_REMEDIACION"
            )
        ),
        "ruta_destino_remediacion": (
            arguments.get(
                "RUTA_DESTINO_REMEDIACION"
            )
        ),
        "reglas_transformativas":
            copy.deepcopy(
                config.get(
                    "reglasTransformativas",
                    [],
                )
            ),
        "requiere_reglas_transformativas":
            bool(
                config.get(
                    "requiereReglasTransformativas",
                    False,
                )
            ),
        "funciones": copy.deepcopy(
            config.get(
                "funciones",
                [],
            )
        ),
    }

    return json_compatible(result)


def build_scd_config(
    meta,
    general,
    config,
):
    pk = meta["pk"]
    sk = "SCD"

    result = {
        "nombre_caso": general["nombreCaso"],
        "salida": require_contract_value(
            config,
            "salida",
            pk,
            sk,
        ),
        "llaves": require_contract_value(
            config,
            "llaves",
            pk,
            sk,
        ),
        "columnas_cambio":
            require_contract_value(
                config,
                "columnasCambio",
                pk,
                sk,
            ),
        "columnas_fijas":
            require_contract_value(
                config,
                "columnasFijas",
                pk,
                sk,
            ),
        "columnas_administrativas":
            require_contract_value(
                config,
                "columnasAdministrativas",
                pk,
                sk,
            ),
        "metadatos":
            require_contract_value(
                config,
                "metadatos",
                pk,
                sk,
            ),
        "estructura_gold_ref":
            require_contract_value(
                config,
                "estructuraGoldRef",
                pk,
                sk,
            ),
        "umbral_apagado_pct":
            require_contract_value(
                config,
                "umbralApagadoPct",
                pk,
                sk,
            ),
        "tipo_scd":
            require_contract_value(
                config,
                "tipoSCD",
                pk,
                sk,
            ),
        "modo_escritura":
            require_contract_value(
                config,
                "modoEscritura",
                pk,
                sk,
            ),
        "entrada":
            require_contract_value(
                config,
                "entrada",
                pk,
                sk,
            ),
        "politica_validacion":
            require_contract_value(
                config,
                "politicaValidacion",
                pk,
                sk,
            ),
        "politica_apagado":
            require_contract_value(
                config,
                "politicaApagado",
                pk,
                sk,
            ),
        "argumentos_job":
            require_contract_value(
                config,
                "argumentosJob",
                pk,
                sk,
            ),
    }

    return json_compatible(result)


def publish_contract(
    uri,
    content,
    publicar,
):
    if not publicar:
        return {
            "estado": "VALIDADO",
            "ruta": uri,
            "etag": None,
            "versionId": None,
        }

    bucket, key = s3_parts(uri)

    response = S3.put_object(
        Bucket=bucket,
        Key=key,
        Body=(
            json.dumps(
                json_compatible(content),
                ensure_ascii=False,
                indent=2,
            )
            + "\n"
        ).encode("utf-8"),
        ContentType="application/json",
        Metadata={
            "origen": "dynamodb-cnf",
            "malla": "emisiones",
        },
    )

    return {
        "estado": "PUBLICADO",
        "ruta": uri,
        "etag": response.get(
            "ETag",
            "",
        ).strip('"'),
        "versionId": response.get(
            "VersionId"
        ),
    }


def contract_uri(
    config,
    pk,
    sk,
):
    uri = config.get(
        "archivoActivoUri"
    )

    if not uri:
        raise ValueError(
            f"{pk}/{sk} no contiene "
            "archivoActivoUri"
        )

    s3_parts(uri)
    return uri

def update_effective(meta, effective):
    CNF.update_item(
        Key={"PK": meta["pk"], "SK": "EXTRACCION"},
        UpdateExpression="SET filtrosEfectivos=:f, fechaActualizacion=:a",
        ConditionExpression="versionModelo = :v",
        ExpressionAttributeValues={
            ":f": effective,
            ":a": now_iso(),
            ":v": "EMISIONES_EXTRACCION_V1",
        },
    )


def lambda_handler(event, context):
    event = event if isinstance(event, dict) else {}

    publicar = event.get("publicar", True)
    ejecutar = event.get("ejecutar", False)

    if not isinstance(publicar, bool):
        raise ValueError("publicar debe ser booleano")

    if not isinstance(ejecutar, bool):
        raise ValueError("ejecutar debe ser booleano")

    if ejecutar and not publicar:
        raise ValueError(
            "Para ejecutar Emisiones se requiere publicar=true"
        )

    program = read_program()
    period = str(program.get("periodoNegocio") or "").strip()
    default_start, default_end = month_window(period)
    common_input = program.get("filtrosComunes") or {}
    common = {
        "periodoNegocio": period,
        "fechaInicio": str(common_input.get("fechaInicio") or default_start),
        "fechaFin": str(common_input.get("fechaFin") or default_end),
        "status": [int(v) for v in normalize_list(common_input.get("status"))],
    }
    if common["fechaInicio"] >= common["fechaFin"]:
        raise ValueError("fechaInicio debe ser menor que fechaFin")

    execution_id, lot = execution_identity(program, period)
    mode = str(program.get("modoEjecucion") or "NORMAL").upper()
    active = program.get("casosActivos") or {}
    filters = program.get("filtros") or {}

    filtros_satelites = (
        filters.get("satelites")
        or {}
    )

    core_domain = {
        "productos": (
            normalize_list(
                filtros_satelites.get("productos")
            )
            if active.get("satelites") is True
            else []
        ),
        "companias": [],
    }

    if (
        active.get("satelites") is True
        and not core_domain["productos"]
    ):
        raise ValueError(
            "Emisiones requiere productos textuales "
            "de Satelites para el nucleo comun"
        )

    results = {}
    routes = []
    for case, meta in CASES.items():
        if active.get(case) is not True:
            continue
        extraction = read_cnf(
            meta["pk"],
            "EXTRACCION",
        )
        cycle = read_cnf(
            meta["pk"],
            "CICLO#001",
        )
        general = read_contract(
            meta["pk"],
            "GENERAL",
        )
        validation_row = read_contract(
            meta["pk"],
            "VALIDACION",
        )
        remediation_row = read_contract(
            meta["pk"],
            "REMEDIACION",
        )
        scd_row = read_contract(
            meta["pk"],
            "SCD",
        )
        case_filters = filters.get(case) or {}
        domain = {
            "productos": normalize_list(case_filters.get("productos")),
            "companias": normalize_list(case_filters.get("companias")),
        }
        config = build_config(
            case,
            meta,
            extraction,
            cycle,
            common,
            domain,
            core_domain,
            execution_id,
            lot,
            mode,
        )
        validate_config(case, config)

        # DynamoDB entrega números como Decimal. La
        # configuración publicada debe contener únicamente
        # tipos JSON nativos.
        config = json_compatible(config)

        uri = extraction["archivoActivoUri"]
        response = {}

        if publicar:
            bucket, key = s3_parts(uri)

            response = S3.put_object(
                Bucket=bucket,
                Key=key,
                Body=json.dumps(
                    config,
                    ensure_ascii=False,
                    indent=2,
                ).encode("utf-8"),
                ContentType="application/json",
            )

            effective = {
                "periodoNegocio": period,
                "fechaInicio": common["fechaInicio"],
                "fechaFin": common["fechaFin"],
                "status": [
                    Decimal(str(v))
                    for v in common["status"]
                ],
                "productos": domain["productos"],
                "companias": domain["companias"],
                "aplicarFiltroStatus": bool(
                    common["status"]
                ),
                "aplicarFiltroProductos": bool(
                    domain["productos"]
                ),
                "aplicarFiltroCompanias": bool(
                    domain["companias"]
                ),
                "idEjecucion": execution_id,
                "loteCargueId": Decimal(str(lot)),
                "origen": "PRG",
                "fechaActualizacion": now_iso(),
            }

            update_effective(meta, effective)

        routes.append(uri)

        validation_config = (
            build_validation_config(
                meta,
                general,
                validation_row,
            )
        )

        remediation_config = (
            build_remediation_config(
                meta,
                remediation_row,
            )
        )

        scd_config = build_scd_config(
            meta,
            general,
            scd_row,
        )

        validation_result = publish_contract(
            contract_uri(
                validation_row,
                meta["pk"],
                "VALIDACION",
            ),
            validation_config,
            publicar,
        )

        remediation_result = publish_contract(
            contract_uri(
                remediation_row,
                meta["pk"],
                "REMEDIACION",
            ),
            remediation_config,
            publicar,
        )

        scd_result = publish_contract(
            contract_uri(
                scd_row,
                meta["pk"],
                "SCD",
            ),
            scd_config,
            publicar,
        )

        results[case] = {
            "estado": (
                "PUBLICADO"
                if publicar
                else "VALIDADO"
            ),
            "rutaConfigExtraccion": uri,
            "validacion": validation_result,
            "remediacion": remediation_result,
            "scd": scd_result,
            "etag": (
                response.get("ETag", "")
                .strip('"')
                if publicar
                else None
            ),
            "versionId": (
                response.get("VersionId")
                if publicar
                else None
            ),
            "tablas": (
                sum(
                    len(p["tablas"])
                    for p in config["nucleo_comun"]["fases"]
                )
                + sum(
                    len(s["tablas"])
                    for c in config["ciclos"]
                    for s in c["segmentos"]
                )
            ),
            "fasesRama": [4, 5, 6, 7, 8, 9],
        }

    if not results:
        raise ValueError(
            "PROGRAMACION#EMISIONES no tiene casos activos"
        )

    execution_arn = None

    if ejecutar:
        function_name = os.environ[
            "AWS_LAMBDA_FUNCTION_NAME"
        ]

        suffix = "-configuration-general"

        if not function_name.endswith(suffix):
            raise ValueError(
                "No fue posible resolver el prefijo "
                f"desde {function_name}"
            )

        project_env_prefix = function_name[
            :-len(suffix)
        ]

        region = os.environ["AWS_REGION"]

        account_id = (
            context.invoked_function_arn
            .split(":")[4]
        )

        state_machine_arn = (
            f"arn:aws:states:{region}:"
            f"{account_id}:stateMachine:"
            f"{project_env_prefix}-emisiones"
        )

        step_input = {
            "codigoMalla": "EMISIONES",
            "alcance": "COMPLETO",
            "periodoNegocio": period,
            "idEjecucion": execution_id,
            "loteCargueId": lot,
            "modoEjecucion": mode,
            "fechaInicio": common["fechaInicio"],
            "fechaFin": common["fechaFin"],
            "status": common["status"],
            "casosActivos": active,
            "rutasConfigExtraccion": routes,
            "origen": event.get(
                "origen",
                "CONFIGURADOR",
            ),
        }

        states = boto3.client(
            "stepfunctions",
            region_name=region,
        )

        execution = states.start_execution(
            stateMachineArn=state_machine_arn,
            name=execution_id,
            input=json.dumps(
                json_compatible(step_input),
                ensure_ascii=False,
            ),
        )

        execution_arn = execution[
            "executionArn"
        ]

    return {
        "codigoMalla": "EMISIONES",
        "alcance": "COMPLETO",
        "periodoNegocio": period,
        "idEjecucion": execution_id,
        "loteCargueId": lot,
        "modoEjecucion": mode,
        "fechaInicio": common["fechaInicio"],
        "fechaFin": common["fechaFin"],
        "status": common["status"],
        "casos": results,
        "rutasConfigExtraccion": routes,
        "publicar": publicar,
        "ejecutar": ejecutar,
        "executionArn": execution_arn,
    }
