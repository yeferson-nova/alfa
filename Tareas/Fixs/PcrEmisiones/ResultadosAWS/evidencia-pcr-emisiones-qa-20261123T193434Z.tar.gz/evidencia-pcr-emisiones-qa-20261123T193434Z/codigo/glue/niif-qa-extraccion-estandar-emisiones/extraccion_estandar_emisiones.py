#!/usr/bin/env python3
"""Extractor estandar de Emisiones NIIF"""

import calendar
import html
import json
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
from datetime import datetime, timezone

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.storagelevel import StorageLevel

REGION = os.environ.get(
    "AWS_REGION",
    os.environ.get(
        "AWS_DEFAULT_REGION",
        "us-east-1",
    ),
)



REQUIRED_ARGS = ["JOB_NAME", "RUTAS_CONFIG_EXTRACCION"]
args = getResolvedOptions(sys.argv, REQUIRED_ARGS)

sc = SparkContext.getOrCreate()
glue_context = GlueContext(sc)
spark = glue_context.spark_session
job = Job(glue_context)
job.init(args["JOB_NAME"], args)

s3 = boto3.client("s3")
glue = boto3.client("glue")

SUPPORTED_CASES = {"pcr_vida", "generales", "satelites"}
SUPPORTED_STRATEGIES = {
    "SQL_CONFIGURADA",
    "SQL_CONFIGURADA_UNA_TABLA",
    "DIRECTA",
    "DEPENDENCIA",
}
DEFAULT_COMMON_BRONZE = (
    "s3://alfa-datalake-prd-bronce/niif/ACSELE"
)


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def parse_s3_uri(uri):
    match = re.match(r"^s3://([^/]+)/(.+)$", str(uri))
    if not match:
        raise ValueError(f"URI S3 invalida: {uri}")
    return match.group(1), match.group(2)


def read_json(uri):
    bucket, key = parse_s3_uri(uri)
    body = s3.get_object(Bucket=bucket, Key=key)["Body"].read()
    return json.loads(body.decode("utf-8"))


def write_json(uri, payload):
    bucket, key = parse_s3_uri(uri)
    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"),
        ContentType="application/json",
    )


def s3_exists(uri):
    bucket, key = parse_s3_uri(uri)
    try:
        s3.head_object(Bucket=bucket, Key=key)
        return True
    except Exception as exc:
        code = str(getattr(exc, "response", {}).get("Error", {}).get("Code", ""))
        if code in {"404", "NoSuchKey", "NotFound"}:
            return False
        raise


def month_window(period):
    if not re.fullmatch(r"\d{6}", period):
        raise ValueError(f"periodo_negocio invalido: {period}")
    year, month = int(period[:4]), int(period[4:])
    start = datetime(year, month, 1)
    if month == 12:
        end = datetime(year + 1, 1, 1)
    else:
        end = datetime(year, month + 1, 1)
    return start.strftime("%Y-%m-%d %H:%M:%S"), end.strftime("%Y-%m-%d %H:%M:%S")


def jdbc_options(connection_name):
    connection = glue.get_connection(
        Name=connection_name
    )["Connection"]

    props = connection.get(
        "ConnectionProperties",
        {},
    )

    url = props.get(
        "JDBC_CONNECTION_URL"
    )

    user = props.get("USERNAME")
    password = props.get("PASSWORD")
    secret_id = props.get("SECRET_ID")

    if not url:
        raise ValueError(
            "La Glue Connection "
            + connection_name
            + " no contiene JDBC_CONNECTION_URL"
        )

    if secret_id:
        secret_response = boto3.client(
            "secretsmanager",
            region_name=REGION,
        ).get_secret_value(
            SecretId=secret_id
        )

        secret_text = secret_response.get(
            "SecretString"
        )

        if not secret_text:
            raise ValueError(
                "El secreto de la conexion "
                + connection_name
                + " no contiene SecretString"
            )

        secret = json.loads(secret_text)

        user = (
            secret.get("username")
            or secret.get("user")
        )

        password = (
            secret.get("password")
            or secret.get("passwd")
        )

        if not user or not password:
            raise ValueError(
                "El secreto de la conexion "
                + connection_name
                + " no contiene username/password"
            )

    if not user or not password:
        raise ValueError(
            "La Glue Connection "
            + connection_name
            + " no permite resolver credenciales"
        )

    return {
        "url": url,
        "driver": props.get(
            "JDBC_DRIVER_CLASS_NAME",
            "oracle.jdbc.OracleDriver",
        ),
        "user": user,
        "password": password,
    }


def normalize_sql(text):
    return (
        html.unescape(str(text or ""))
        .replace("{schema}", "{SCHEMA}")
        .replace("\u00a0", " ")
        .strip()
    )


def table_name(table):
    value = table.get("tabla") or str(table.get("tabla_relativa", "")).strip("/").split("/")[-1]
    value = str(value).strip().upper()
    if not value:
        raise ValueError(f"Tabla sin nombre: {table}")
    return value


def table_relative(table):
    return str(table.get("tabla_relativa") or f"acsele_alfa/{table_name(table).lower()}").strip("/").lower()


def flatten_branch_tables(config):
    rows = []
    for cycle in config.get("ciclos", []):
        for segment in cycle.get("segmentos", []):
            for table in segment.get("tablas", []):
                item = deepcopy(table)
                item.setdefault("fase", item.get("orden", 1))
                item.setdefault("modo_fase", segment.get("forma", "CASCADA"))
                rows.append(item)
    return rows


def flatten_core_tables(config):
    rows = []
    for phase in sorted(config.get("nucleo_comun", {}).get("fases", []), key=lambda x: x.get("fase", 0)):
        for table in sorted(phase.get("tablas", []), key=lambda x: x.get("orden", 0)):
            item = deepcopy(table)
            item["fase"] = phase.get("fase", item.get("fase", 1))
            item["modo_fase"] = phase.get("modo", item.get("modo_fase", "CASCADA"))
            rows.append(item)
    return rows


def normalize_config(raw, uri):
    config = deepcopy(raw)
    config["_config_uri"] = uri
    config["nombre_caso"] = str(config.get("nombre_caso", "")).strip().lower()
    config["periodo_negocio"] = str(config.get("periodo_negocio", "")).strip()
    config["id_ejecucion"] = str(config.get("id_ejecucion", "")).strip()
    try:
        config["lote_cargue_id"] = int(config["lote_cargue_id"])
    except Exception as exc:
        raise ValueError(f"{uri}: lote_cargue_id debe ser numerico y efectivo") from exc
    return config


def validate_config(config):
    case = config["nombre_caso"]
    if case not in SUPPORTED_CASES:
        raise ValueError(f"Caso no soportado: {case}")
    if not config["id_ejecucion"]:
        raise ValueError(f"{case}: id_ejecucion obligatorio")
    month_window(config["periodo_negocio"])
    source = config.get("fuente", {})
    if not source.get("connection_name"):
        raise ValueError(f"{case}: fuente.connection_name obligatorio")
    routes = config.get("rutas", {})
    if not routes.get("ruta_parametros_extraccion"):
        raise ValueError(f"{case}: rutas.ruta_parametros_extraccion obligatoria")
    if not routes.get("s3_bronze_base"):
        raise ValueError(f"{case}: rutas.s3_bronze_base obligatoria")
    if not flatten_core_tables(config):
        raise ValueError(f"{case}: nucleo_comun.fases vacio")
    for table in flatten_core_tables(config) + flatten_branch_tables(config):
        strategy = table.get("estrategia_lectura", "SQL_CONFIGURADA")
        if strategy not in SUPPORTED_STRATEGIES:
            raise ValueError(f"{case}/{table_name(table)}: estrategia no soportada {strategy}")
        if strategy in {"SQL_CONFIGURADA", "SQL_CONFIGURADA_UNA_TABLA"} and not table.get("consulta_sql"):
            raise ValueError(f"{case}/{table_name(table)}: consulta_sql obligatoria")
        if strategy == "DEPENDENCIA" and not table.get("dependencias_lectura"):
            raise ValueError(f"{case}/{table_name(table)}: dependencias_lectura obligatoria")


def load_active_configs():
    try:
        uris = json.loads(args["RUTAS_CONFIG_EXTRACCION"])
    except json.JSONDecodeError as exc:
        raise ValueError("RUTAS_CONFIG_EXTRACCION debe ser una lista JSON") from exc
    if not isinstance(uris, list) or not 1 <= len(uris) <= 3:
        raise ValueError("RUTAS_CONFIG_EXTRACCION debe contener entre 1 y 3 rutas")
    configs = [normalize_config(read_json(uri), uri) for uri in uris]
    for config in configs:
        validate_config(config)
    if len({c["nombre_caso"] for c in configs}) != len(configs):
        raise ValueError("Hay casos activos duplicados")
    return configs


def core_signature(config):
    return json.dumps(
        [
            {
                "fase": t.get("fase"),
                "tabla": table_name(t),
                "relativa": table_relative(t),
                "estrategia": t.get("estrategia_lectura"),
                "sql": normalize_sql(t.get("consulta_sql")),
            }
            for t in flatten_core_tables(config)
        ],
        sort_keys=True,
    )


def validate_execution(configs):
    periods = {c["periodo_negocio"] for c in configs}
    lots = {c["lote_cargue_id"] for c in configs}
    executions = {c["id_ejecucion"] for c in configs}
    connections = {c["fuente"]["connection_name"] for c in configs}
    signatures = {core_signature(c) for c in configs}
    structural_signatures = {
        json.dumps(
            [
                {
                    "fase": t.get("fase"),
                    "tabla": table_name(t),
                    "relativa": table_relative(t),
                    "estrategia": t.get("estrategia_lectura"),
                }
                for t in flatten_core_tables(c)
            ],
            sort_keys=True,
        )
        for c in configs
    }
    if len(periods) != 1 or len(lots) != 1 or len(executions) != 1:
        raise ValueError("Los casos activos deben compartir periodo, lote e id_ejecucion")
    if len(connections) != 1:
        raise ValueError(f"Los casos activos usan conexiones diferentes: {connections}")
    if len(structural_signatures) != 1:
        raise ValueError(
            "Los casos activos no contienen la misma estructura de nucleo comun "
            "(fase, tabla, ruta relativa o estrategia)"
        )
    if len(signatures) != 1:
        print(
            json.dumps(
                {
                    "evento": "ADVERTENCIA_NUCLEO_COMUN_SQL_DIFERENTE",
                    "mensaje": (
                        "Los casos activos tienen diferencias en el SQL del nucleo comun. "
                        "Se usara el nucleo del primer caso activo."
                    ),
                    "caso_portador": configs[0]["nombre_caso"],
                    "config_portadora": configs[0]["_config_uri"],
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
    return {
        "periodo_negocio": next(iter(periods)),
        "lote_cargue_id": next(iter(lots)),
        "id_ejecucion": next(iter(executions)),
        "connection_name": next(iter(connections)),
    }


def render_sql(sql, config, start, end):
    schema = config.get("fuente", {}).get("schema", "ACSELE_ALFA")
    replacements = {
        "{SCHEMA}": schema,
        "{START}": start,
        "{END}": end,
        "{START_DATE}": start.strftime("%Y-%m-%d") if hasattr(start, "strftime") else str(start)[:10],
        "{END_DATE}": end.strftime("%Y-%m-%d") if hasattr(end, "strftime") else str(end)[:10],
        "{PERIODO_NEGOCIO}": config["periodo_negocio"],
        "{LOTE_CARGUE_ID}": str(config["lote_cargue_id"]),
        "{ID_EJECUCION}": config["id_ejecucion"],
    }
    rendered = normalize_sql(sql)
    for token, value in replacements.items():
        rendered = rendered.replace(token, str(value))
    return rendered


def oracle_projection(table, alias="T0"):
    columns = table.get("columnas") or []
    if not columns:
        return f"{alias}.*"
    return ", ".join(f"{alias}.{str(column).upper()}" for column in columns)


def dependency_operator(dependencies):
    if len(dependencies) <= 1:
        return "AND"
    destination_sets = [tuple(sorted(m["destino"] for m in dep.get("mapeo", []))) for dep in dependencies]
    return "OR" if len(set(destination_sets)) == 1 else "AND"


def compile_dependency_sql(target, table_map, config, start, end, stack=None):
    stack = list(stack or [])
    target_key = table_relative(target)
    if target_key in stack:
        raise ValueError(f"Dependencia ciclica detectada: {' -> '.join(stack + [target_key])}")
    stack.append(target_key)
    schema = target.get("schema") or config.get("fuente", {}).get("schema", "ACSELE_ALFA")
    alias = "T0"
    predicates = []
    where = normalize_sql(target.get("where"))
    if where:
        predicates.append(where.replace("{ALIAS}", alias))
    dependencies = target.get("dependencias_lectura", [])
    groups = []
    for index, dep in enumerate(dependencies, 1):
        origin_key = str(dep.get("tabla_origen", "")).strip("/").lower()
        origin = table_map.get(origin_key)
        if not origin:
            raise ValueError(f"{target_key}: tabla_origen no configurada: {origin_key}")
        origin_schema = origin.get("schema") or config.get("fuente", {}).get("schema", "ACSELE_ALFA")
        origin_name = table_name(origin)
        origin_alias = f"D{index}"
        mappings = dep.get("mapeo", [])
        if not mappings:
            raise ValueError(f"{target_key}: dependencia sin mapeo hacia {origin_key}")
        correlations = [
            f"{origin_alias}.{m['origen']} = {alias}.{m['destino']}"
            for m in mappings
        ]
        origin_where = normalize_sql(origin.get("where"))
        if origin_where:
            correlations.append(origin_where.replace("{ALIAS}", origin_alias))
        origin_dependencies = origin.get("dependencias_lectura", [])
        if origin_dependencies:
            nested = compile_dependency_predicate(
                origin,
                origin_alias,
                table_map,
                config,
                start,
                end,
                stack,
            )
            if nested:
                correlations.append(nested)
        groups.append(
            "EXISTS (SELECT 1 FROM "
            f"{origin_schema}.{origin_name} {origin_alias} WHERE "
            + " AND ".join(f"({value})" for value in correlations)
            + ")"
        )
    if groups:
        operator = dependency_operator(dependencies)
        predicates.append("(" + f" {operator} ".join(groups) + ")")
    if not predicates:
        predicates.append("1=1")
    parallel = int(target.get("oracle_parallel", 0) or 0)

    if parallel not in {0, 2, 3, 4}:
        raise ValueError(
            f"{target_key}: oracle_parallel no permitido: {parallel}"
        )

    hint = (
        f"/*+ parallel({parallel}) */ "
        if parallel
        else ""
    )

    usar_distinct = target.get(
        "usar_distinct",
        True,
    )

    if not isinstance(usar_distinct, bool):
        raise ValueError(
            f"{target_key}: usar_distinct debe ser booleano"
        )

    distinct = (
        "DISTINCT "
        if usar_distinct
        else ""
    )

    return (
        f"SELECT {hint}{distinct}"
        f"{oracle_projection(target, alias)} "
        f"FROM {schema}.{table_name(target)} {alias} WHERE "
        + " AND ".join(f"({value})" for value in predicates)
    )


def compile_dependency_predicate(target, alias, table_map, config, start, end, stack):
    dependencies = target.get("dependencias_lectura", [])
    groups = []
    for index, dep in enumerate(dependencies, 1):
        origin_key = str(dep.get("tabla_origen", "")).strip("/").lower()
        origin = table_map.get(origin_key)
        if not origin:
            raise ValueError(f"{table_relative(target)}: origen no configurado {origin_key}")
        origin_alias = f"{alias}_D{index}"
        origin_schema = origin.get("schema") or config.get("fuente", {}).get("schema", "ACSELE_ALFA")
        conditions = [
            f"{origin_alias}.{m['origen']} = {alias}.{m['destino']}"
            for m in dep.get("mapeo", [])
        ]
        origin_where = normalize_sql(origin.get("where"))
        if origin_where:
            conditions.append(origin_where.replace("{ALIAS}", origin_alias))
        if origin.get("dependencias_lectura"):
            nested_stack = list(stack) + [table_relative(target)]
            nested = compile_dependency_predicate(
                origin,
                origin_alias,
                table_map,
                config,
                start,
                end,
                nested_stack,
            )
            if nested:
                conditions.append(nested)
        groups.append(
            "EXISTS (SELECT 1 FROM "
            f"{origin_schema}.{table_name(origin)} {origin_alias} WHERE "
            + " AND ".join(f"({value})" for value in conditions)
            + ")"
        )
    if not groups:
        return ""
    return "(" + f" {dependency_operator(dependencies)} ".join(groups) + ")"


def compile_sql(table, table_map, config, start, end):
    strategy = table.get("estrategia_lectura", "SQL_CONFIGURADA")
    if strategy in {"SQL_CONFIGURADA", "SQL_CONFIGURADA_UNA_TABLA"}:
        return render_sql(table["consulta_sql"], config, start, end)
    if strategy == "DEPENDENCIA":
        return render_sql(
            compile_dependency_sql(table, table_map, config, start, end),
            config,
            start,
            end,
        )
    schema = table.get("schema") or config.get("fuente", {}).get("schema", "ACSELE_ALFA")
    alias = "T0"
    where = normalize_sql(table.get("where"))
    clause = "1=1" if not where else where.replace("{ALIAS}", alias)
    return (
        f"SELECT {oracle_projection(table, alias)} "
        f"FROM {schema}.{table_name(table)} {alias} WHERE {clause}"
    )


def strip_oracle_hints(sql):
    return re.sub(r"/\*\+.*?\*/", "", sql, flags=re.S)


def read_oracle(sql, table, jdbc, config):
    sql = strip_oracle_hints(sql)
    source = config.get("fuente", {})
    fetchsize = str(source.get("fetchsize", 20000))
    parallel = table.get("lectura_paralela", {}) or {}
    enabled = bool(parallel.get("habilitada"))
    parts = int(parallel.get("hashpartitions") or parallel.get("numero_particiones") or parallel.get("numPartitions") or 0)
    expression = parallel.get("hashexpression")
    field = parallel.get("hashfield")
    if enabled and parts > 1 and (expression or field):
        options = {
            "useConnectionProperties": "true",
            "connectionName": source["connection_name"],
            "dbtable": f"({sql}) Q",
            "fetchsize": fetchsize,
            "hashpartitions": str(min(parts, 16)),
        }
        if expression:
            match = re.fullmatch(r"(?:[A-Za-z][A-Za-z0-9_]*\.)?([A-Za-z][A-Za-z0-9_]*)", str(expression).strip())
            options["hashexpression"] = match.group(1).upper() if match else str(expression)
        else:
            options["hashfield"] = str(field)
        print(json.dumps({"evento":"JDBC_PARTICIONADA","tabla":table_name(table),"metodo":"GLUE_HASH","particiones":int(options["hashpartitions"])}), flush=True)
        return glue_context.create_dynamic_frame.from_options(
            connection_type=str(source.get("connection_type") or "oracle"),
            connection_options=options,
            transformation_ctx=f"jdbc_{table_name(table).lower()}",
        ).toDF()
    options = dict(jdbc)
    options["dbtable"] = f"({sql}) Q"
    options["fetchsize"] = fetchsize
    column = parallel.get("partitionColumn") or parallel.get("columna_particion")
    lower = parallel.get("lowerBound") or parallel.get("limite_inferior")
    upper = parallel.get("upperBound") or parallel.get("limite_superior")
    if enabled and parts > 1 and column and lower is not None and upper is not None:
        options.update({"partitionColumn":str(column),"lowerBound":str(lower),"upperBound":str(upper),"numPartitions":str(min(parts,16))})
    return spark.read.format("jdbc").options(**options).load()

def common_bronze_base(config):
    return config.get("rutas", {}).get("s3_bronze_comun") or DEFAULT_COMMON_BRONZE


def output_path(config, table, common=False):
    root = common_bronze_base(config) if common else config["rutas"]["s3_bronze_base"]
    base = (
        root.rstrip("/")
        + "/"
        + table_relative(table)
        + f"/periodo_negocio={config['periodo_negocio']}"
        + f"/lote_cargue_id={config['lote_cargue_id']}"
    )
    if not common:
        base += f"/caso_uso={config['nombre_caso']}"
    return base


def silver_destination(config, table):
    relative = table_relative(table)
    explicit = table.get("ruta_dataset_destino")
    if explicit:
        return str(explicit).rstrip("/") + "/"
    routes = config.get("rutas", {})
    base = routes.get("s3_silver_base") or routes.get("s3_silver_base_path") or routes.get("s3_silver_destino")
    if base:
        return base.rstrip("/") + "/" + relative + "/"
    bronze = config["rutas"]["s3_bronze_base"].rstrip("/")
    return bronze.replace("alfa-datalake-qa-bronce", "alfa-datalake-qa-silver") + "/" + relative + "/"


def checkpoint_uri(destination):
    return destination.rstrip("/") + "/_control/_SUCCESS.json"


def optional_table_result(table, config, destination, reason):
    return {
        "tabla_relativa": table_relative(table),
        "estado": "SKIPPED_NOT_AVAILABLE",
        "ruta_dataset_origen": destination.rstrip("/") + "/data/",
        "ruta_dataset_destino": silver_destination(config, table),
        "lote_cargue_id_dataset": config["lote_cargue_id"],
        "datos_nuevos": False,
        "total_registros": 0,
        "registros_excluidos_por_segmento": 0,
        "segmentacion_horizontal": table.get("segmentacion_horizontal") or {},
        "motivo": reason,
    }


def extract_table(table, config, table_map, jdbc, start, end, common=False):
    destination = output_path(config, table, common=common)
    checkpoint = checkpoint_uri(destination)
    control = config.get("control_extraccion", {})
    if control.get("permitir_reanudacion", True) and s3_exists(checkpoint):
        previous = read_json(checkpoint)
        previous["estado"] = "REUSED"
        previous["datos_nuevos"] = False
        return previous
    sql = compile_sql(table, table_map, config, start, end)
    unresolved = sorted(set(re.findall(r"\{[A-Z0-9_]+\}", sql)))
    if unresolved:
        raise ValueError(f"{table_relative(table)}: marcadores SQL sin resolver: {unresolved}")
    try:
        dataframe = read_oracle(sql, table, jdbc, config)
    except Exception as exc:
        availability = table.get("disponibilidad", {})
        allowed = [
            str(code)
            for code in (
                availability.get("errores_permitidos")
                or availability.get("codigos_permitidos")
                or []
            )
        ]
        if (
            not availability.get("obligatoria", True)
            and allowed
            and any(code in str(exc) for code in allowed)
        ):
            result = optional_table_result(table, config, destination, str(exc))
            write_json(checkpoint, result)
            return result
        raise
    keys = [key for key in table.get("deduplicar_por", []) if key in dataframe.columns]
    if keys:
        dataframe = dataframe.dropDuplicates(keys)
    dataframe = (
        dataframe
        .withColumn("periodo_negocio", F.lit(config["periodo_negocio"]))
        .withColumn("id_ejecucion", F.lit(config["id_ejecucion"]))
        .withColumn("lote_cargue_id", F.lit(config["lote_cargue_id"]).cast("long"))
    )
    if not common:
        dataframe = dataframe.withColumn("caso_uso", F.lit(config["nombre_caso"]))
    count_rows = bool(
        control.get(
            "contar_registros",
            True,
        )
    )

    ruta_data = (
        destination.rstrip("/")
        + "/data/"
    )

    inicio_escritura = utc_now()

    (
        dataframe.write
        .mode("overwrite")
        .format("parquet")
        .option(
            "compression",
            "snappy",
        )
        .save(ruta_data)
    )

    fin_escritura = utc_now()

    inicio_conteo = utc_now()

    row_count = (
        spark.read
        .parquet(ruta_data)
        .selectExpr("1 AS registro")
        .count()
        if count_rows
        else None
    )

    fin_conteo = utc_now()

    result = {
        "tabla_relativa": table_relative(table),
        "estado": "COMPLETE",
        "origen_compartido": bool(common),
        "ruta_dataset_origen": ruta_data,
        "ruta_dataset_destino": silver_destination(config, table),
        "lote_cargue_id_dataset": config["lote_cargue_id"],
        "datos_nuevos": True,
        "total_registros": row_count,
        "registros_excluidos_por_segmento": 0,
        "segmentacion_horizontal": table.get("segmentacion_horizontal") or {},
        "fecha_inicio_conteo": inicio_conteo,
        "fecha_fin_conteo": fin_conteo,
        "fecha_inicio_escritura": inicio_escritura,
        "fecha_fin_escritura": fin_escritura,
        "nivel_persistencia": "NINGUNO",
        "modo_conteo": (
            "POST_ESCRITURA_S3"
            if count_rows
            else "NO_CONTAR"
        ),
        "origen_conteo": (
            "PARQUET_S3"
            if count_rows
            else None
        ),
        "fecha_fin": utc_now(),
    }
    write_json(checkpoint, result)
    return result


def table_map_for(config):
    mapping = {}
    for table in flatten_core_tables(config) + flatten_branch_tables(config):
        mapping[table_relative(table)] = table
    return mapping


def execute_phases(tables, config, table_map, jdbc, start, end, common=False):
    results = []
    phases = sorted({int(t.get("fase", t.get("orden", 1))) for t in tables})
    maximum = max(1, min(int(config.get("control_extraccion", {}).get("max_concurrencia_jdbc", 3) or 3), 3))
    for phase in phases:
        targets = [t for t in tables if int(t.get("fase", t.get("orden", 1))) == phase]
        mode = str(targets[0].get("modo_fase", "CASCADA")).upper() if targets else "CASCADA"
        workers = min(maximum, len(targets)) if mode in {"PARALELO", "PARALLEL"} else 1
        print(json.dumps({"evento":"FASE_INICIO","caso":config["nombre_caso"],"fase":phase,"modo":mode,"concurrencia_jdbc":workers,"tablas":[table_name(t) for t in targets]}), flush=True)
        if workers == 1:
            for table in targets:
                result = extract_table(table, config, table_map, jdbc, start, end, common=common)
                results.append(result)
                print(json.dumps({"evento":"TABLA_FIN","caso":config["nombre_caso"],**result},ensure_ascii=False),flush=True)
            continue
        ordered = {}
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(extract_table,t,config,table_map,jdbc,start,end,common):(i,t) for i,t in enumerate(targets)}
            for future in as_completed(futures):
                index, table = futures[future]
                ordered[index] = future.result()
                print(json.dumps({"evento":"TABLA_FIN","caso":config["nombre_caso"],**ordered[index]},ensure_ascii=False),flush=True)
        results.extend(ordered[i] for i in sorted(ordered))
    return results

def runtime_for(config, core_results, branch_results):
    common = []
    for source in core_results:
        item = deepcopy(source)
        item["origen_compartido"] = True
        item["ruta_dataset_destino"] = silver_destination(
            config,
            {"tabla_relativa": item["tabla_relativa"]},
        )
        common.append(item)
    datasets = common + branch_results
    expected = {table_relative(t) for t in flatten_core_tables(config) + flatten_branch_tables(config)}
    manifested = {str(d.get("tabla_relativa", "")).strip("/").lower() for d in datasets}
    missing = sorted(expected - manifested)
    if missing:
        raise ValueError(f"{config['nombre_caso']}: no se publica parametros_extraccion.json; faltan tablas: {missing}")
    quality = "INCOMPLETA" if any(d.get("estado") == "SKIPPED_NOT_AVAILABLE" for d in datasets) else "COMPLETA"
    return {
        "id_ejecucion": config["id_ejecucion"],
        "nombre_caso": config["nombre_caso"],
        "caso_uso": config["nombre_caso"],
        "periodo_negocio": config["periodo_negocio"],
        "lote_cargue_id": config["lote_cargue_id"],
        "estado_extraccion": "SUCCESS",
        "calidad_fuentes": quality,
        "fecha_fin": utc_now(),
        "configuracion": config["_config_uri"],
        "datasets_extraidos": datasets,
    }


def main():
    configs = load_active_configs()
    execution = validate_execution(configs)
    start, end = month_window(execution["periodo_negocio"])
    jdbc = jdbc_options(execution["connection_name"])
    print(json.dumps({"evento": "EMISIONES_INICIO", "id_ejecucion": execution["id_ejecucion"], "periodo_negocio": execution["periodo_negocio"], "lote_cargue_id": execution["lote_cargue_id"], "casos_activos": [c["nombre_caso"] for c in configs]}), flush=True)

    carrier = deepcopy(configs[0])
    carrier["nombre_caso"] = "emisiones_comun"
    carrier_map = table_map_for(configs[0])
    core_results = execute_phases(
        flatten_core_tables(configs[0]), carrier, carrier_map, jdbc, start, end, common=True
    )

    runtime_summary = []
    for config in configs:
        mapping = table_map_for(config)
        branch_results = execute_phases(
            flatten_branch_tables(config), config, mapping, jdbc, start, end, common=False
        )
        runtime = runtime_for(config, core_results, branch_results)
        runtime_uri = config["rutas"]["ruta_parametros_extraccion"]
        write_json(runtime_uri, runtime)
        runtime_summary.append({
            "caso": config["nombre_caso"],
            "runtime": runtime_uri,
            "datasets": len(runtime["datasets_extraidos"]),
            "estado": "SUCCESS",
        })
        print(json.dumps({"evento": "CASO_EXTRACCION_OK", **runtime}, ensure_ascii=False), flush=True)

    print(json.dumps({"evento": "EMISIONES_EXTRACCION_OK", "id_ejecucion": execution["id_ejecucion"], "periodo_negocio": execution["periodo_negocio"], "lote_cargue_id": execution["lote_cargue_id"], "runtimes": runtime_summary}, ensure_ascii=False), flush=True)
    job.commit()


if __name__ == "__main__":
    main()
