#!/usr/bin/env python3
"""Preparacion Silver de PCR Vida usando exclusivamente PySpark DataFrame API."""

import json
import re
import sys
import uuid
from datetime import datetime

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark import StorageLevel
from pyspark.context import SparkContext
from pyspark.sql import DataFrame, functions as F
from pyspark.sql.window import Window

CASO = "pcr_vida"
PRODUCT_ID = 48897
COMPANY_VALUE = "50.0"


def s3_json(uri):
    match = re.match(r"^s3://([^/]+)/(.+)$", uri or "")
    if not match:
        raise ValueError(f"Ruta S3 invalida: {uri}")
    body = boto3.client("s3").get_object(
        Bucket=match.group(1), Key=match.group(2)
    )["Body"].read()
    return json.loads(body)


def source_name(item):
    value = item.get("tabla_relativa") or item.get("tabla") or ""
    return re.sub(r"[^A-Za-z0-9_]", "_", value.rstrip("/").split("/")[-1]).lower()


def source_path(item, capa):
    keys = (
        ["ruta_dataset_destino", "ruta_destino", "ruta_dataset_origen", "ruta_origen"]
        if capa == "SILVER"
        else ["ruta_dataset_origen", "ruta_origen", "s3_path", "ruta"]
    )
    return next((item.get(key) for key in keys if item.get(key)), None)


def register_sources(spark, runtime, capa):
    datasets = runtime.get("datasets_extraidos") or runtime.get("datasets") or []
    if not datasets:
        raise ValueError("El runtime no contiene datasets_extraidos/datasets")

    cache = []
    for item in datasets:
        name = source_name(item)
        if not name:
            continue
        state = str(item.get("estado") or item.get("status") or "").upper()
        path = source_path(item, capa)
        if state in {"FAILED", "ERROR"}:
            raise ValueError(f"Dataset fallido: {name}")
        if not path or state in {"SKIPPED_NOT_AVAILABLE", "NOT_AVAILABLE"}:
            continue

        frame = spark.read.parquet(path)
        frame = frame.toDF(*[column.lower() for column in frame.columns])
        lots = (
            item.get("lotes_preparacion_silver")
            or item.get("lotes_segmento")
            or [item.get("lote_cargue_id_dataset")]
            or [runtime.get("lote_cargue_id")]
        )
        lots = [int(value) for value in lots if value is not None]
        if "lote_cargue_id" in frame.columns and lots:
            frame = frame.filter(F.col("lote_cargue_id").isin(lots))
        frame.createOrReplaceTempView(name)
        cache.append(frame.persist(StorageLevel.MEMORY_AND_DISK))

    return cache


def table(spark, name):
    return spark.table(name)


def with_period_filter(frame, column, start, end):
    if column not in frame.columns:
        return frame
    return frame.filter((F.col(column) >= F.to_timestamp(F.lit(start))) &
                        (F.col(column) < F.to_timestamp(F.lit(end))))


def build_base(spark, runtime):
    start = runtime.get("ventana_extraccion", {}).get("fecha_inicio")
    end = runtime.get("ventana_extraccion", {}).get("fecha_fin")

    context = table(spark, "contextoperation")
    if start and end:
        context = with_period_filter(context, "time_stamp", start, end)
    statuses = runtime.get("filtros_efectivos", {}).get("status") or [2]
    context = context.filter(F.col("status").isin(statuses))

    policy = table(spark, "policydco")
    policy = policy.join(
        context.select(F.col("id").alias("context_id"),
                       F.col("time_stamp").alias("context_time_stamp"),
                       F.col("status").alias("context_status")),
        policy.operationpk == F.col("context_id"),
        "inner",
    ).drop("context_id")

    aggregated = table(spark, "agregatedpolicy").filter(
        F.col("productid") == F.lit(PRODUCT_ID)
    )
    prepolicy = table(spark, "prepolicy")
    event = table(spark, "eventdco")
    risk = table(spark, "riskunitdco")
    preproduct = table(spark, "preproduct").filter(
        (F.col("static") == F.lit(PRODUCT_ID)) &
        (F.col("companiavalue").cast("string") == F.lit(COMPANY_VALUE))
    )
    product = table(spark, "product").filter(F.col("productid") == PRODUCT_ID)
    event_type = table(spark, "eventtype").alias("evt")

    base = (
        policy.alias("pd")
        .join(aggregated.alias("ap"),
              F.col("pd.agregatedobjectid") == F.col("ap.agregatedpolicyid"),
              "inner")
        .join(prepolicy.alias("pp"),
              F.col("pd.dcoid") == F.col("pp.pk"),
              "inner")
        .join(event.alias("ev"),
              (F.col("pd.operationpk") == F.col("ev.operationpk")) &
              (F.col("pd.iddcoevent") == F.col("ev.iddcoevent")),
              "inner")
        .join(risk.alias("ru"),
              F.col("pd.operationpk") == F.col("ru.operationpk"),
              "inner")
        .join(
            event_type,
            F.col("ev.eventtypeid") == F.col("evt.eventtypeid"),
            "left",
        )
        .join(preproduct.alias("prp"),
              F.col("ap.productid") == F.col("prp.static"),
              "inner")
        .join(product.alias("prd"),
              F.col("prp.static") == F.col("prd.productid"),
              "inner")
        .select(
            F.col("pd.operationpk").alias("nro_operacion"),
            F.col("pd.dcoid").alias("id_prepoliza"),
            F.col("pd.iddcoevent").alias("id_evento_dco"),
            F.col("pd.initialdate").alias("fecha_inicial_pol"),
            F.col("pd.finishdate").alias("fecha_final_pol"),
            F.col("pd.event").alias("evento_policydco"),
            F.col("pd.context_time_stamp").alias("fecha_emision"),
            F.col("pd.context_status").alias("estado_poliza"),
            F.col("ap.agregatedpolicyid").alias("idpoliza"),
            F.col("ap.productid").alias("idproducto"),
            F.col("pp.pk").alias("prepolicy_pk"),
            F.col("pp.static").alias("prepolicy_static"),
            F.col("pp.oficinavalue").alias("codigo_sucursal"),
            F.col("pp.oficinainput").alias("sucursal"),
            F.col("pp.tipopolizainput").alias("tipo_poliza"),
            F.col("pp.numeropolizainput").alias("nro_poliza"),
            F.col("pp.monedainput").alias("moneda_acuerdo"),
            F.col("pp.frecuenciapagoinput").alias("frecuencia_pago"),
            F.col("ev.eventtypeid").alias("id_tipo_evento"),
            F.coalesce(
                F.col("evt.description"),
                F.col("pd.event"),
            ).alias("descripcion_evento"),
            F.col("ru.dcoid").alias("risk_dcoid"),
            F.col("ru.agregatedobjectid").alias("unidad_riesgo"),
            F.col("ru.initialdate").alias("fecha_inicial_ur"),
            F.col("ru.finishdate").alias("fecha_final_ur"),
            F.col("prp.companiavalue").alias("codigo_compania"),
            F.col("prp.companiainput").alias("compania"),
            F.col("prp.static").alias("codigo_producto"),
            F.col("prp.descripcionproductoinput").alias("producto"),
            F.col("prp.ramovalue").alias("codigo_ramo"),
            F.col("prp.ramoinput").alias("ramo"),
            F.col("prd.description").alias("producto_del_acuerdo"),
        )
    )
    return base


def add_agreements(spark, base):
    relation = table(spark, "stps_relationagreementpolicy").alias("rel")
    agreement = table(spark, "stps_agreementstaticdat").alias("ast")
    versions = table(spark, "stag_agreementversion").alias("ver")
    preagreement = table(spark, "preagreement").alias("pag")

    candidates = (
        base.alias("b")
        .join(relation,
              F.col("b.prepolicy_static") == F.col("rel.rsa_policyid"), "inner")
        .join(agreement, F.col("rel.rsa_ast_id") == F.col("ast.ast_id"), "inner")
        .join(versions,
              (F.col("ver.ast_id") == F.col("ast.ast_id")) &
              (F.col("ver.ast_fecini") <= F.col("b.fecha_inicial_ur")) &
              (F.col("ver.ast_fecfin") >= F.col("b.fecha_inicial_ur")),
              "inner")
        .join(preagreement, F.col("ver.dcoid") == F.col("pag.pk"), "left")
        .select(
            F.col("b.*"),
            F.col("rel.rsa_ast_id").alias("idacuerdo"),
            F.col("rel.rsa_policyid").alias("rsa_policyid"),
            F.col("ast.ast_numeroacu").alias("acuerdo"),
            F.col("ast.ast_nombreacu").alias("nombre_acuerdo"),
            F.col("ver.ast_fecini").alias("fechaini_acuerdo"),
            F.col("ver.ast_fecfin").alias("fechafin_acuerdo"),
            F.col("ver.description").alias("linea_credito"),
            F.col("ver.dcoid").alias("agreement_dcoid"),
            F.col("pag.tipoproduccioninput").alias("tipo_produccion"),
            F.col("pag.unidadnegocioinput").alias("unidad_negocio"),
            F.col("pag.unidadnegociovalue").alias("codigo_unidad_negocio"),
            F.col("pag.lineacreditoinput").alias("linea_credito_nego"),
            F.row_number().over(
                Window.partitionBy("b.idpoliza", "b.nro_operacion", "b.unidad_riesgo")
                .orderBy(F.col("ver.ast_fecini").desc(),
                         F.col("ver.ast_fecfin").desc(),
                         F.col("ast.ast_id").desc(),
                         F.col("ver.dcoid").desc())
            ).alias("_rn"),
        )
        .filter(F.col("_rn") == 1)
        .drop("_rn")
    )
    acuerdos = candidates.select(
        "idpoliza",
        "nro_operacion",
        "unidad_riesgo",
        "idacuerdo",
        "rsa_policyid",
        "acuerdo",
        "nombre_acuerdo",
        "fechaini_acuerdo",
        "fechafin_acuerdo",
        "linea_credito",
        "agreement_dcoid",
        "tipo_produccion",
        "unidad_negocio",
        "codigo_unidad_negocio",
        "linea_credito_nego",
    )

    return base.join(
        acuerdos,
        ["idpoliza", "nro_operacion", "unidad_riesgo"],
        "left",
    )


def add_debtors(spark, base):
    objects = table(spark, "insuranceobjectdco").filter(F.col("status") == 1)
    minimum = (
        objects.groupBy("agregatedparentid", "operationpk")
        .agg(F.min("agregatedobjectid").alias("minimum_object_id"))
    )
    minimum_object = (
        objects.alias("obj")
        .join(
            minimum.alias("min_obj"),
            (F.col("obj.agregatedparentid") == F.col("min_obj.agregatedparentid")) &
            (F.col("obj.operationpk") == F.col("min_obj.operationpk")) &
            (F.col("obj.agregatedobjectid") == F.col("min_obj.minimum_object_id")),
            "inner",
        )
        .select(
            F.col("min_obj.agregatedparentid"),
            F.col("min_obj.operationpk"),
            F.col("min_obj.minimum_object_id"),
            F.col("obj.dcoid").alias("minimum_object_dcoid"),
        )
    )
    debtors = table(spark, "oavdeudores").alias("deb")
    risk_debtors = table(spark, "urvdeudores").alias("urv")

    return (
        base.join(minimum_object,
                  (base.unidad_riesgo == minimum_object.agregatedparentid) &
                  (base.nro_operacion == minimum_object.operationpk),
                  "inner")
        .join(
            debtors,
            F.col("minimum_object_dcoid") == F.col("deb.pk"),
            "inner",
        )
        .join(
            risk_debtors,
            F.col("risk_dcoid") == F.col("urv.pk"),
            "left",
        )
        .select(
            base["*"],
            F.col("deb.edadvalue").alias("edad_asegurado"),
            F.col("deb.fechanacimientoaseginput").alias("fecha_nacimiento_asegurado"),
            F.col("deb.direccionaseguradoinput").alias("direccion_asegurado"),
            F.col("deb.departamentoinput").alias("departamento_asegurado"),
            F.col("deb.departamentovalue").alias("codigo_departamento"),
            F.col("deb.ciudadinput").alias("ciudad_asegurado"),
            F.col("deb.ciudadvalue").alias("codigo_ciudad"),
            F.col("deb.factorvidavalue").alias("factor_vida"),
            F.col("urv.numerocreditoinput").alias("numero_credito"),
            F.col("urv.fechadesembolsoinput").alias("fecha_desembolso"),
        )
    )


def add_participants(spark, base):
    policy_part = table(spark, "stpo_policyparticipation").alias("part")
    policy_dco = table(spark, "stpo_policyparticipationdco").alias("partdco")
    roles = table(spark, "stts_role").alias("role")
    people = table(spark, "prethirdparty").alias("person")

    participants = (
        policy_part.join(
            policy_dco,
            F.col("part.agregatedobjectid") == F.col("partdco.agregatedobjectid"),
            "inner",
        )
        .join(roles, F.col("part.rol_id") == F.col("role.rol_id"), "inner")
        .join(people, F.col("part.thirdpartyid") == F.col("person.static"), "inner")
        .select(
            F.col("part.agregatedparentid").alias("idpoliza"),
            F.col("partdco.status").alias("participant_status"),
            F.upper(F.col("role.rol_description")).alias("role_name"),
            F.col("person.documentoidentidadinput").alias("documento"),
            F.col("person.nombrepredeterminadoinput").alias("nombre"),
        )
    )

    grouped = participants.groupBy("idpoliza").agg(
        F.max(
            F.when(
                F.col("role_name").like("%TOMADOR%"),
                F.col("documento"),
            )
        ).alias("identificacion_tomador"),
        F.max(
            F.when(
                F.col("role_name").like("%TOMADOR%"),
                F.col("nombre"),
            )
        ).alias("tomador"),
        F.max(
            F.when(
                F.col("role_name").like("%AGENTE%"),
                F.col("nombre"),
            )
        ).alias("agente"),
        F.max(
            F.when(
                F.col("role_name").like("%MAESTRO%")
                & (F.col("participant_status") == 1),
                F.concat_ws("-", "documento", "nombre"),
            )
        ).alias("pagador_maestro"),
    )

    object_part_dco = (
        table(spark, "stpo_insobjparticipationdco")
        .alias("objdco")
    )
    object_part = (
        table(spark, "stpo_insobjparticipation")
        .alias("objpart")
    )

    insured = (
        object_part_dco
        .filter(F.col("objdco.status") == 1)
        .join(
            object_part,
            F.col("objdco.agregatedobjectid")
            == F.col("objpart.agregatedobjectid"),
            "inner",
        )
        .join(
            roles,
            F.col("objpart.rol_id") == F.col("role.rol_id"),
            "inner",
        )
        .join(
            people,
            F.col("objpart.thirdpartyid")
            == F.col("person.static"),
            "inner",
        )
        .filter(
            F.upper(F.col("role.rol_description"))
            .like("%ASEGURADO%")
        )
        .groupBy(
            F.col("objdco.operationpk").alias(
                "nro_operacion"
            )
        )
        .agg(
            F.max(
                F.col("person.nombrepredeterminadoinput")
            ).alias("asegurado"),
            F.max(
                F.col("person.documentoidentidadinput")
            ).alias("identificacion_asegurado"),
            F.max(
                F.col("person.tipodocumentoinput")
            ).alias("tipo_identificacion_asegurado"),
        )
    )

    return (
        base
        .join(grouped, "idpoliza", "left")
        .join(insured, "nro_operacion", "left")
    )


def add_movements(spark, base):
    movements = table(spark, "thirdpartymovementpolicy").filter(F.col("ammount") != 0)
    movements = movements.withColumn("concept_u", F.upper(F.col("concept")))
    grouped = movements.groupBy("operationpk").agg(
        F.sum(F.when(F.col("concept_u").isin(
            "PRIMADEVUELTA", "PRIMAANU", "PRIMAANUIND",
            "PRIMADEVUELTAIND", "PRIMAEMITIDADEV",
            "PRIMAEMITIDAANUVIDAAP", "PRIMAEMITIDAPAGDEVVIDAAP"),
            -F.col("ammount")).when(F.col("concept_u").isin(
            "PRIMAEMITIDA", "PRIMAREHAB", "PRIMAREHABIND",
            "PRIMAPERIODOPROVIS", "PRIMAEMITIDAIND",
            "PRIMAPERIODOPROVISIND", "PRIMAEMITIDAVIDAAP",
            "PRIMAEMITIDAPAGVIDAAP"), F.col("ammount"))).alias("prima"),
        F.sum(F.when(F.col("concept_u").isin(
            "COSTORECAUDACIONDEV", "COSTORECAUDACIONDEVIND",
            "COSTORECAUDOANU", "COSTORECAUDOANUIND",
            "COSTORECAUDACIONANUVIDAAP", "COSTORECAUDACIONDEVVIDAAP"),
            -F.col("ammount")).when(F.col("concept_u").isin(
            "COSTORECAUDACION", "COSTORECAUDACIONIND",
            "COSTORECAUDOPROVIS", "COSTORECAUDOPROVISIND",
            "COSTORECAUDOREHAB", "COSTORECAUDOREHABIND",
            "COSTORECAUDACIONREHABVIDAAP", "COSTORECAUDACIONVIDAAP",
            "COSTORECAUDACIONPAGVIDAAP"), F.col("ammount"))).alias("costo_recaudo"),
        F.sum(F.when(F.col("concept_u").isin(
            "IVACOSTORECAUDACIONDEV", "IVACOSTORECAUDACIONDEVIND",
            "IVACOSTORECAUDOANU", "IVACOSTORECAUDOANUIND",
            "IVACOSTORECAUDACIONDEVVIDAAP", "IVACOSTORECAUDACIONANUVIDAAP"),
            -F.col("ammount")).when(F.col("concept_u").isin(
            "IVACOSTORECAUDACION", "IVACOSTORECAUDACIONIND",
            "IVACOSTORECAUDOPROVIS", "IVACOSTORECAUDOPROVISIND",
            "IVACOSTORECAUDOREHAB", "IVACOSTORECAUDOREHABIND",
            "IVACOSTORECAUDACIONVIDAAP", "IVACOSTORECAUDACIONREHABVIDAAP",
            "IVACOSTORECAUDACIONPAGVIDAAP"), F.col("ammount"))).alias("iva_costo_recaudo"),
        F.sum(F.when(F.col("concept_u").isin(
            "COMISIONVIDADEV", "COMISIONVIDAINDDEV", "COMISIONAGENTEDEV"),
            -F.col("ammount")).when(F.col("concept_u").isin(
            "COMISIONVIDA", "COMISIONVIDAIND", "COMISIONAGENTE"),
            F.col("ammount"))).alias("comision"),
        F.sum(F.when(F.col("concept") == "SumaAsegPeriodo",
                     F.col("ammount"))).alias("valor_asegurado"),
    )
    return base.join(grouped, base.nro_operacion == grouped.operationpk, "inner").drop("operationpk")



def guardar_json(uri, contenido):
    match = re.match(
        r"^s3://([^/]+)/(.+)$",
        uri or "",
    )

    if not match:
        raise ValueError(
            f"Ruta S3 invalida: {uri}"
        )

    boto3.client("s3").put_object(
        Bucket=match.group(1),
        Key=match.group(2),
        Body=(
            json.dumps(
                contenido,
                indent=2,
                ensure_ascii=False,
                default=str,
            )
            + "\n"
        ).encode("utf-8"),
        ContentType="application/json",
    )


def actualizar_runtime(
    ruta_runtime,
    runtime,
    salida,
    total,
):
    fecha = datetime.utcnow().isoformat()

    informe = {
        "estado": "SUCCESS",
        "nombre_caso":
            runtime.get("nombre_caso"),
        "periodo_negocio":
            runtime.get("periodo_negocio"),
        "lote_cargue_id":
            runtime.get("lote_cargue_id"),
        "total_registros":
            int(total),
        "ruta_silver_preparada":
            salida,
        "fecha_preparacion":
            fecha,
    }

    runtime.update({
        "estado_preparacion_silver":
            "SUCCESS",
        "ruta_silver_preparada":
            salida,
        "total_registros_silver_preparada":
            int(total),
        "fecha_preparacion_silver":
            fecha,
        "modo_escritura_silver_preparada":
            "overwrite",
        "silver_preparada_historica":
            False,
        "silver_preparacion":
            informe,
    })

    guardar_json(
        ruta_runtime,
        runtime,
    )

    return informe

def main():
    required = ["JOB_NAME", "RUTA_PARAMETROS_EXTRACCION", "S3_SLV_PREP_PATH"]
    args = getResolvedOptions(sys.argv, required)
    capa = "BRONZE"
    if "--CAPA_ENTRADA" in sys.argv:
        capa = getResolvedOptions(sys.argv, ["CAPA_ENTRADA"])["CAPA_ENTRADA"].upper()

    runtime = s3_json(args["RUTA_PARAMETROS_EXTRACCION"])
    periodo = str(runtime.get("periodo_negocio") or runtime.get("periodoNegocio") or "")
    if not re.fullmatch(r"\d{6}", periodo):
        raise ValueError(f"periodo_negocio invalido: {periodo}")
    job_run_id = str(runtime.get("id_ejecucion") or uuid.uuid4())

    context = SparkContext.getOrCreate()
    glue = GlueContext(context)
    spark = glue.spark_session
    spark.conf.set("spark.sql.caseSensitive", "false")
    spark.conf.set("spark.sql.session.timeZone", "America/Bogota")
    job = Job(glue)
    job.init(args["JOB_NAME"], args)
    cache = register_sources(spark, runtime, capa)

    try:
        frame = build_base(spark, runtime)
        frame = add_agreements(spark, frame)
        frame = add_debtors(spark, frame)
        frame = add_participants(spark, frame)
        frame = add_movements(spark, frame)

        frame = (
            frame
            .withColumn(
                "periodo_operacion",
                F.date_format(F.col("fecha_emision"), "yyyyMM"),
            )
            .withColumn(
                "codigo_divipola_municipio",
                F.concat(
                    F.regexp_replace(
                        F.col("codigo_departamento").cast("string"),
                        r"\.0$",
                        "",
                    ),
                    F.lpad(
                        F.regexp_replace(
                            F.col("codigo_ciudad").cast("string"),
                            r"\.0$",
                            "",
                        ),
                        3,
                        "0",
                    ),
                ),
            )
            .withColumn(
                "fecha_incial_pol",
                F.col("fecha_inicial_pol"),
            )
            .withColumn("pnomaseg", F.col("asegurado"))
            .withColumn(
                "pidentaseg",
                F.col("identificacion_asegurado"),
            )
            .withColumn(
                "ptipidentaseg",
                F.col("tipo_identificacion_asegurado"),
            )
            .withColumn(
                "edad_aseguado",
                F.col("edad_asegurado"),
            )
            .withColumn(
                "fecha_nacer_asegurado",
                F.col("fecha_nacimiento_asegurado"),
            )
            .withColumn(
                "direccion_aseguado",
                F.col("direccion_asegurado"),
            )
            .withColumn(
                "desc_departamento",
                F.col("departamento_asegurado"),
            )
            .withColumn(
                "cod_departamento",
                F.col("codigo_departamento"),
            )
            .withColumn(
                "desc_ciudad",
                F.col("ciudad_asegurado"),
            )
            .withColumn(
                "cod_ciudad",
                F.col("codigo_ciudad"),
            )
            .withColumn("periodo_negocio", F.lit(periodo))
            .withColumn("caso_uso", F.lit(CASO))
            .withColumn("id_ejecucion", F.lit(job_run_id))
            .withColumn("lote_cargue_id", F.lit(runtime.get("lote_cargue_id")).cast("long"))
            .withColumn("fecha_proceso", F.current_timestamp())
        )
        output = args["S3_SLV_PREP_PATH"].rstrip("/") + f"/periodo_negocio={periodo}/"
        frame.write.mode("overwrite").option("compression", "snappy").parquet(output)
        total_registros = frame.count()

        informe = actualizar_runtime(
            args["RUTA_PARAMETROS_EXTRACCION"],
            runtime,
            output,
            total_registros,
        )

        print(json.dumps({
            "estado": "SUCCESS",
            "caso": CASO,
            "periodo_negocio": periodo,
            "ruta_silver_preparada": output,
            "total_registros": total_registros,
            "fecha_preparacion": datetime.utcnow().isoformat(),
        }, ensure_ascii=False))
        job.commit()
    finally:
        for item in cache:
            item.unpersist()


if __name__ == "__main__":
    main()