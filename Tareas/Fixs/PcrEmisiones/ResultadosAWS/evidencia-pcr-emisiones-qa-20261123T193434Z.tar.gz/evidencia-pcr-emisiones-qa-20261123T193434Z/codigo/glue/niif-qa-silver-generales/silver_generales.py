#!/usr/bin/env python3
"""Preparacion Silver de Generales usando exclusivamente PySpark DataFrame API."""

import json
import re
import sys
import uuid
from datetime import datetime

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark import StorageLevel
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.sql.window import Window

CASO = "generales"
PRODUCTS = [55059, 55139, 54959, 52897, 54979, 55099]
COMPANY = "Seguros Alfa S.A."


def read_json(uri):
    match = re.match(r"^s3://([^/]+)/(.+)$", uri or "")
    if not match:
        raise ValueError(f"Ruta S3 invalida: {uri}")
    response = boto3.client("s3").get_object(
        Bucket=match.group(1), Key=match.group(2)
    )
    return json.loads(response["Body"].read())


def name_of(item):
    value = item.get("tabla_relativa") or item.get("tabla") or ""
    return re.sub(r"[^A-Za-z0-9_]", "_", value.rstrip("/").split("/")[-1]).lower()


def path_of(item, capa):
    if capa == "SILVER":
        keys = (
            "ruta_dataset_destino",
            "ruta_destino",
            "ruta_dataset_origen",
            "ruta_origen",
        )
    else:
        keys = (
            "ruta_dataset_origen",
            "ruta_origen",
            "s3_path",
            "ruta",
        )
    return next((item.get(key) for key in keys if item.get(key)), None)



def s3_prefix_exists(uri):
    match = re.match(r"^s3://([^/]+)/(.+)$", uri or "")
    if not match:
        return False

    response = boto3.client("s3").list_objects_v2(
        Bucket=match.group(1),
        Prefix=match.group(2).rstrip("/") + "/",
        MaxKeys=1,
    )
    return int(response.get("KeyCount", 0)) > 0



def load_sources(spark, runtime, capa):
    datasets = runtime.get("datasets_extraidos") or runtime.get("datasets") or []
    if not datasets:
        raise ValueError("El runtime no contiene datasets_extraidos/datasets")

    frames = {}
    cached = []
    for item in datasets:
        name = name_of(item)
        state = str(item.get("estado") or item.get("status") or "").upper()
        path = path_of(item, capa)
        if state in {"FAILED", "ERROR"}:
            raise ValueError(f"Dataset fallido: {name}")
        if not name or not path or state in {"SKIPPED_NOT_AVAILABLE", "NOT_AVAILABLE"}:
            continue

        if not s3_prefix_exists(path):
            print(
                "DATASET_IGNORADO_RUTA_NO_EXISTE | "
                f"tabla={name} | ruta={path} | estado={state}"
            )
            continue

        frame = spark.read.parquet(path)
        frame = frame.toDF(*[column.lower() for column in frame.columns])
        lots = (
            item.get("lotes_preparacion_silver")
            or item.get("lotes_segmento")
            or [item.get("lote_cargue_id_dataset")]
            or [runtime.get("lote_cargue_id")]
        )
        lots = [int(value) for value in lots if value is not None]
        if "lote_cargue_id" in frame.columns and lots:
            frame = frame.filter(F.col("lote_cargue_id").isin(lots))
        frames[name] = frame.persist(StorageLevel.MEMORY_AND_DISK)
        cached.append(frames[name])
    return frames, cached


def required(frames, name):
    if name not in frames:
        raise ValueError(f"Dataset requerido no disponible: {name}")
    return frames[name]


def optional(frames, name):
    return frames.get(name)


def c(frame, name, dtype="string"):
    return F.col(name).cast(dtype) if name in frame.columns else F.lit(None).cast(dtype)


def alias_select(frame, mapping):
    return frame.select(*[c(frame, source, dtype).alias(target)
                          for target, (source, dtype) in mapping.items()])


def base_frame(frames, runtime):
    ctx = required(frames, "contextoperation")
    policy = required(frames, "policydco")
    aggregated = required(frames, "agregatedpolicy")
    prepolicy = required(frames, "prepolicy")
    event = required(frames, "eventdco")
    risk = required(frames, "riskunitdco")
    preproduct = required(frames, "preproduct")
    product = required(frames, "product")
    aggregated_risk = required(frames, "agregatedriskunit")
    prerisk = required(frames, "preriskunits")
    event_type = required(frames, "eventtype")

    window = runtime.get("ventana_extraccion", {})
    start = window.get("fecha_inicio")
    end = window.get("fecha_fin")
    statuses = runtime.get("filtros_efectivos", {}).get("status") or [2]

    ctx = ctx.filter(F.col("status").isin(statuses))
    if start and end and "time_stamp" in ctx.columns:
        ctx = ctx.filter(
            (F.col("time_stamp") >= F.to_timestamp(F.lit(start)))
            & (F.col("time_stamp") < F.to_timestamp(F.lit(end)))
        )

    ctx = ctx.select(
        F.col("id").alias("ctx_id"),
        F.col("time_stamp").alias("ctx_time_stamp"),
        F.col("status").alias("ctx_status"),
    )

    pd = policy.join(ctx, policy.operationpk == ctx.ctx_id, "inner")
    ap = aggregated.filter(F.col("productid").isin(PRODUCTS))
    pp = prepolicy
    ev = event
    ru = risk
    ppd = preproduct.filter(
        (F.col("static").isin(PRODUCTS))
        & (F.col("companiainput") == COMPANY)
    )
    pr = product
    ar = aggregated_risk
    pru = prerisk
    et = event_type.filter(F.col("description") != "ActualizarGeoreferenciacion")

    return (
        pd.join(ap, pd.agregatedobjectid == ap.agregatedpolicyid, "inner")
        .join(pp, pd.dcoid == pp.pk, "inner")
        .join(
            ev,
            (pd.operationpk == ev.operationpk)
            & (pd.iddcoevent == ev.iddcoevent),
            "inner",
        )
        .join(ru, pd.operationpk == ru.operationpk, "inner")
        .join(ppd, ap.productid == ppd.static, "inner")
        .join(pr, ppd.static == pr.productid, "inner")
        .join(
            ar,
            (ap.agregatedpolicyid == ar.agregatedpolicyid)
            & (ru.agregatedobjectid == ar.agregatedriskunitid),
            "inner",
        )
        .join(pru, ru.dcoid == pru.pk, "inner")
        .join(et, ev.eventtypeid == et.eventtypeid, "inner")
        .select(
            ap.agregatedpolicyid.alias("idpoliza"),
            ap.productid.alias("idproducto"),
            ppd.companiavalue.alias("codigo_compania_raw"),
            ppd.companiainput.alias("compania"),
            ppd.codigoproductoinput.alias("codigo_producto"),
            pr.description.alias("producto"),
            ppd.ramovalue.alias("codigo_ramo_raw"),
            ppd.ramoinput.alias("ramo_raw"),
            pp.oficinavalue.alias("codigo_sucursal_raw"),
            pp.oficinainput.alias("sucursal"),
            pp.tipopolizainput.alias("tipo_poliza"),
            pp.numeropolizainput.alias("nro_poliza"),
            pp.monedainput.alias("moneda_acuerdo"),
            pp.frecuenciapagoinput.alias("frecuencia_pago"),
            pp.pk.alias("prplc_pk"),
            pd.operationpk.alias("nro_operacion"),
            pd.dcoid.alias("policy_dcoid"),
            pd.agregatedobjectid.alias("policy_object_id"),
            pd.iddcoevent.alias("event_dco_id"),
            pd.initialdate.alias("fecha_incial_pol"),
            pd.finishdate.alias("fecha_final_pol"),
            pd.event.alias("policy_event"),
            ctx.ctx_time_stamp,
            ctx.ctx_status,
            ev.eventtypeid.alias("event_type_id"),
            et.description.alias("event_description"),
            ru.dcoid.alias("risk_dcoid"),
            ru.agregatedobjectid.alias("risk_id"),
            ru.initialdate.alias("fecha_inicial_ur"),
            ru.finishdate.alias("fecha_final_ur"),
            pru.numunidriesgoinput.alias("unidad_riesgo"),
            ar.agregatedriskunitid.alias("aggregated_risk_id"),
            ppd.static.alias("product_id"),
        )
    )


def add_agreement_and_object(frames, base):
    relation = required(frames, "stps_relationagreementpolicy")
    agreement = required(frames, "stps_agreementstaticdat")
    versions = required(frames, "stag_agreementversion")
    objects = required(frames, "insuranceobjectdco")

    minimum = (
        objects.filter(F.col("status") == 1)
        .groupBy("operationpk", "agregatedparentid")
        .agg(F.min("agregatedobjectid").alias("minimum_object_id"))
    )

    b = (
        base.join(
            relation,
            base.idpoliza == relation.rsa_policyid,
            "inner",
        )
        .join(
            agreement,
            relation.rsa_ast_id == agreement.ast_id,
            "inner",
        )
        .join(
            versions,
            (versions.ast_id == agreement.ast_id)
            & (versions.ast_fecini <= base.fecha_inicial_ur)
            & (versions.ast_fecfin >= base.fecha_inicial_ur),
            "inner",
        )
        .join(
            minimum,
            (base.risk_id == minimum.agregatedparentid)
            & (base.nro_operacion == minimum.operationpk),
            "inner",
        )
    )

    preagreement = optional(frames, "preagreement")
    if preagreement is not None:
        b = b.join(
            preagreement,
            versions.dcoid == preagreement.pk,
            "left",
        )

    return b.select(
        base["*"],
        relation.rsa_ast_id.alias("idacuerdo"),
        agreement.ast_numeroacu.alias("numero_poliza_matriz"),
        agreement.ast_nombreacu.alias("nombre_acuerdo"),
        versions.ast_fecini.alias("fechaini_acuerdo"),
        versions.ast_fecfin.alias("fechafin_acuerdo"),
        versions.status.alias("agreement_status"),
        minimum.minimum_object_id,
        c(preagreement, "tipoproduccioninput").alias("tipo_produccion")
        if preagreement is not None else F.lit(None).alias("tipo_produccion"),
        c(preagreement, "unidadnegociovalue").alias("cod_unidad_negocio")
        if preagreement is not None else F.lit(None).alias("cod_unidad_negocio"),
        c(preagreement, "unidadnegocioinput").alias("unidad_negocio")
        if preagreement is not None else F.lit(None).alias("unidad_negocio"),
        c(preagreement, "lineacreditoinput").alias("linea_credito_pre")
        if preagreement is not None else F.lit(None).alias("linea_credito_pre"),
    )


def participant_aggregates(frames, base):
    pp = required(frames, "stpo_policyparticipation")
    ppd = required(frames, "stpo_policyparticipationdco")
    roles = required(frames, "stts_role")
    people = required(frames, "prethirdparty")

    participants = (
        pp.join(ppd, pp.agregatedobjectid == ppd.agregatedobjectid, "inner")
        .join(roles, pp.rol_id == roles.rol_id, "inner")
        .join(people, pp.thirdpartyid == people.static, "inner")
        .select(
            pp.agregatedparentid.alias("idpoliza"),
            roles.rol_id,
            F.upper(roles.rol_description).alias("role_name"),
            c(people, "documentoidentidadinput").alias("documento"),
            c(people, "nombrepredeterminadoinput").alias("nombre"),
            c(people, "telefonooficinacompletinput").alias(
                "telefonooficinacompletinput"
            ),
            c(people, "emailinput").alias("emailinput"),
        )
    )

    grouped = participants.groupBy("idpoliza").agg(
        F.concat_ws(",", F.collect_list(
            F.when(F.col("rol_id") == 25935, F.col("documento"))
        )).alias("identificacion_tomador"),
        F.concat_ws(",", F.collect_list(
            F.when(F.col("rol_id") == 25935, F.col("nombre"))
        )).alias("tomador"),
        F.concat_ws(",", F.collect_list(
            F.when(F.col("rol_id") == 33935, F.col("documento"))
        )).alias("identifica_pagador_maestro"),
        F.concat_ws(",", F.collect_list(
            F.when(F.col("rol_id") == 33935, F.col("nombre"))
        )).alias("informacion_pagador_maestro"),
        F.concat_ws(",", F.collect_list(
            F.when(F.col("rol_id") == 39937, F.col("documento"))
        )).alias("identificacion_pagador"),
        F.concat_ws(",", F.collect_list(
            F.when(F.col("rol_id") == 39937, F.col("nombre"))
        )).alias("pagador"),
        F.concat_ws(",", F.collect_list(
        F.when(F.col("rol_id") == 25935, F.col("telefonooficinacompletinput"))
        )).alias("telefono_tomador"),
        F.concat_ws(",", F.collect_list(
        F.when(F.col("rol_id") == 25935, F.col("emailinput"))
        )).alias("email_tomador"),
        F.max(
            F.when(F.col("role_name").like("%AGENTE%"), F.col("nombre"))
        ).alias("agente"),
    )
    return base.join(grouped, "idpoliza", "left")


def address_and_agent(frames, base):
    participants = required(frames, "stpo_policyparticipation")
    people = required(frames, "prethirdparty")
    roles = required(frames, "stts_role")
    addresses = optional(frames, "stte_thirdpartyaddressbook")
    third_party = optional(frames, "stte_thirdparty")
    direction = optional(frames, "direccion")

    if addresses is None or third_party is None or direction is None:
        return base.withColumn("departamento_tom", F.lit(None)).withColumn(
            "ciudad_tom", F.lit(None)
        ).withColumn("direcion_tom", F.lit(None))

    address = (
        participants.join(roles, participants.rol_id == roles.rol_id, "inner")
        .join(people, participants.thirdpartyid == people.static, "inner")
        .join(third_party, people.static == third_party.tpt_id, "inner")
        .join(
            addresses,
            (third_party.tpt_id == addresses.tpt_id)
            & (addresses.isdefaultaddress == 1),
            "inner",
        )
        .join(direction, addresses.iddco == direction.pk, "inner")
        .filter(participants.rol_id == 25935)
        .groupBy(participants.agregatedparentid)
        .agg(
            F.max(direction.departamentoinput).alias("departamento_tom"),
            F.max(direction.ciudadinput).alias("ciudad_tom"),
            F.max(direction.direccioninput).alias("direcion_tom"),
        )
        .withColumnRenamed("agregatedparentid", "idpoliza")
    )
    return base.join(address, "idpoliza", "left")


def insured_people(frames, base):
    roles = required(frames, "stts_role")
    people = required(frames, "prethirdparty")
    risk_part_dco = required(frames, "stpo_ruparticipationdco")
    risk_part = required(frames, "stpo_ruparticipation")
    object_part_dco = required(frames, "stpo_insobjparticipationdco")
    object_part = required(frames, "stpo_insobjparticipation")
    product_id = F.col("idproducto")

    risk_people = (
        base.filter(product_id == 54959)
        .join(
            risk_part_dco.filter(F.col("status") == 1),
            F.col("nro_operacion") == risk_part_dco.operationpk,
            "left",
        )
        .join(
            risk_part,
            risk_part_dco.agregatedobjectid
            == risk_part.agregatedobjectid,
            "left",
        )
        .join(roles, risk_part.rol_id == roles.rol_id, "left")
        .join(people, risk_part.thirdpartyid == people.static, "left")
        .filter(roles.rol_description == "AseguradoGenerales")
        .groupBy("nro_operacion")
        .agg(
            F.max(people.tipodocumentoinput).alias("risk_tipo"),
            F.max(people.documentoidentidadinput).alias("risk_documento"),
            F.max(people.nombrepredeterminadoinput).alias("risk_nombre"),
        )
    )

    object_people = (
        base.filter(product_id != 54959)
        .join(
            object_part_dco.filter(F.col("status") == 1),
            F.col("nro_operacion") == object_part_dco.operationpk,
            "left",
        )
        .join(
            object_part,
            object_part_dco.agregatedobjectid
            == object_part.agregatedobjectid,
            "left",
        )
        .join(roles, object_part.rol_id == roles.rol_id, "left")
        .join(people, object_part.thirdpartyid == people.static, "left")
        .filter(roles.rol_description.like("%Asegurado%"))
        .groupBy("nro_operacion")
        .agg(
            F.max(people.tipodocumentoinput).alias("object_tipo"),
            F.max(people.documentoidentidadinput).alias("object_documento"),
            F.max(people.nombrepredeterminadoinput).alias("object_nombre"),
        )
    )

    return (
        base.join(risk_people, "nro_operacion", "left")
        .join(object_people, "nro_operacion", "left")
        .withColumn(
            "tipo_identif_asegurado",
            F.when(F.col("idproducto") == 54959, F.col("risk_tipo"))
            .otherwise(F.col("object_tipo")),
        )
        .withColumn(
            "identif_asegurado",
            F.when(F.col("idproducto") == 54959, F.col("risk_documento"))
            .otherwise(F.col("object_documento")),
        )
        .withColumn(
            "asegurado",
            F.when(F.col("idproducto") == 54959, F.col("risk_nombre"))
            .otherwise(F.col("object_nombre")),
        )
        .drop("risk_tipo", "risk_documento", "risk_nombre",
              "object_tipo", "object_documento", "object_nombre")
    )


def add_attributes(frames, base):
    joins = [
        ("pomihogarseguro", "policy_dcoid", "pk", {
            "idempleadorinput": "identificacion_empleador",
            "empleadorinput": "nombre_empleador",
            "indorigeninput": "origen_dato",
            "operacionmihogarseguroinput": "nro_operacion_factura",
            "tipobienmihogarseguroinput": "hogar_tipo_bien",
        }),
        ("povdeudores", "policy_object_id", "static", {}),
        ("pomascotas", "policy_object_id", "static", {
            "razamascotainput": "raza_mascota",
            "tipomascotainput": "tipo_mascota",
            "edadmascotainput": "edad_mascota",
            "generomascotainput": "genero_mascota",
            "observacionesgeninput": "detalle_mascota",
            "nombremascotainput": "nombre_mascota",
        }),
        ("podecenal", "policy_object_id", "static", {
            "fechainicioproyectoinput": "fecha_inicial_proyecto",
            "fechafinproyectoinput": "fecha_final_proyecto",
            "periododegraciainput": "periodo_gracia",
            "montoanticipovalue": "valor_anticipo",
            "nombreedificioinput": "nombre_edificio",
            "numeropisosinput": "numero_pisos",
            "anoconstruccioninput": "ano_construcion_edificio",
            "tipoconjuntoinput": "decanal_tipo_bien",
            "direccioninmuebleinput": "decanal_direccion",
            "departamentovalue": "decanal_cod_departamento",
            "departamentoinput": "decanal_departamento",
            "ciudadvalue": "decanal_cod_ciudad",
            "ciudadinput": "decanal_ciudad",
        }),
        ("poproteccionfinanciera", "prplc_pk", "pk", {
            "llaveinput": "llave_integral_prod",
            "vigenciatecnicainput": "vigencia_tecnica",
            "indorigeninput": "origen_dato",
            "numerocreditoinput": "numero_credito",
            "ramobancasegurosvalue": "ramo_bancaseguros_codigo",
            "ramobancasegurosinput": "ramo_bancaseguros",
        }),
        ("urvdeudores", "risk_dcoid", "pk", {
            "numerocreditoinput": "numero_credito",
        }),
        ("urincterrdeudores", "risk_dcoid", "pk", {
            "numerocreditoinput": "numero_credito",
        }),
        ("urmihogarseguro", "risk_dcoid", "pk", {
            "tipobienmihogarseguroinput": "hogar_tipo_bien",
            "direccioninmuebleinput": "hogar_direccion",
            "departamentovalue": "hogar_cod_departamento",
            "departamentoinput": "hogar_departamento",
            "ciudadvalue": "hogar_cod_ciudad",
            "ciudadinput": "hogar_ciudad",
            "codigozonasismicainput": "hogar_zona_sismica",
        }),
        ("urmascotas", "risk_dcoid", "pk", {
            "departamentovalue": "mascota_cod_departamento",
            "departamentoinput": "mascota_departamento",
            "ciudadvalue": "mascota_cod_ciudad",
            "ciudadinput": "mascota_ciudad",
        }),
        ("urdecenal", "risk_dcoid", "pk", {
            "tipoconjuntoinput": "decanal_tipo_bien",
            "direccioninmuebleinput": "decanal_direccion",
            "departamentovalue": "decanal_cod_departamento",
            "departamentoinput": "decanal_departamento",
            "ciudadvalue": "decanal_cod_ciudad",
            "ciudadinput": "decanal_ciudad",
            "codigozonasismicavalue": "decanal_zona_sismica",
        }),
        ("urproteccionfinanciera", "risk_dcoid", "pk", {
            "indorigeninput": "origen_dato",
            "numerocreditoinput": "numero_credito",
            "porccomisrecauddesvalue": "porc_comis_recaudo",
            "porccomisionreadesvalue": "porc_comis_reaseguro",
            "porccomisionreaapvalue": "porc_comis_reaseguro_vda",
            "valorcomisionreasegdesvalue": "valor_comision_reaseguro",
            "valorcomisionreasegapvalue": "valor_comision_reaseguro_vda",
        }),
        ("oaincterrdeudores", "minimum_object_id", "pk", {
            "tipobieninput": "incendio_tipo_bien",
            "direccioninmuebleinput": "incendio_direccion",
            "departamentovalue": "incendio_cod_departamento",
            "departamentoinput": "incendio_departamento",
            "ciudadvalue": "incendio_cod_ciudad",
            "ciudadinput": "incendio_ciudad",
            "codigozonasismicainput": "incendio_zona_sismica",
            "tipoestructuralinput": "incendio_tipo_estructura",
            "tipoestructuralvalue": "incendio_cod_estructura",
        }),
        ("oamihogarseguro", "minimum_object_id", "pk", {
            "tipobienmihogarseguroinput": "hogar_tipo_bien",
            "direccioninmuebleinput": "hogar_direccion",
            "departamentovalue": "hogar_cod_departamento",
            "departamentoinput": "hogar_departamento",
            "ciudadvalue": "hogar_cod_ciudad",
            "ciudadinput": "hogar_ciudad",
            "tipobienmihogarsegurovalue": "hogar_cod_tipo_bien",
        }),
        ("oamascotas", "minimum_object_id", "pk", {}),
    ]

    result = base
    for table_name, base_key, source_key, mapping in joins:
        source = optional(frames, table_name)
        if source is None or source_key not in source.columns:
            continue
        columnas_temporales = {
            target: f"__{table_name}_{target}"
            for target in mapping.values()
        }
        selected = source.select(
            F.col(source_key).alias(f"join_{table_name}"),
            *[
                c(source, source_column).alias(columnas_temporales[target])
                for source_column, target in mapping.items()
            ],
        )
        result = result.join(
            selected,
            F.col(base_key) == selected[f"join_{table_name}"],
            "left",
        ).drop(f"join_{table_name}")

        for target, temporal in columnas_temporales.items():
            if target in result.columns:
                result = result.withColumn(
                    target,
                    F.coalesce(F.col(target), F.col(temporal)),
                ).drop(temporal)
            else:
                result = result.withColumnRenamed(temporal, target)
    return result


def ensure_columns(frame):
    names = [
        "ramo_bancaseguros_codigo", "ramo_bancaseguros",
        "hogar_tipo_bien", "hogar_direccion", "hogar_cod_departamento",
        "hogar_departamento", "hogar_cod_ciudad", "hogar_ciudad",
        "mascota_cod_departamento", "mascota_departamento",
        "mascota_cod_ciudad", "mascota_ciudad",
        "hogar_zona_sismica", "decanal_zona_sismica",
        "decanal_tipo_bien", "decanal_direccion",
        "decanal_cod_departamento", "decanal_departamento",
        "decanal_cod_ciudad", "decanal_ciudad", "incendio_tipo_bien",
        "incendio_direccion", "incendio_cod_departamento",
        "incendio_departamento", "incendio_cod_ciudad", "incendio_ciudad",
        "linea_credito_pre", "identificacion_empleador",
        "nombre_empleador", "origen_dato", "nro_operacion_factura",
        "numero_credito", "raza_mascota", "tipo_mascota", "edad_mascota",
        "genero_mascota", "detalle_mascota", "nombre_mascota",
        "fecha_inicial_proyecto", "fecha_final_proyecto", "periodo_gracia",
        "valor_anticipo", "nombre_edificio", "numero_pisos",
        "ano_construcion_edificio", "llave_integral_prod", "vigencia_tecnica",
        "telefono_tomador", "email_tomador", "departamento_tom",
        "ciudad_tom", "direcion_tom",
        "porc_comis_recaudo", "porc_comis_reaseguro", "porc_comis_reaseguro_vda",
        "valor_comision_reaseguro", "valor_comision_reaseguro_vda",
    ]
    tipos_opcionales = {
        "porc_comis_recaudo": "decimal(38,8)",
        "porc_comis_reaseguro": "decimal(38,8)",
        "porc_comis_reaseguro_vda": "decimal(38,8)",
        "valor_comision_reaseguro": "decimal(38,8)",
        "valor_comision_reaseguro_vda": "decimal(38,8)",
    }
    for name in names:
        if name not in frame.columns:
            frame = frame.withColumn(
                name,
                F.lit(None).cast(tipos_opcionales.get(name, "string")),
            )
    return frame


def signed_sum(frame, concepts, negative, name):
    amount = F.coalesce(F.col("ammount"), F.lit(0))
    value = F.when(
        F.col("concept_u").isin(negative) & (amount > 0),
        -amount,
    ).otherwise(amount)
    return F.sum(F.when(F.col("concept_u").isin(concepts), value)).alias(name)


def movement_aggregates(frames):
    movement = required(frames, "thirdpartymovementpolicy")
    movement = movement.filter(F.col("ammount") != 0).withColumn(
        "concept_u",
        F.upper(F.col("concept")),
    )

    general_prima = [
        "PRIMA", "PRIMAREHAB", "PRIMAANU", "PRIMADEV",
        "PRIMAPERIODOPROVIS", "PRIMAEMITIDAIND", "PRIMAREHABIND",
        "PRIMAANUIND", "PRIMADEVUELTAIND", "PRIMAPERIODOPROVISIND",
        "PRIMAINCENDIO", "PRIMATERREMOTO", "PRIMAINCENDIOPROVIS",
        "PRIMATERREMOTOPROVIS", "PRIMAINCENDIODEV",
        "PRIMATERREMOTODEV", "PRIMAINCENDIOREHAB",
        "PRIMATERREMOTOREHAB", "PRIMATERREMOTOANU",
        "PRIMAINCENDIOANU", "PRIMAASISTENCIA", "PRIMAASISTENCIADEV",
        "PRIMASUSTRACCION", "PRIMASUSTRACCIONDEV",
        "PRIMARESPONSABILIDADCIVIL", "PRIMARESPONSABILIDADCIVILDEV",
        "PRIMAGENERALES", "PRIMAGENERALESDEV",
        "PRIMAGENERALESPROVIS", "PRIMAGENERALESPROVISDEV",
        "PRIMARC", "PRIMARCANU", "PRIMARCANUDEV", "PRIMARCDEV",
        "PRIMARCPROVIS", "PRIMARCREHAB", "PRIMARCPROVISANU",
        "PRIMASUS", "PRIMASUSDEV", "PRIMADES", "PRIMADESDEV",
    ]
    negative_prima = [
        "PRIMAANU", "PRIMAANUIND", "PRIMAINCENDIODEV",
        "PRIMATERREMOTODEV", "PRIMATERREMOTOANU",
        "PRIMAINCENDIOANU", "PRIMAGENERALESDEV", "PRIMADEV",
        "PRIMADEVUELTAIND", "PRIMAASISTENCIADEV",
        "PRIMASUSTRACCIONDEV", "PRIMARESPONSABILIDADCIVILDEV",
        "PRIMAGENERALESPROVISDEV", "PRIMARCANU", "PRIMARCANUDEV",
        "PRIMARCDEV", "PRIMARCPROVISANU", "PRIMASUSDEV", "PRIMADESDEV",
    ]

    def group(concepts, negative, alias):
        return signed_sum(movement, concepts, negative, alias)

    aggregations = [
        group(general_prima, negative_prima, "prima"),
        group(["PRIMAVIDA", "PRIMAVIDADEV", "PRIMAACC", "PRIMAACCDEV"],
              ["PRIMAVIDADEV", "PRIMAACCDEV"], "prima_vida"),
        group(["PRIMAINCENDIO", "PRIMAINCENDIOPROVIS",
               "PRIMAINCENDIODEV", "PRIMAINCENDIOREHAB",
               "PRIMAINCENDIOANU"],
              ["PRIMAINCENDIODEV", "PRIMAINCENDIOANU"], "prima_incendio"),
        group(["PRIMATERREMOTO", "PRIMATERREMOTOPROVIS",
               "PRIMATERREMOTODEV", "PRIMATERREMOTOREHAB",
               "PRIMATERREMOTOANU"],
              ["PRIMATERREMOTODEV", "PRIMATERREMOTOANU"],
              "prima_terremoto"),
        group(["PRIMARC", "PRIMARCANU", "PRIMARCANUDEV", "PRIMARCDEV",
               "PRIMARCPROVIS", "PRIMARCREHAB", "PRIMARCPROVISANU"],
              ["PRIMARCANU", "PRIMARCANUDEV", "PRIMARCDEV",
               "PRIMARCPROVISANU"], "prima_respcivil"),
        group(["PRIMAASISTENCIA", "PRIMAASISTENCIADEV"],
              ["PRIMAASISTENCIADEV"], "prima_asistencia"),
        group(["PRIMASUSTRACCION", "PRIMASUSTRACCIONDEV"],
              ["PRIMASUSTRACCIONDEV"], "prima_sustraccion"),
        group(["PRIMARESPONSABILIDADCIVIL",
               "PRIMARESPONSABILIDADCIVILDEV"],
              ["PRIMARESPONSABILIDADCIVILDEV"],
              "prima_responsabilidad"),
    ]

    cost = [
        "COSTORECAUDACION", "COSTORECAUDACIONDEV",
        "COSTORECAUDOPROVIS", "COSTORECAUDOREHAB", "COSTORECAUDOANU",
        "COSTORECAUDACIONIND", "COSTORECAUDACIONDEVIND",
        "COSTORECAUDOPROVISIND", "COSTORECAUDOREHABIND",
        "COSTORECAUDOANUIND", "COSTORECAUDOINCENDIO",
        "COSTORECAUDOTERREMOTO", "COSTORECAUDOINCPROVIS",
        "COSTORECAUDOTERRPROVIS", "COSTORECAUDOINCENDIODEV",
        "COSTORECAUDOTERREMOTODEV", "COSTORECAUDOINCREHAB",
        "COSTORECAUDOTERRREHAB", "COSTORECAUDOINCANU",
        "COSTORECAUDOTERRANU", "COMISIONRECAUDOGENERALES",
        "COMISIONRECAUDOGENERALESDEV", "COMISIONRECAUDOGENERALESPROVIS",
        "COMISIONRECAUDOGENERALESPROVISDEV", "COSTORECAUDORC",
        "COSTORECAUDORCDEV", "COSTORECAUDORCPROVIS",
        "COSTORECAUDORCREHAB", "COSTORECAUDORCANU",
        "COSTORECAUDORCPROVISANU", "COMISIONRECAUDODES",
        "COMISIONRECAUDODESDEV", "COMISIONRECAUDOSUS",
        "COMISIONRECAUDOSUSDEV",
    ]
    cost_negative = [x for x in cost if x.endswith("DEV") or x.endswith("ANU")]
    aggregations.extend([
        group(cost, cost_negative, "costo_recaudacion"),
        group(["COMISIONRECAUDOVIDA", "COMISIONRECAUDOVIDADEV",
               "COMISIONRECAUDOACC", "COMISIONRECAUDOACCDEV"],
              ["COMISIONRECAUDOVIDADEV", "COMISIONRECAUDOACCDEV"],
              "costo_recaudacion_vida"),
    ])

    categories = {
        "iva_costo_recaudacion": ["IVACOSTORECAUDACION", "IVACOSTORECAUDACIONDEV"],
        "iva_costo_recaudacion_vida": ["IVACOMISIONRECAUDOVIDA", "IVACOMISIONRECAUDOVIDADEV"],
        "comision_total_interincter": ["COMISIONEMITIDA", "COMISIONDEVUELTA"],
        "comision_intermediario_inc": ["COMISIONINCENDIO", "COMISIONINCENDIODEV"],
        "comision_intermediario_terr": ["COMISIONTERREMOTO", "COMISIONTERREMOTODEV"],
        "iva_prima_total": ["IVAPRIMA", "IVAPRIMADEVUELTA", "IVAPRIMAANULADA",
                             "IVAPRIMAGENERALES", "IVAPRIMAGENERALESDEV"],
        "iva_prima_bancaseg": ["IVAPRIMAACC", "IVAPRIMAACCDEV"],
        "iva_prima_incendio": ["IVAINCENDIO", "IVAINCENDIODEV"],
        "iva_prima_terremoto": ["IVATERREMOTO", "IVATERREMOTODEV"],
        "iva_prima_repcivil": ["IVARC", "IVARCANU", "IVARCDEV"],
        "contrib_bomberos_incendio": ["CONTRIBUCIONBOMINCE", "CONTRIBUCIONBOMINCENDIO"],
        "contrib_bomberos_terremoto": ["CONTRIBUCIONBOMTERR", "CONTRIBUCIONBOMTERREMOTO"],
        "contrib_bomberos_hogar": ["CONTRIBUCIONBOM", "CONTRIBUCIONBOMDEV"],
        "iva_prima_asistencia": ["IVAASISTENCIA", "IVAASISTENCIADEV"],
        "iva_prima_sustraccion": ["IVASUSTRACCION", "IVASUSTRACCIONDEV"],
        "iva_prima_responsabilidad": ["IVARESPONSABILIDADCIVIL", "IVARESPONSABILIDADCIVILDEV"],
        "comision_neta_alfa": ["COMISIONNETAALFAGENERALES", "COMISIONNETAALFAGENERALESDEV"],
        "comision_neta_vida": ["COMISIONNETAALFAVIDA", "COMISIONNETAALFAVIDADEV"],
        "valor_neto_reaseguro": ["COMISIONREASEGUROSGENERALES", "COMISIONREASEGUROSGENERALESDEV"],
        "valor_neto_reaseguro_vida": ["COMISIONREASEGUROSVIDA", "COMISIONREASEGUROSVIDADEV"],
        "comision_tarjetacr": ["COMISIONTARJETAGENERALES", "COMISIONTARJETAGENERALESDEV"],
        "comision_tarjetacr_vida": ["COMISIONTARJETAVIDA", "COMISIONTARJETAVIDADEV"],
    }
    categories.update({
        "costo_recaudacion_inc": ["COSTORECAUDOINCENDIO", "COSTORECAUDOINCENDIODEV", "COSTORECAUDOINCPROVIS", "COSTORECAUDOINCREHAB", "COSTORECAUDOINCANU"],
        "costo_recaudacion_terr": ["COSTORECAUDOTERREMOTO", "COSTORECAUDOTERREMOTODEV", "COSTORECAUDOTERRPROVIS", "COSTORECAUDOTERRREHAB", "COSTORECAUDOTERRANU"],
        "costo_recaudacion_respcivil": ["COSTORECAUDORC", "COSTORECAUDORCDEV", "COSTORECAUDORCPROVIS", "COSTORECAUDORCREHAB", "COSTORECAUDORCANU", "COSTORECAUDORCPROVISANU"],
        "iva_costo_recaudo_inc": ["IVACOSTORECAUDOINCENDIO", "IVACOSTORECAUDOINCENDIODEV", "IVACOSTORECAUDOINCPROVIS", "IVACOSTORECAUDOINCEDEV", "IVACOSTORECAUDOINCANU", "IVACOSTORECAUDOINCANUDEV"],
        "iva_costo_recaudo_terr": ["IVACOSTORECAUDOTERR", "IVACOSTORECAUDOTERRDEV", "IVACOSTORECAUDOTERRPROVIS", "IVACOSTORECAUDOTERRREHAB", "IVACOSTORECAUDOTERRANU"],
        "iva_costo_recaudo_rescivil": ["IVACOSTORECAUDORC", "IVACOSTORECAUDORCDEV", "IVACOSTORECAUDORCPROVIS", "IVACOSTORECAUDORCREHAB", "IVACOSTORECAUDORCANU", "IVACOSTORECAUDORCPROVISANU"],
        "iva_costo_recaudo_provinc": ["IVACOSTORECAUDOINCPROVIS"],
        "iva_costo_recaudo_provterr": ["IVACOSTORECAUDOTERRPROVIS"],
        "iva_prima_provincendio": ["IVAINCENDIOPROVIS"],
        "iva_prima_provterremoto": ["IVATERREMOTOPROVIS"],
        "iva_prima_provrespcivil": ["IVARCPROVIS"],
    })

    for alias, concepts in categories.items():
        negative = [x for x in concepts if x.endswith("DEV") or x.endswith("ANU") or x.endswith("ANUDEV")]
        aggregations.append(group(concepts, negative, alias))

    aggregations.append(
        F.sum(
            F.when(
                F.upper(F.col("descproperty")).isin(
                    "SUMAASEGURADAPERIODO",
                    "VALORASEGURADOINCENDIOTERREMOTO",
                )
                & F.col("concept").like("%Aseg%"),
                F.col("ammount"),
            )
        ).alias("suma_asegurada_periodo")
    )

    return movement.groupBy("operationpk", "policyid").agg(*aggregations)


def final_frame(frames, base):
    movements = movement_aggregates(frames)
    result = base.join(
        movements,
        (base.nro_operacion == movements.operationpk)
        & (base.idpoliza == movements.policyid),
        "left",
    )

    result = (
        result.withColumn(
            "codigo_compania",
            F.regexp_replace(F.col("codigo_compania_raw").cast("string"), r"\.0$", ""),
        )
        .withColumn(
            "codigo_ramo",
            F.when(
                F.col("idproducto") == 55059,
                F.col("ramo_bancaseguros_codigo"),
            ).otherwise(F.col("codigo_ramo_raw")),
        )
        .withColumn(
            "ramo",
            F.when(
                F.col("idproducto") == 55059,
                F.col("ramo_bancaseguros"),
            ).otherwise(F.col("ramo_raw")),
        )
        .withColumn(
            "codigo_sucursal",
            F.regexp_replace(F.col("codigo_sucursal_raw").cast("string"), r"\.0$", ""),
        )
        .withColumn(
            "fechaemision",
            F.coalesce(F.col("ctx_time_stamp"), F.to_timestamp(F.lit("1999-01-01"))),
        )
        .withColumn(
            "periodo_fechaemision",
            F.date_format(F.col("fechaemision"), "yyyyMM"),
        )
        .withColumn(
            "estado_poliza",
            F.when(F.col("ctx_status") == 1, "PÓLIZA_PENDIENTE")
            .when(F.col("ctx_status") == 2, "PÓLIZA_EMITIDA")
            .otherwise(F.col("ctx_status").cast("string")),
        )
        .withColumn(
            "estado_acuerdo",
            F.when(F.col("agreement_status") == 1, "ACTIVO")
            .when(F.col("agreement_status") == 2, "SUSPENDIDO")
            .otherwise(F.col("agreement_status").cast("string")),
        )
        .withColumn(
            "descripcion_evento",
            F.coalesce(F.col("event_description"), F.col("policy_event")),
        )
        .withColumn(
            "tipo_inmueble",
            F.coalesce(F.col("incendio_tipo_bien"), F.col("hogar_tipo_bien"),
                       F.col("mascota_cod_departamento"), F.col("decanal_tipo_bien")),
        )
        .withColumn(
            "direccion_inmueble",
            F.coalesce(F.col("incendio_direccion"), F.col("hogar_direccion"),
                       F.col("decanal_direccion")),
        )
        .withColumn(
            "cod_departamento_inmueble",
            F.coalesce(F.col("incendio_cod_departamento"),
                       F.col("hogar_cod_departamento"),
                       F.col("mascota_cod_departamento"),
                       F.col("decanal_cod_departamento")),
        )
        .withColumn(
            "departamento_inmueble",
            F.coalesce(F.col("incendio_departamento"),
                       F.col("hogar_departamento"),
                       F.col("mascota_departamento"),
                       F.col("decanal_departamento")),
        )
        .withColumn(
            "cod_ciudad_inmueble",
            F.coalesce(F.col("incendio_cod_ciudad"),
                       F.col("hogar_cod_ciudad"),
                       F.col("mascota_cod_ciudad"),
                       F.col("decanal_cod_ciudad")),
        )
        .withColumn(
            "ciudad_inmueble",
            F.coalesce(F.col("incendio_ciudad"),
                       F.col("hogar_ciudad"),
                       F.col("mascota_ciudad"),
                       F.col("decanal_ciudad")),
        )
        .withColumn(
            "cod_divipol_municipio",
            F.coalesce(
                F.concat(
                    F.regexp_replace(F.col("incendio_cod_departamento").cast("string"), r"\.0$", ""),
                    F.lpad(F.regexp_replace(F.col("incendio_cod_ciudad").cast("string"), r"\.0$", ""), 3, "0"),
                ),
                F.concat(
                    F.regexp_replace(F.col("hogar_cod_departamento").cast("string"), r"\.0$", ""),
                    F.lpad(F.regexp_replace(F.col("hogar_cod_ciudad").cast("string"), r"\.0$", ""), 3, "0"),
                ),
                F.concat(
                    F.regexp_replace(F.col("mascota_cod_departamento").cast("string"), r"\.0$", ""),
                    F.lpad(F.regexp_replace(F.col("mascota_cod_ciudad").cast("string"), r"\.0$", ""), 3, "0"),
                ),
                F.concat(
                    F.regexp_replace(F.col("decanal_cod_departamento").cast("string"), r"\.0$", ""),
                    F.lpad(F.regexp_replace(F.col("decanal_cod_ciudad").cast("string"), r"\.0$", ""), 3, "0"),
                ),
            ),
        )
        .withColumn(
            "cod_zona_sismica",
            F.coalesce(
                F.col("incendio_zona_sismica"),
                F.col("hogar_zona_sismica"),
                F.col("decanal_zona_sismica"),
            ),
        )
        .withColumn(
            "tipo_estructura_bien",
            F.coalesce(
                F.col("incendio_tipo_estructura"),
                F.col("hogar_tipo_bien"),
            ),
        )
        .withColumn(
            "cod_tipo_estructura_bien",
            F.coalesce(
                F.col("incendio_cod_estructura"),
                F.col("hogar_cod_tipo_bien"),
            ),
        )
        .withColumn(
            "linea_credito",
            F.coalesce(F.col("linea_credito_pre"), F.lit(None)),
        )
    )

    result = result.withColumn("nro_operacion_pol", F.col("nro_operacion"))
    for columna_cero in [
        "costo_recaudacion_inc", "costo_recaudacion_terr", "costo_recaudacion_respcivil",
        "iva_costo_recaudo_inc", "iva_costo_recaudo_terr", "iva_costo_recaudo_rescivil",
        "iva_costo_recaudo_provinc", "iva_costo_recaudo_provterr",
        "iva_prima_provincendio", "iva_prima_provterremoto", "iva_prima_provrespcivil",
        "iva_prima_anulada_mascotas",
    ]:
        if columna_cero in result.columns:
            result = result.withColumn(
                columna_cero,
                F.coalesce(F.col(columna_cero), F.lit(0)),
            )
        else:
            result = result.withColumn(columna_cero, F.lit(0))

    output_columns = [
        "idpoliza", "idproducto", "codigo_compania", "compania",
        "codigo_producto", "producto", "codigo_ramo", "ramo",
        "codigo_sucursal", "sucursal", "identificacion_tomador", "tomador",
        "departamento_tom", "ciudad_tom", "direcion_tom", "telefono_tomador",
        "email_tomador", "identifica_pagador_maestro",
        "informacion_pagador_maestro", "tipo_identif_asegurado",
        "identif_asegurado", "asegurado", "identificacion_empleador",
        "nombre_empleador", "identificacion_pagador", "pagador", "idacuerdo",
        "fechaini_acuerdo", "fechafin_acuerdo", "numero_poliza_matriz",
        "nombre_acuerdo", "estado_acuerdo", "tipo_poliza", "nro_poliza",
        "frecuencia_pago", "fechaemision", "periodo_fechaemision",
        "estado_poliza", "fecha_incial_pol", "fecha_final_pol",
        "tipo_produccion", "cod_unidad_negocio", "unidad_negocio",
        "nro_operacion", "tipo_inmueble", "direccion_inmueble",
        "cod_departamento_inmueble", "departamento_inmueble",
        "cod_ciudad_inmueble", "ciudad_inmueble", "cod_divipol_municipio",
        "cod_zona_sismica", "tipo_estructura_bien", "cod_tipo_estructura_bien",
        "linea_credito",
        "descripcion_evento", "moneda_acuerdo", "unidad_riesgo",
        "numero_credito", "fecha_inicial_ur", "fecha_final_ur",
        "prima", "prima_vida", "prima_incendio", "prima_terremoto",
        "prima_respcivil", "costo_recaudacion",
        "costo_recaudacion_vida", "iva_costo_recaudacion",
        "iva_costo_recaudacion_vida", "comision_total_interincter",
        "comision_intermediario_inc", "comision_intermediario_terr",
        "iva_prima_total", "iva_prima_bancaseg", "iva_prima_incendio",
        "iva_prima_terremoto", "iva_prima_repcivil",
        "suma_asegurada_periodo", "prima_asistencia", "prima_sustraccion",
        "prima_responsabilidad", "iva_prima_asistencia",
        "iva_prima_sustraccion", "iva_prima_responsabilidad",
        "comision_neta_alfa", "comision_neta_vida",
        "valor_neto_reaseguro", "valor_neto_reaseguro_vida",
        "comision_tarjetacr", "comision_tarjetacr_vida", "agente",
        "raza_mascota", "tipo_mascota", "edad_mascota", "genero_mascota", "detalle_mascota", "nombre_mascota",
        "nro_operacion_pol", "origen_dato", "nro_operacion_factura",
        "fecha_inicial_proyecto", "fecha_final_proyecto", "periodo_gracia", "valor_anticipo", "nombre_edificio", "numero_pisos", "ano_construcion_edificio",
        "costo_recaudacion_inc", "costo_recaudacion_terr", "costo_recaudacion_respcivil",
        "iva_costo_recaudo_inc", "iva_costo_recaudo_terr", "iva_costo_recaudo_rescivil", "iva_costo_recaudo_provinc", "iva_costo_recaudo_provterr",
        "iva_prima_provincendio", "iva_prima_provterremoto", "iva_prima_provrespcivil",
        "contrib_bomberos_incendio", "contrib_bomberos_terremoto", "contrib_bomberos_hogar",
        "vigencia_tecnica", "porc_comis_recaudo", "porc_comis_reaseguro", "porc_comis_reaseguro_vda", "valor_comision_reaseguro", "valor_comision_reaseguro_vda",
        "iva_prima_anulada_mascotas",
    ]

    faltantes_salida = [column for column in output_columns if column not in result.columns]
    if faltantes_salida:
        raise ValueError(
            "Salida de Generales incompleta: " + ", ".join(faltantes_salida)
        )
    return result.select(*output_columns)




def buscar_ruta_gold(config):
    prioridades = (
        "ruta_gold",
        "ruta_scd",
        "ruta_destino_gold",
        "ruta_salida_gold",
    )
    if isinstance(config, dict):
        for key in prioridades:
            value = config.get(key)
            if isinstance(value, str) and value.startswith("s3://"):
                return value
        for value in config.values():
            found = buscar_ruta_gold(value)
            if found:
                return found
    elif isinstance(config, list):
        for value in config:
            found = buscar_ruta_gold(value)
            if found:
                return found
    return None


def alinear_con_contrato_gold(spark, frame, ruta_config_scd):
    config_scd = read_json(ruta_config_scd)
    ruta_gold = buscar_ruta_gold(config_scd)
    if not ruta_gold:
        raise ValueError("No se encontro la ruta Gold en config_scd_generales.json")

    if not s3_prefix_exists(ruta_gold):
        print(
            "ALINEACION_GOLD_OMITIDA_PRIMERA_CARGA | "
            f"ruta_gold={ruta_gold}"
        )
        return frame

    campos_gold = spark.read.parquet(ruta_gold).schema.fields
    columnas_administrativas_scd = {
        "hash",
        "fec_ini_vig_reg",
        "fec_fin_vig_reg",
        "vrs_reg",
        "act_reg",
    }
    campos_negocio = [
        field for field in campos_gold
        if field.name.lower() not in columnas_administrativas_scd
    ]

    actuales = {name.lower(): name for name in frame.columns}
    agregadas = []
    for field in campos_negocio:
        if field.name.lower() not in actuales:
            frame = frame.withColumn(
                field.name,
                F.lit(None).cast(field.dataType),
            )
            agregadas.append(field.name)

    actuales = {name.lower(): name for name in frame.columns}
    seleccion = [
        F.col(actuales[field.name.lower()])
        .cast(field.dataType)
        .alias(field.name)
        for field in campos_negocio
    ]

    print(
        "ALINEACION_CONTRATO_GOLD | "
        f"ruta_gold={ruta_gold} | "
        f"columnas_gold_negocio={len(campos_negocio)} | "
        f"columnas_silver_antes={len(frame.columns)} | "
        f"columnas_agregadas={len(agregadas)} | "
        f"agregadas={','.join(agregadas)}"
    )
    return frame.select(*seleccion)

def guardar_json(uri, contenido):
    match = re.match(
        r"^s3://([^/]+)/(.+)$",
        uri or "",
    )

    if not match:
        raise ValueError(
            f"Ruta S3 invalida: {uri}"
        )

    boto3.client("s3").put_object(
        Bucket=match.group(1),
        Key=match.group(2),
        Body=(
            json.dumps(
                contenido,
                indent=2,
                ensure_ascii=False,
                default=str,
            )
            + "\n"
        ).encode("utf-8"),
        ContentType="application/json",
    )


def actualizar_runtime(
    ruta_runtime,
    runtime,
    salida,
    total,
):
    fecha = datetime.utcnow().isoformat()

    informe = {
        "estado": "SUCCESS",
        "nombre_caso":
            runtime.get("nombre_caso"),
        "periodo_negocio":
            runtime.get("periodo_negocio"),
        "lote_cargue_id":
            runtime.get("lote_cargue_id"),
        "total_registros":
            int(total),
        "ruta_silver_preparada":
            salida,
        "fecha_preparacion":
            fecha,
    }

    runtime.update({
        "estado_preparacion_silver":
            "SUCCESS",
        "ruta_silver_preparada":
            salida,
        "total_registros_silver_preparada":
            int(total),
        "fecha_preparacion_silver":
            fecha,
        "modo_escritura_silver_preparada":
            "overwrite",
        "silver_preparada_historica":
            False,
        "silver_preparacion":
            informe,
    })

    guardar_json(
        ruta_runtime,
        runtime,
    )

    return informe

def main():
    required_args = [
        "JOB_NAME",
        "RUTA_PARAMETROS_EXTRACCION",
        "S3_SLV_PREP_PATH",
        "RUTA_CONFIG_SCD",
    ]
    args = getResolvedOptions(sys.argv, required_args)
    capa = "BRONZE"
    if "--CAPA_ENTRADA" in sys.argv:
        capa = getResolvedOptions(
            sys.argv, ["CAPA_ENTRADA"]
        )["CAPA_ENTRADA"].upper()

    runtime = read_json(args["RUTA_PARAMETROS_EXTRACCION"])
    periodo = str(
        runtime.get("periodo_negocio")
        or runtime.get("periodoNegocio")
        or ""
    )
    if not re.fullmatch(r"\d{6}", periodo):
        raise ValueError(f"periodo_negocio invalido: {periodo}")

    context = SparkContext.getOrCreate()
    glue = GlueContext(context)
    spark = glue.spark_session
    spark.conf.set("spark.sql.caseSensitive", "false")
    spark.conf.set("spark.sql.session.timeZone", "America/Bogota")
    job = Job(glue)
    job.init(args["JOB_NAME"], args)

    frames, cached = load_sources(spark, runtime, capa)
    try:
        frame = base_frame(frames, runtime)
        frame = add_agreement_and_object(frames, frame)
        frame = participant_aggregates(frames, frame)
        frame = address_and_agent(frames, frame)
        frame = insured_people(frames, frame)
        frame = add_attributes(frames, frame)
        frame = ensure_columns(frame)
        frame = final_frame(frames, frame)

        frame = (
            frame.withColumn("periodo_negocio", F.lit(periodo))
            .withColumn("caso_uso", F.lit(CASO))
            .withColumn(
                "id_ejecucion",
                F.lit(runtime.get("id_ejecucion") or str(uuid.uuid4())),
            )
            .withColumn(
                "lote_cargue_id",
                F.lit(runtime.get("lote_cargue_id")).cast("long"),
            )
            .withColumn("fecha_proceso", F.current_timestamp())
        )

        frame = alinear_con_contrato_gold(
            spark,
            frame,
            args["RUTA_CONFIG_SCD"],
        )

        output = (
            args["S3_SLV_PREP_PATH"].rstrip("/")
            + f"/periodo_negocio={periodo}/"
        )
        frame.write.mode("overwrite").option(
            "compression", "snappy"
        ).parquet(output)

        total_registros = frame.count()

        informe = actualizar_runtime(
            args["RUTA_PARAMETROS_EXTRACCION"],
            runtime,
            output,
            total_registros,
        )

        print(json.dumps({
            "estado": "SUCCESS",
            "caso": CASO,
            "periodo_negocio": periodo,
            "ruta_silver_preparada": output,
            "total_registros": total_registros,
            "fecha_preparacion": datetime.utcnow().isoformat(),
        }, ensure_ascii=False))
        job.commit()
    finally:
        for item in cached:
            item.unpersist()


if __name__ == "__main__":
    main()
