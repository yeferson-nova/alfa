import sys
import json
import uuid
import boto3
from datetime import datetime
from urllib.parse import urlparse
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark import StorageLevel

def parse_s3(uri):
    parsed = urlparse(uri)
    if parsed.scheme != 's3' or not parsed.netloc:
        raise ValueError('URI S3 invalida: ' + str(uri))
    return (parsed.netloc, parsed.path.lstrip('/'))

def cargar_json(uri):
    bucket, key = parse_s3(uri)
    response = boto3.client('s3').get_object(Bucket=bucket, Key=key)
    return json.loads(response['Body'].read().decode('utf-8'))

def guardar_json(uri, contenido):
    bucket, key = parse_s3(uri)
    boto3.client('s3').put_object(Bucket=bucket, Key=key, Body=json.dumps(contenido, indent=2, ensure_ascii=False, default=str).encode('utf-8'), ContentType='application/json')

def normalizar_columnas(df):
    return df.toDF(*[columna.upper() for columna in df.columns])
from pyspark.sql.types import StringType, StructType, StructField
PRODUCTOS = [55059, 54999, 54959, 52897, 54979, 55099]

def opcional(nombre, defecto):
    flag = '--' + nombre
    if flag in sys.argv:
        return getResolvedOptions(sys.argv, [nombre])[nombre]
    return defecto

def preparar_vistas(spark, runtime, capa):
    """Registra solo fuentes disponibles y conserva LEFT JOIN opcionales."""
    datasets = runtime.get("datasets_extraidos") or runtime.get("datasets") or []
    if not datasets:
        raise ValueError("Runtime de Satelites sin datasets_extraidos/datasets")

    copiados_silver = {
        (registro.get("tabla_relativa") or registro.get("tabla") or "")
        .rstrip("/")
        .split("/")[-1]
        .upper()
        for registro in (runtime.get("datasets_copiados_silver") or [])
        if (registro.get("tabla_relativa") or registro.get("tabla"))
    }

    indice = {}
    cache = []
    esquemas_vacios = {
        "POPETLOVER": StructType([
            StructField("PK", StringType(), True),
            StructField("PROMOTORINPUT", StringType(), True),
            StructField("TIPONEGOCIOGASINPUT", StringType(), True),
            StructField("INDORIGENINPUT", StringType(), True),
        ]),
    }

    for item in datasets:
        relativa = item.get("tabla_relativa") or item.get("tabla")
        if not relativa:
            raise ValueError("Dataset de Satelites sin tabla_relativa")
        nombre = relativa.rstrip("/").split("/")[-1].upper()
        estado = str(item.get("estado") or item.get("status") or "").upper()
        if estado in {"FAILED", "ERROR"}:
            raise ValueError(f"Dataset de Satelites con estado {estado}: {nombre}")
        indice[nombre] = item

        if capa == "SILVER" and nombre not in copiados_silver:
            omitido = next(
                (
                    registro
                    for registro in (runtime.get("datasets_omitidos_silver") or [])
                    if (
                        registro.get("tabla_relativa")
                        or registro.get("tabla")
                        or ""
                    ).rstrip("/").split("/")[-1].upper() == nombre
                ),
                None,
            )
            estado_remediacion = str((omitido or {}).get("estado") or "").upper()

            if estado_remediacion == "SKIPPED_SIN_REGISTROS":
                ruta_bronze = item.get("ruta_dataset_origen")
                if not ruta_bronze:
                    raise ValueError(f"Dataset vacio sin ruta Bronze: {nombre}")
                df = normalizar_columnas(spark.read.parquet(ruta_bronze).limit(0))
                df.createOrReplaceTempView(nombre)
                print(
                    f"VISTA_VACIA_REGISTRADA_DESDE_BRONZE | "
                    f"tabla={nombre} | ruta={ruta_bronze}"
                )
                continue

            esquema = esquemas_vacios.get(nombre)
            if estado in {"SKIPPED_NOT_AVAILABLE", "NOT_AVAILABLE"} and esquema is not None:
                df = spark.createDataFrame([], esquema)
                df.createOrReplaceTempView(nombre)
                print(
                    f"VISTA_VACIA_REGISTRADA_DESDE_ESQUEMA | "
                    f"tabla={nombre} | estado={estado}"
                )
                continue

            print(
                f"DATASET_IGNORADO_NO_COPIADO_POR_REMEDIACION | "
                f"tabla={nombre} | estado={estado} | "
                f"estado_remediacion={estado_remediacion}"
            )
            continue

        if estado in {"SKIPPED_NOT_AVAILABLE", "NOT_AVAILABLE"}:
            esquema = esquemas_vacios.get(nombre)
            if esquema is None:
                continue
            df = spark.createDataFrame([], esquema)
        else:
            campo_ruta = "ruta_dataset_destino" if capa == "SILVER" else "ruta_dataset_origen"
            ruta_dataset = item.get(campo_ruta)
            if not ruta_dataset:
                raise ValueError(f"Ruta ausente para {nombre}: {campo_ruta}")
            df = normalizar_columnas(spark.read.parquet(ruta_dataset))
            lotes = item.get("lotes_preparacion_silver") or item.get("lotes_segmento") or [item.get("lote_cargue_id_dataset")]
            lotes = [int(lote) for lote in lotes if lote is not None]
            if "LOTE_CARGUE_ID" in df.columns and lotes:
                df = df.filter(F.col("LOTE_CARGUE_ID").isin(lotes))

        for campo in df.schema.fields:
            if isinstance(campo.dataType, StringType):
                df = df.withColumn(campo.name, F.when(F.col(campo.name) == "", F.lit(None)).otherwise(F.col(campo.name)))
        df = df.persist(StorageLevel.MEMORY_AND_DISK)
        df.createOrReplaceTempView(nombre)
        cache.append(df)

    return indice, cache

def construir_base_principal(spark):
    """
    Construye la base funcional inicial de Satelites.

    Reglas:
    - PREPRODUCT.COMPANIAVALUE = '50.0'.
    - No filtra STATUS en POLICYDCO.
    - No filtra STATUS en RISKUNITDCO.
    - PRODUCT.DESCRIPTION conserva el nombre real.
    - El objeto asegurado minimo se calcula aparte usando
      INSURANCEOBJECTDCO.STATUS = 1.
    """
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        OBJETO_ASEGURADO_MINIMO_SATELITES AS\n\n        SELECT\n            AGREGATEDPARENTID,\n            OPERATIONPK,\n            MIN(\n                AGREGATEDOBJECTID\n            ) AS AGREGATEDOBJECTID\n\n        FROM INSURANCEOBJECTDCO\n\n        WHERE STATUS = 1\n\n        GROUP BY\n            AGREGATEDPARENTID,\n            OPERATIONPK\n    ')
    spark.sql("\n        CREATE OR REPLACE TEMP VIEW\n        BASE_PRINCIPAL_SATELITES AS\n\n        SELECT\n            AP.AGREGATEDPOLICYID\n                AS IDPOLIZA,\n\n            AP.PRODUCTID\n                AS IDPRODUCTO,\n\n            PDCO.OPERATIONPK\n                AS NRO_OPERACION,\n\n            PDCO.DCOID\n                AS ID_PREPOLICY,\n\n            PDCO.INITIALDATE\n                AS FECHA_INICIAL_POL,\n\n            PDCO.FINISHDATE\n                AS FECHA_FINAL_POL,\n\n            PDCO.EVENT\n                AS EVENTO_POLICYDCO,\n\n            PDCO.IDDCOEVENT\n                AS ID_EVENTO_DCO,\n\n            REGEXP_REPLACE(\n                CAST(\n                    PREP.COMPANIAVALUE\n                    AS STRING\n                ),\n                '\\.0$',\n                ''\n            ) AS CODIGO_COMPANIA,\n\n            PREP.COMPANIAINPUT\n                AS COMPANIA,\n\n            PREP.CODIGOPRODUCTOINPUT\n                AS CODIGO_PRODUCTO,\n\n            PREP.RAMOVALUE\n                AS CODIGO_RAMO_BASE,\n\n            PREP.RAMOINPUT\n                AS RAMO_BASE,\n\n            PR.DESCRIPTION\n                AS PRODUCTO,\n\n            PPOL.OFICINAVALUE\n                AS CODIGO_SUCURSAL_BASE,\n\n            PPOL.OFICINAINPUT\n                AS SUCURSAL,\n\n            PPOL.TIPOPOLIZAINPUT\n                AS TIPO_POLIZA,\n\n            PPOL.FRECUENCIAPAGOINPUT\n                AS FRECUENCIA_PAGO,\n\n            PPOL.NUMEROPOLIZAINPUT\n                AS NRO_POLIZA,\n\n            PPOL.CANALVENTAINPUT\n                AS CANAL_VENTA,\n\n            PPOL.MONEDAINPUT\n                AS MONEDA_ACUERDO,\n\n            RUDCO.AGREGATEDOBJECTID\n                AS UNIDAD_RIESGO,\n\n            RUDCO.DCOID\n                AS ID_PRERISKUNIT,\n\n            RUDCO.INITIALDATE\n                AS FECHA_INICIAL_UR,\n\n            RUDCO.FINISHDATE\n                AS FECHA_FINAL_UR,\n\n            CTX.TIME_STAMP\n                AS FECHA_EMISION,\n\n            OAM.AGREGATEDOBJECTID\n                AS OBJETO_ASEGURADO_MINIMO\n\n        FROM POLICYDCO PDCO\n\n        INNER JOIN CONTEXTOPERATION CTX\n            ON CTX.ID =\n               PDCO.OPERATIONPK\n\n        INNER JOIN AGREGATEDPOLICY AP\n            ON AP.AGREGATEDPOLICYID =\n               PDCO.AGREGATEDOBJECTID\n\n        INNER JOIN PREPOLICY PPOL\n            ON PPOL.PK =\n               PDCO.DCOID\n\n        INNER JOIN PREPRODUCT PREP\n            ON PREP.STATIC =\n               AP.PRODUCTID\n\n           AND CAST(\n               PREP.COMPANIAVALUE\n               AS STRING\n           ) = '50.0'\n\n            INNER JOIN PRODUCT PR\n            ON PR.PRODUCTID =\n               PREP.STATIC\n\n           AND PR.DESCRIPTION IN (\n               'Practiseguro',\n               'VidaAp',\n               'SalvaFactura',\n               'Exequias',\n               'PetLover',\n               'ProteccionVida',\n               'ProteccionSalud',\n               'ExequiasTradicional'\n           )\n\n        INNER JOIN RISKUNITDCO RUDCO\n            ON RUDCO.OPERATIONPK =\n               PDCO.OPERATIONPK\n\n        LEFT JOIN\n            OBJETO_ASEGURADO_MINIMO_SATELITES\n            OAM\n\n            ON OAM.OPERATIONPK =\n               RUDCO.OPERATIONPK\n\n           AND OAM.AGREGATEDPARENTID =\n               RUDCO.AGREGATEDOBJECTID\n    ")
    columnas_requeridas = {'IDPOLIZA', 'IDPRODUCTO', 'NRO_OPERACION', 'CODIGO_COMPANIA', 'COMPANIA', 'CODIGO_PRODUCTO', 'PRODUCTO', 'NRO_POLIZA', 'UNIDAD_RIESGO'}
    columnas_actuales = set(spark.table('BASE_PRINCIPAL_SATELITES').columns)
    faltantes = sorted(columnas_requeridas - columnas_actuales)
    if faltantes:
        raise ValueError('Base principal Satelites sin columnas requeridas: ' + ', '.join(faltantes))
    return spark.table('BASE_PRINCIPAL_SATELITES')

def preparar_acuerdos(spark):
    """
    Construye el acuerdo vigente aplicable a cada
    registro de la base principal de Satelites.

    Relaciones del SQL funcional:
    - IDPOLIZA = RSA_POLICYID.
    - RSA_AST_ID = AST_ID.
    - AST_FECINI <= FECHA_INICIAL_UR.
    - AST_FECFIN >= FECHA_INICIAL_UR.

    La integracion final es LEFT JOIN para conservar
    polizas sin acuerdo.

    Si existe mas de una version vigente para la misma
    poliza, operacion y unidad de riesgo, conserva una
    version deterministica:
    1. mayor AST_FECINI;
    2. mayor AST_FECFIN;
    3. mayor AST_ID;
    4. mayor DCOID de version.
    """
    spark.sql("\n        CREATE OR REPLACE TEMP VIEW\n        ACUERDOS_VIGENTES_CANDIDATOS AS\n\n        SELECT\n            BASE.IDPOLIZA,\n            BASE.NRO_OPERACION,\n            BASE.UNIDAD_RIESGO,\n\n            AGREDAT.AST_ID\n                AS IDACUERDO,\n\n            AGREDAT.AST_NUMEROACU\n                AS NUMERO_POLIZA_MATRIZ,\n\n            AGREDAT.AST_NOMBREACU\n                AS NOMBRE_ACUERDO,\n\n            CASE\n                WHEN CAST(\n                    AGRV.STATUS AS STRING\n                ) = '1'\n                    THEN 'ACTIVO'\n\n                WHEN CAST(\n                    AGRV.STATUS AS STRING\n                ) = '2'\n                    THEN 'SUSPENDIDO'\n\n                ELSE CAST(\n                    AGRV.STATUS AS STRING\n                )\n            END AS ESTADO_ACUERDO,\n\n            AGRV.AST_FECINI\n                AS FECHAINI_ACUERDO_TS,\n\n            AGRV.AST_FECFIN\n                AS FECHAFIN_ACUERDO_TS,\n\n            DATE_FORMAT(\n                AGRV.AST_FECINI,\n                'dd-MM-yyyy'\n            ) AS FECHAINI_ACUERDO,\n\n            DATE_FORMAT(\n                AGRV.AST_FECFIN,\n                'dd-MM-yyyy'\n            ) AS FECHAFIN_ACUERDO,\n\n            LIUNC.TIPOPRODUCCIONINPUT\n                AS TIPO_PRODUCCION,\n\n            LIUNC.UNIDADNEGOCIOINPUT\n                AS UNIDAD_NEGOCIO,\n\n            LIUNC.LINEACREDITOINPUT\n                AS LINEA_CREDITO,\n\n            AGRV.DCOID\n                AS ID_PREAGREEMENT,\n\n            ROW_NUMBER() OVER (\n                PARTITION BY\n                    BASE.IDPOLIZA,\n                    BASE.NRO_OPERACION,\n                    BASE.UNIDAD_RIESGO\n\n                ORDER BY\n                    AGRV.AST_FECINI DESC,\n                    AGRV.AST_FECFIN DESC,\n                    AGREDAT.AST_ID DESC,\n                    AGRV.DCOID DESC\n            ) AS ORDEN_VIGENCIA\n\n        FROM BASE_PRINCIPAL_SATELITES BASE\n\n        INNER JOIN\n            STPS_RELATIONAGREEMENTPOLICY\n            AGPOL\n\n            ON AGPOL.RSA_POLICYID =\n               BASE.IDPOLIZA\n\n        INNER JOIN\n            STPS_AGREEMENTSTATICDAT\n            AGREDAT\n\n            ON AGREDAT.AST_ID =\n               AGPOL.RSA_AST_ID\n\n        INNER JOIN\n            STAG_AGREEMENTVERSION AGRV\n\n            ON AGRV.AST_ID =\n               AGREDAT.AST_ID\n\n           AND AGRV.AST_FECINI <=\n               BASE.FECHA_INICIAL_UR\n\n           AND AGRV.AST_FECFIN >=\n               BASE.FECHA_INICIAL_UR\n\n        LEFT JOIN PREAGREEMENT LIUNC\n            ON LIUNC.PK =\n               AGRV.DCOID\n    ")
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        ACUERDOS_VIGENTES_SATELITES AS\n\n        SELECT\n            IDPOLIZA,\n            NRO_OPERACION,\n            UNIDAD_RIESGO,\n            IDACUERDO,\n            NUMERO_POLIZA_MATRIZ,\n            NOMBRE_ACUERDO,\n            ESTADO_ACUERDO,\n            FECHAINI_ACUERDO,\n            FECHAFIN_ACUERDO,\n            FECHAINI_ACUERDO_TS,\n            FECHAFIN_ACUERDO_TS,\n            TIPO_PRODUCCION,\n            UNIDAD_NEGOCIO,\n            LINEA_CREDITO,\n            ID_PREAGREEMENT\n\n        FROM ACUERDOS_VIGENTES_CANDIDATOS\n\n        WHERE ORDEN_VIGENCIA = 1\n    ')
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        BASE_SATELITES_CON_ACUERDOS AS\n\n        SELECT\n            BASE.*,\n\n            ACU.IDACUERDO,\n            ACU.NUMERO_POLIZA_MATRIZ,\n            ACU.NOMBRE_ACUERDO,\n            ACU.ESTADO_ACUERDO,\n            ACU.FECHAINI_ACUERDO,\n            ACU.FECHAFIN_ACUERDO,\n            ACU.FECHAINI_ACUERDO_TS,\n            ACU.FECHAFIN_ACUERDO_TS,\n            ACU.TIPO_PRODUCCION,\n            ACU.UNIDAD_NEGOCIO,\n            ACU.LINEA_CREDITO,\n            ACU.ID_PREAGREEMENT\n\n        FROM BASE_PRINCIPAL_SATELITES BASE\n\n        LEFT JOIN\n            ACUERDOS_VIGENTES_SATELITES ACU\n\n            ON ACU.IDPOLIZA =\n               BASE.IDPOLIZA\n\n           AND ACU.NRO_OPERACION =\n               BASE.NRO_OPERACION\n\n           AND ACU.UNIDAD_RIESGO =\n               BASE.UNIDAD_RIESGO\n    ')
    base = spark.table('BASE_PRINCIPAL_SATELITES')
    resultado = spark.table('BASE_SATELITES_CON_ACUERDOS')
    columnas_requeridas = {'IDPOLIZA', 'NRO_OPERACION', 'UNIDAD_RIESGO', 'IDACUERDO', 'NUMERO_POLIZA_MATRIZ', 'NOMBRE_ACUERDO', 'ESTADO_ACUERDO', 'FECHAINI_ACUERDO', 'FECHAFIN_ACUERDO', 'TIPO_PRODUCCION', 'UNIDAD_NEGOCIO', 'LINEA_CREDITO'}
    faltantes = sorted(columnas_requeridas - set(resultado.columns))
    if faltantes:
        raise ValueError('Acuerdos Satelites sin columnas: ' + ', '.join(faltantes))
    total_base = base.count()
    total_resultado = resultado.count()
    if total_resultado != total_base:
        raise ValueError(f'Acuerdos alteraron la cardinalidad: base={total_base}, resultado={total_resultado}')
    duplicados_acuerdo = spark.table('ACUERDOS_VIGENTES_SATELITES').groupBy('IDPOLIZA', 'NRO_OPERACION', 'UNIDAD_RIESGO').count().filter(F.col('count') > 1).count()
    if duplicados_acuerdo:
        raise ValueError('Acuerdos vigentes duplicados: ' + str(duplicados_acuerdo))
    return resultado

def preparar_eventos(spark):
    """
    Enriquece la base de Satelites con el evento
    asociado a POLICYDCO.

    Relacion funcional:
    - POLICYDCO.OPERATIONPK =
      EVENTDCO.OPERATIONPK.
    - POLICYDCO.IDDCOEVENT =
      EVENTDCO.IDDCOEVENT.
    - EVENTDCO.EVENTTYPEID =
      EVENTTYPE.EVENTTYPEID.

    La union se realiza por OPERATIONPK e IDDCOEVENT.
    No se permite unir solamente por OPERATIONPK,
    debido a que una operacion puede tener varios
    eventos.

    Durante la construccion se utiliza LEFT JOIN para
    medir registros sin evento sin perder polizas. La
    salida definitiva podra aplicar la semantica INNER
    del SQL fuente despues de la reconciliacion.
    """
    duplicados_eventdco = spark.table('EVENTDCO').groupBy('OPERATIONPK', 'IDDCOEVENT').count().filter(F.col('count') > 1).count()
    if duplicados_eventdco:
        raise ValueError('EVENTDCO tiene claves duplicadas OPERATIONPK + IDDCOEVENT: ' + str(duplicados_eventdco))
    duplicados_eventtype = spark.table('EVENTTYPE').groupBy('EVENTTYPEID').count().filter(F.col('count') > 1).count()
    if duplicados_eventtype:
        raise ValueError('EVENTTYPE tiene EVENTTYPEID duplicados: ' + str(duplicados_eventtype))
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        EVENTOS_SATELITES AS\n\n        SELECT\n            ED.OPERATIONPK\n                AS NRO_OPERACION,\n\n            ED.IDDCOEVENT\n                AS ID_EVENTO_DCO,\n\n            ED.EVENTTYPEID\n                AS ID_TIPO_EVENTO,\n\n            EVENT.DESCRIPTION\n                AS DESCRIPCION_EVENTTYPE\n\n        FROM EVENTDCO ED\n\n        LEFT JOIN EVENTTYPE EVENT\n            ON EVENT.EVENTTYPEID =\n               ED.EVENTTYPEID\n    ')
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        BASE_SATELITES_CON_EVENTOS AS\n\n        SELECT\n            BASE.*,\n\n            EVT.ID_TIPO_EVENTO,\n\n            EVT.DESCRIPCION_EVENTTYPE,\n\n            COALESCE(\n                EVT.DESCRIPCION_EVENTTYPE,\n                BASE.EVENTO_POLICYDCO\n            ) AS DESCRIPCION_EVENTO\n\n        FROM BASE_SATELITES_CON_ACUERDOS BASE\n\n        LEFT JOIN EVENTOS_SATELITES EVT\n            ON EVT.NRO_OPERACION =\n               BASE.NRO_OPERACION\n\n           AND EVT.ID_EVENTO_DCO =\n               BASE.ID_EVENTO_DCO\n    ')
    base = spark.table('BASE_SATELITES_CON_ACUERDOS')
    resultado = spark.table('BASE_SATELITES_CON_EVENTOS')
    columnas_requeridas = {'NRO_OPERACION', 'ID_EVENTO_DCO', 'ID_TIPO_EVENTO', 'DESCRIPCION_EVENTTYPE', 'DESCRIPCION_EVENTO'}
    faltantes = sorted(columnas_requeridas - set(resultado.columns))
    if faltantes:
        raise ValueError('Eventos Satelites sin columnas: ' + ', '.join(faltantes))
    total_base = base.count()
    total_resultado = resultado.count()
    if total_resultado != total_base:
        raise ValueError(f'Eventos alteraron la cardinalidad: base={total_base}, resultado={total_resultado}')
    eventos_no_encontrados = resultado.filter(F.col('ID_EVENTO_DCO').isNotNull() & F.col('ID_TIPO_EVENTO').isNull()).count()
    return {'dataframe': resultado, 'total_base': total_base, 'total_resultado': total_resultado, 'eventos_no_encontrados': eventos_no_encontrados, 'duplicados_eventdco': duplicados_eventdco, 'duplicados_eventtype': duplicados_eventtype}

def preparar_cancelaciones(spark):
    """
    Integra cancelaciones y anulaciones mediante
    ID_EVENTO_DCO.

    Relaciones funcionales:
    - ID_EVENTO_DCO = CANCELARVIDAAP.PK.
    - ID_EVENTO_DCO = CANCELARPYS.PK.
    - ID_EVENTO_DCO = ANULAR.PK.

    Prioridad definida por el SQL:
    1. CANCELARVIDAAP.
    2. CANCELARPYS.
    3. ANULAR.

    MOTIVOCANCELACION conserva la regla especial:
    solamente toma MOTIVOCANCELACIONVIDAAPINPUT
    cuando DESCRIPCION_EVENTO = 'Cancelar'.

    ESTADO_FINAL_POL no se calcula en este bloque,
    porque depende de la ultima operacion de la
    poliza y se implementara separadamente.
    """
    tablas_pk = ['CANCELARVIDAAP', 'CANCELARPYS', 'ANULAR']
    duplicados_por_tabla = {}
    for tabla in tablas_pk:
        duplicados = spark.table(tabla).filter(F.col('PK').isNotNull()).groupBy('PK').count().filter(F.col('count') > 1).count()
        duplicados_por_tabla[tabla] = duplicados
        if duplicados:
            raise ValueError(f'{tabla} tiene PK duplicada: {duplicados}')
    spark.sql("\n        CREATE OR REPLACE TEMP VIEW\n        CANCELACIONES_SATELITES AS\n\n        SELECT\n            BASE.IDPOLIZA,\n            BASE.NRO_OPERACION,\n            BASE.UNIDAD_RIESGO,\n            BASE.ID_EVENTO_DCO,\n\n            CAP.MOTIVOCANCELACIONVIDAAPINPUT\n                AS MOTIVO_CANCELACION_VIDA_AP,\n\n            CPG.MOTIVOANULACIONINPUT\n                AS MOTIVO_CANCELAR_PYS,\n\n            AAPPG.MOTIVOANULACIONINPUT\n                AS MOTIVO_ANULAR,\n\n            COALESCE(\n                CAP.FECHAMOVIMIENTOINPUT,\n                CPG.FECHAMOVIMIENTOINPUT,\n                AAPPG.FECHAMOVIMIENTOINPUT\n            ) AS FECHA_MOV_CANCELANUL,\n\n            COALESCE(\n                CAP.FECHAEFECTIVAINPUT,\n                CPG.FECHAEFECTIVAINPUT,\n                AAPPG.FECHAEFECTIVAINPUT\n            ) AS FECHA_EFECTIVA_CANCELANU,\n\n            COALESCE(\n                CAP.MOTIVOCANCELACIONVIDAAPINPUT,\n                CPG.MOTIVOANULACIONINPUT,\n                AAPPG.MOTIVOANULACIONINPUT\n            ) AS MOTIVO_CANCELANUL,\n\n            CASE\n                WHEN COALESCE(\n                    BASE.DESCRIPCION_EVENTO,\n                    BASE.EVENTO_POLICYDCO\n                ) <> 'Cancelar'\n                    THEN ''\n\n                ELSE\n                    CAP.MOTIVOCANCELACIONVIDAAPINPUT\n            END AS MOTIVOCANCELACION,\n\n            CASE\n                WHEN CAP.PK IS NOT NULL\n                    THEN 'CANCELARVIDAAP'\n\n                WHEN CPG.PK IS NOT NULL\n                    THEN 'CANCELARPYS'\n\n                WHEN AAPPG.PK IS NOT NULL\n                    THEN 'ANULAR'\n\n                ELSE NULL\n            END AS FUENTE_CANCELANUL\n\n        FROM BASE_SATELITES_CON_EVENTOS BASE\n\n        LEFT JOIN CANCELARVIDAAP CAP\n            ON CAP.PK =\n               BASE.ID_EVENTO_DCO\n\n        LEFT JOIN CANCELARPYS CPG\n            ON CPG.PK =\n               BASE.ID_EVENTO_DCO\n\n        LEFT JOIN ANULAR AAPPG\n            ON AAPPG.PK =\n               BASE.ID_EVENTO_DCO\n    ")
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        BASE_SATELITES_CON_CANCELACIONES AS\n\n        SELECT\n            BASE.*,\n\n            CAN.MOTIVO_CANCELACION_VIDA_AP,\n            CAN.MOTIVO_CANCELAR_PYS,\n            CAN.MOTIVO_ANULAR,\n            CAN.FECHA_MOV_CANCELANUL,\n            CAN.FECHA_EFECTIVA_CANCELANU,\n            CAN.MOTIVO_CANCELANUL,\n            CAN.MOTIVOCANCELACION,\n            CAN.FUENTE_CANCELANUL\n\n        FROM BASE_SATELITES_CON_EVENTOS BASE\n\n        LEFT JOIN CANCELACIONES_SATELITES CAN\n            ON CAN.IDPOLIZA =\n               BASE.IDPOLIZA\n\n           AND CAN.NRO_OPERACION =\n               BASE.NRO_OPERACION\n\n           AND CAN.UNIDAD_RIESGO =\n               BASE.UNIDAD_RIESGO\n\n           AND CAN.ID_EVENTO_DCO <=>\n               BASE.ID_EVENTO_DCO\n    ')
    base = spark.table('BASE_SATELITES_CON_EVENTOS')
    resultado = spark.table('BASE_SATELITES_CON_CANCELACIONES')
    columnas_requeridas = {'ID_EVENTO_DCO', 'MOTIVOCANCELACION', 'MOTIVO_CANCELANUL', 'FECHA_MOV_CANCELANUL', 'FECHA_EFECTIVA_CANCELANU', 'FUENTE_CANCELANUL'}
    faltantes = sorted(columnas_requeridas - set(resultado.columns))
    if faltantes:
        raise ValueError('Cancelaciones Satelites sin columnas requeridas: ' + ', '.join(faltantes))
    total_base = base.count()
    total_resultado = resultado.count()
    if total_resultado != total_base:
        raise ValueError(f'Cancelaciones alteraron la cardinalidad: base={total_base}, resultado={total_resultado}')
    resumen_fuentes = {'CANCELARVIDAAP': resultado.filter(F.col('FUENTE_CANCELANUL') == 'CANCELARVIDAAP').count(), 'CANCELARPYS': resultado.filter(F.col('FUENTE_CANCELANUL') == 'CANCELARPYS').count(), 'ANULAR': resultado.filter(F.col('FUENTE_CANCELANUL') == 'ANULAR').count()}
    con_cancelacion = resultado.filter(F.col('FUENTE_CANCELANUL').isNotNull()).count()
    return {'dataframe': resultado, 'total_base': total_base, 'total_resultado': total_resultado, 'con_cancelacion': con_cancelacion, 'sin_cancelacion': total_resultado - con_cancelacion, 'resumen_fuentes': resumen_fuentes, 'duplicados_por_tabla': duplicados_por_tabla}

def preparar_coberturas(spark):
    """
    ramos contables de coberturas por
    OPERATIONPK antes de unirlos con la base.

    Replica las expresiones del SQL funcional:

    CODIGO_RAMO_CONTABLE_COBERTURA:
        MAX(COB.COBRAMOCONTABLEVALUE)

    RAMO_CONTABLE_COBERTURA:
        MAX(RSK.REK_DESCRIPTION)

    Relaciones:
    - COVERAGEDCO.DCOID = COBERTURA.PK.
    - COBERTURA.COBRAMOCONTABLEVALUE se normaliza
      eliminando solamente el sufijo '.0'.
    - El codigo normalizado se relaciona con
      STRI_REINSURANCEKIND.REK_CODE.
    """
    duplicados_reinsurancekind = spark.table('STRI_REINSURANCEKIND').withColumn('REK_CODE_NORMALIZADO', F.regexp_replace(F.col('REK_CODE').cast('string'), '\\.0$', '')).filter(F.col('REK_CODE_NORMALIZADO').isNotNull()).groupBy('REK_CODE_NORMALIZADO').count().filter(F.col('count') > 1).count()
    if duplicados_reinsurancekind:
        raise ValueError('STRI_REINSURANCEKIND tiene REK_CODE normalizado duplicado: ' + str(duplicados_reinsurancekind))
    spark.sql("\n        CREATE OR REPLACE TEMP VIEW\n        COBERTURAS_DETALLE_SATELITES AS\n\n        SELECT\n            CDCO.OPERATIONPK\n                AS NRO_OPERACION,\n\n            COB.COBRAMOCONTABLEVALUE\n                AS CODIGO_RAMO_CONTABLE_ORIGINAL,\n\n            REGEXP_REPLACE(\n                CAST(\n                    COB.COBRAMOCONTABLEVALUE\n                    AS STRING\n                ),\n                '\\\\.0$',\n                ''\n            ) AS CODIGO_RAMO_CONTABLE_NORMALIZADO,\n\n            RSK.REK_DESCRIPTION\n                AS RAMO_CONTABLE_DESCRIPCION\n\n        FROM COVERAGEDCO CDCO\n\n        INNER JOIN COBERTURA COB\n            ON COB.PK =\n               CDCO.DCOID\n\n        LEFT JOIN STRI_REINSURANCEKIND RSK\n            ON REGEXP_REPLACE(\n                   CAST(\n                       RSK.REK_CODE\n                       AS STRING\n                   ),\n                   '\\\\.0$',\n                   ''\n               )\n               =\n               REGEXP_REPLACE(\n                   CAST(\n                       COB.COBRAMOCONTABLEVALUE\n                       AS STRING\n                   ),\n                   '\\\\.0$',\n                   ''\n               )\n    ")
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        COBERTURAS_AGREGADAS_SATELITES AS\n\n        SELECT\n            NRO_OPERACION,\n\n            MAX(\n                CODIGO_RAMO_CONTABLE_ORIGINAL\n            ) AS CODIGO_RAMO_CONTABLE_COBERTURA,\n\n            MAX(\n                RAMO_CONTABLE_DESCRIPCION\n            ) AS RAMO_CONTABLE_COBERTURA,\n\n            COUNT(*)\n                AS TOTAL_COBERTURAS_OPERACION,\n\n            COUNT(\n                DISTINCT\n                CODIGO_RAMO_CONTABLE_NORMALIZADO\n            ) AS TOTAL_RAMOS_CONTABLES_OPERACION\n\n        FROM COBERTURAS_DETALLE_SATELITES\n\n        GROUP BY\n            NRO_OPERACION\n    ')
    duplicados_agregado = spark.table('COBERTURAS_AGREGADAS_SATELITES').groupBy('NRO_OPERACION').count().filter(F.col('count') > 1).count()
    if duplicados_agregado:
        raise ValueError('Coberturas agregadas duplicadas por NRO_OPERACION: ' + str(duplicados_agregado))
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        BASE_SATELITES_CON_COBERTURAS AS\n\n        SELECT\n            BASE.*,\n\n            COB.CODIGO_RAMO_CONTABLE_COBERTURA,\n\n            COB.RAMO_CONTABLE_COBERTURA,\n\n            COB.TOTAL_COBERTURAS_OPERACION,\n\n            COB.TOTAL_RAMOS_CONTABLES_OPERACION\n\n        FROM\n            BASE_SATELITES_CON_CANCELACIONES\n            BASE\n\n        LEFT JOIN\n            COBERTURAS_AGREGADAS_SATELITES\n            COB\n\n            ON COB.NRO_OPERACION =\n               BASE.NRO_OPERACION\n    ')
    base = spark.table('BASE_SATELITES_CON_CANCELACIONES')
    resultado = spark.table('BASE_SATELITES_CON_COBERTURAS')
    columnas_requeridas = {'NRO_OPERACION', 'CODIGO_RAMO_CONTABLE_COBERTURA', 'RAMO_CONTABLE_COBERTURA', 'TOTAL_COBERTURAS_OPERACION', 'TOTAL_RAMOS_CONTABLES_OPERACION'}
    faltantes = sorted(columnas_requeridas - set(resultado.columns))
    if faltantes:
        raise ValueError('Coberturas Satelites sin columnas: ' + ', '.join(faltantes))
    total_base = base.count()
    total_resultado = resultado.count()
    if total_resultado != total_base:
        raise ValueError(f'Coberturas alteraron la cardinalidad: base={total_base}, resultado={total_resultado}')
    con_cobertura = resultado.filter(F.col('TOTAL_COBERTURAS_OPERACION').isNotNull()).count()
    con_ramo_contable = resultado.filter(F.col('CODIGO_RAMO_CONTABLE_COBERTURA').isNotNull()).count()
    multiples_ramos = resultado.filter(F.coalesce(F.col('TOTAL_RAMOS_CONTABLES_OPERACION'), F.lit(0)) > 1).count()
    return {'dataframe': resultado, 'total_base': total_base, 'total_resultado': total_resultado, 'con_cobertura': con_cobertura, 'sin_cobertura': total_resultado - con_cobertura, 'con_ramo_contable': con_ramo_contable, 'multiples_ramos': multiples_ramos, 'duplicados_agregado': duplicados_agregado, 'duplicados_reinsurancekind': duplicados_reinsurancekind}

def preparar_productos_especificos(spark):
    """
    Integra atributos específicos de producto y
    resuelve las columnas finales de ramo.

    Relaciones verificadas en el SQL funcional:

    POPROTECCIONSALUD.PK =
        PREPOLICY.PK.

    POPROTECCIONVIDA.PK =
        PREPOLICY.PK.

    POPRACTISEGURO.STATIC =
        POLICYDCO.AGREGATEDOBJECTID.

    POACCPERSONALES.PK =
        POLICYDCO.DCOID.

    POVIDAAP.PK =
        POLICYDCO.DCOID.

    POPETLOVER.PK =
        POLICYDCO.DCOID.

    Para los productos 55119, 55060 y 55059,
    el ramo se obtiene de Protección Salud o
    Protección Vida.

    Para los demás productos:
    - CODIGO_RAMO y RAMO vienen de PREPRODUCT.
    - CODIGO_RAMO_CONTABLE y RAMO_CONTABLE
      vienen de coberturas agregadas.
    """
    validaciones_unicidad = [('POPROTECCIONSALUD', 'PK'), ('POPROTECCIONVIDA', 'PK'), ('POACCPERSONALES', 'PK'), ('POVIDAAP', 'PK'), ('POPETLOVER', 'PK'), ('POPROTECCIONVIDA', 'PK')]
    duplicados_por_fuente = {}
    for tabla, llave in validaciones_unicidad:
        duplicados = spark.table(tabla).filter(F.col(llave).isNotNull()).groupBy(llave).count().filter(F.col('count') > 1).count()
        duplicados_por_fuente[tabla] = duplicados
        if duplicados:
            raise ValueError(f'{tabla} tiene {llave} duplicada: {duplicados}')
    duplicados_povps = spark.table('POPRACTISEGURO').filter(F.col('STATIC').isNotNull()).groupBy('STATIC').count().filter(F.col('count') > 1).count()
    duplicados_por_fuente['POPRACTISEGURO'] = duplicados_povps
    if duplicados_povps:
        raise ValueError('POPRACTISEGURO tiene STATIC duplicado: ' + str(duplicados_povps))
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        PRODUCTOS_ESPECIFICOS_SATELITES AS\n\n        SELECT\n            BASE.IDPOLIZA,\n            BASE.NRO_OPERACION,\n            BASE.UNIDAD_RIESGO,\n\n            POSAL.RAMOBANCASEGUROSVALUE\n                AS CODIGO_RAMO_SALUD,\n\n            POSAL.RAMOBANCASEGUROSINPUT\n                AS RAMO_SALUD,\n\n            POVDA.RAMOBANCASEGUROSVALUE\n                AS CODIGO_RAMO_VIDA,\n\n            POVDA.RAMOBANCASEGUROSINPUT\n                AS RAMO_VIDA,\n\n            POVPS.PROMOTORINPUT\n                AS PROMOTOR_PRACTISEGURO,\n\n            PREAPL.PROMOTORINPUT\n                AS PROMOTOR_PETLOVER,\n\n            POVPS.TIPONEGOCIOGASINPUT\n                AS TIPO_NEGOCIO_PRACTISEGURO,\n\n            PREAPL.TIPONEGOCIOGASINPUT\n                AS TIPO_NEGOCIO_PETLOVER,\n\n            POVPS.INDORIGENINPUT\n                AS ORIGEN_PRACTISEGURO,\n\n            PREAP.INDORIGENINPUT\n                AS ORIGEN_ACCIDENTES_PERSONALES,\n\n            PREAPL.INDORIGENINPUT\n                AS ORIGEN_PETLOVER,\n\n            POSAL.INDORIGENINPUT\n                AS ORIGEN_PROTECCION_SALUD,\n\n            POVDA.INDORIGENINPUT\n                AS ORIGEN_PROTECCION_VIDA,\n\n            PREAPD.INDORIGENINPUT\n                AS ORIGEN_VIDA_AP,\n\n            PREAPD.PRODKEYINPUT\n                AS CAMPANA,\n\n            PREAPD.PRODKEYVALUE\n                AS COD_CAMPANA,\n\n            PREAPD.PRODKEYNOMINPUT\n                AS NOMBRE_CAMPANA,\n\n            PREAPD.PRODKEYNOMVALUE\n                AS COD_NOMBRE_CAMPANA,\n\n            COALESCE(\n                POSAL.NOMBREMOVIMIENTOINPUT,\n                POVDA.NOMBREMOVIMIENTOINPUT\n            ) AS DESC_MOVIMIENTO,\n\n            COALESCE(\n                POSAL.LLAVEINPUT,\n                POVDA.LLAVEINPUT\n            ) AS LLAVE_INTEGRAL_PROD,\n\n            COALESCE(\n                POSAL.VIGENCIATECNICAINPUT,\n                POVDA.VIGENCIATECNICAINPUT\n            ) AS VIGENCIA_TECNICA\n\n        FROM BASE_SATELITES_CON_COBERTURAS BASE\n\n        LEFT JOIN POPROTECCIONSALUD POSAL\n            ON POSAL.PK =\n               BASE.ID_PREPOLICY\n\n        LEFT JOIN POPROTECCIONVIDA POVDA\n            ON POVDA.PK =\n               BASE.ID_PREPOLICY\n\n        LEFT JOIN POPRACTISEGURO POVPS\n            ON POVPS.STATIC =\n               BASE.IDPOLIZA\n\n        LEFT JOIN POACCPERSONALES PREAP\n            ON PREAP.PK =\n               BASE.ID_PREPOLICY\n\n        LEFT JOIN POVIDAAP PREAPD\n            ON PREAPD.PK =\n               BASE.ID_PREPOLICY\n\n        LEFT JOIN POPETLOVER PREAPL\n            ON PREAPL.PK =\n               BASE.ID_PREPOLICY\n    ')
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        BASE_SATELITES_CON_PRODUCTOS AS\n\n        SELECT\n            BASE.*,\n\n            CASE\n                WHEN CAST(\n                    BASE.IDPRODUCTO\n                    AS BIGINT\n                ) NOT IN (\n                    55119,\n                    55060,\n                    55059\n                )\n                    THEN BASE.CODIGO_RAMO_BASE\n\n                ELSE COALESCE(\n                    PROD.CODIGO_RAMO_SALUD,\n                    PROD.CODIGO_RAMO_VIDA\n                )\n            END AS CODIGO_RAMO,\n\n            CASE\n                WHEN CAST(\n                    BASE.IDPRODUCTO\n                    AS BIGINT\n                ) NOT IN (\n                    55119,\n                    55060,\n                    55059\n                )\n                    THEN BASE.RAMO_BASE\n\n                ELSE COALESCE(\n                    PROD.RAMO_SALUD,\n                    PROD.RAMO_VIDA\n                )\n            END AS RAMO,\n\n            CASE\n                WHEN CAST(\n                    BASE.IDPRODUCTO\n                    AS BIGINT\n                ) NOT IN (\n                    55119,\n                    55060,\n                    55059\n                )\n                    THEN\n                    BASE.CODIGO_RAMO_CONTABLE_COBERTURA\n\n                ELSE COALESCE(\n                    PROD.CODIGO_RAMO_SALUD,\n                    PROD.CODIGO_RAMO_VIDA\n                )\n            END AS CODIGO_RAMO_CONTABLE,\n\n            CASE\n                WHEN CAST(\n                    BASE.IDPRODUCTO\n                    AS BIGINT\n                ) NOT IN (\n                    55119,\n                    55060,\n                    55059\n                )\n                    THEN\n                    BASE.RAMO_CONTABLE_COBERTURA\n\n                ELSE COALESCE(\n                    PROD.RAMO_SALUD,\n                    PROD.RAMO_VIDA\n                )\n            END AS RAMO_CONTABLE,\n\n            COALESCE(\n                PROD.PROMOTOR_PRACTISEGURO,\n                PROD.PROMOTOR_PETLOVER\n            ) AS PROMOTOR,\n\n            COALESCE(\n                PROD.ORIGEN_PRACTISEGURO,\n                PROD.ORIGEN_ACCIDENTES_PERSONALES,\n                PROD.ORIGEN_PETLOVER,\n                PROD.ORIGEN_PROTECCION_SALUD,\n                PROD.ORIGEN_PROTECCION_VIDA\n            ) AS ORIGEN_DATO,\n\n            COALESCE(\n                PROD.TIPO_NEGOCIO_PRACTISEGURO,\n                PROD.TIPO_NEGOCIO_PETLOVER\n            ) AS TIPO_NEGOCIO,\n\n            PROD.CAMPANA,\n            PROD.COD_CAMPANA,\n            PROD.NOMBRE_CAMPANA,\n            PROD.COD_NOMBRE_CAMPANA,\n            PROD.DESC_MOVIMIENTO,\n            PROD.LLAVE_INTEGRAL_PROD,\n            PROD.VIGENCIA_TECNICA,\n\n            PROD.CODIGO_RAMO_SALUD,\n            PROD.RAMO_SALUD,\n            PROD.CODIGO_RAMO_VIDA,\n            PROD.RAMO_VIDA\n\n        FROM BASE_SATELITES_CON_COBERTURAS BASE\n\n        LEFT JOIN\n            PRODUCTOS_ESPECIFICOS_SATELITES\n            PROD\n\n            ON PROD.IDPOLIZA =\n               BASE.IDPOLIZA\n\n           AND PROD.NRO_OPERACION =\n               BASE.NRO_OPERACION\n\n           AND PROD.UNIDAD_RIESGO =\n               BASE.UNIDAD_RIESGO\n    ')
    base = spark.table('BASE_SATELITES_CON_COBERTURAS')
    resultado = spark.table('BASE_SATELITES_CON_PRODUCTOS')
    columnas_requeridas = {'CODIGO_RAMO', 'RAMO', 'CODIGO_RAMO_CONTABLE', 'RAMO_CONTABLE', 'PROMOTOR', 'ORIGEN_DATO', 'TIPO_NEGOCIO', 'DESC_MOVIMIENTO', 'LLAVE_INTEGRAL_PROD', 'VIGENCIA_TECNICA'}
    faltantes = sorted(columnas_requeridas - set(resultado.columns))
    if faltantes:
        raise ValueError('Productos Satelites sin columnas: ' + ', '.join(faltantes))
    total_base = base.count()
    total_resultado = resultado.count()
    if total_resultado != total_base:
        raise ValueError(f'Productos específicos alteraron la cardinalidad: base={total_base}, resultado={total_resultado}')
    productos_especiales = resultado.filter(F.col('IDPRODUCTO').cast('bigint').isin(55119, 55060, 55059)).count()
    especiales_sin_ramo = resultado.filter(F.col('IDPRODUCTO').cast('bigint').isin(55119, 55060, 55059)).filter(F.col('CODIGO_RAMO').isNull() & F.col('RAMO').isNull()).count()
    registros_sin_ramo_contable = resultado.filter(F.col('CODIGO_RAMO_CONTABLE').isNull() & F.col('RAMO_CONTABLE').isNull()).count()
    return {'dataframe': resultado, 'total_base': total_base, 'total_resultado': total_resultado, 'productos_especiales': productos_especiales, 'especiales_sin_ramo': especiales_sin_ramo, 'registros_sin_ramo_contable': registros_sin_ramo_contable, 'duplicados_por_fuente': duplicados_por_fuente}

def preparar_terceros(spark):
    """
    Sustituye las subconsultas Oracle relacionadas
    con terceros por vistas agregadas y joins.

    Participantes de poliza:
    - Tomador: ROL_DESCRIPTION contiene TOMADOR.
    - Pagador Maestro: contiene MAESTRO y el DCO
      de participacion tiene STATUS = 1.
    - Sponsor: ROL_DESCRIPTION = SPONSOR.
    - Agente: ROL_DESCRIPTION contiene AGENTE.

    Asegurado:
    - Participacion de objeto asegurado.
    - PPDCO.STATUS = 1.
    - PPDCO.OPERATIONPK = NRO_OPERACION.
    - ROL_DESCRIPTION contiene ASEGURADO.
    - Las columnas se agregan con MAX, igual que
      las subconsultas del SQL fuente.

    Para las expresiones Oracle ROWNUM <= 1 se usa
    ROW_NUMBER con orden deterministico.
    """
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        ASEGURADOVIDA_POR_TERCERO AS\n\n        SELECT\n            TP.THIRDPARTYID,\n\n            MAX(\n                AV.FECHANACIMIENTOINPUT\n            ) AS FECHA_NACIMIENTO_TERCERO,\n\n            MAX(\n                AV.SEXOINPUT\n            ) AS GENERO_TERCERO\n\n        FROM ASEGURADOVIDA AV\n\n        INNER JOIN THIRDPARTYROLE TP\n            ON TP.IDDCOROLE =\n               AV.PK\n\n        GROUP BY\n            TP.THIRDPARTYID\n    ')
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        TERCEROS_POLIZA_DETALLE AS\n\n        SELECT\n            PP.AGREGATEDPARENTID\n                AS IDPOLIZA,\n\n            PPD.OPERATIONPK\n                AS NRO_OPERACION_PARTICIPACION,\n\n            PP.AGREGATEDOBJECTID\n                AS ID_PARTICIPACION,\n\n            PP.THIRDPARTYID\n                AS ID_TERCERO,\n\n            PP.ROL_ID\n                AS ID_ROL,\n\n            UPPER(\n                ROL.ROL_DESCRIPTION\n            ) AS DESCRIPCION_ROL,\n\n            PPD.STATUS\n                AS STATUS_PARTICIPACION,\n\n            PT.DOCUMENTOIDENTIDADINPUT\n                AS IDENTIFICACION_TERCERO,\n\n            PT.NOMBREPREDETERMINADOINPUT\n                AS NOMBRE_TERCERO,\n\n            AV.FECHA_NACIMIENTO_TERCERO,\n\n            AV.GENERO_TERCERO\n\n        FROM STPO_POLICYPARTICIPATION PP\n\n        INNER JOIN\n            STPO_POLICYPARTICIPATIONDCO\n            PPD\n\n            ON PPD.AGREGATEDOBJECTID =\n               PP.AGREGATEDOBJECTID\n\n        INNER JOIN STTS_ROLE ROL\n            ON ROL.ROL_ID =\n               PP.ROL_ID\n\n        INNER JOIN PRETHIRDPARTY PT\n            ON PT.STATIC =\n               PP.THIRDPARTYID\n\n        LEFT JOIN\n            ASEGURADOVIDA_POR_TERCERO AV\n\n            ON AV.THIRDPARTYID =\n               PT.STATIC\n    ')
    spark.sql("\n        CREATE OR REPLACE TEMP VIEW\n        TOMADOR_CANDIDATOS_SATELITES AS\n\n        SELECT\n            DET.*,\n\n            ROW_NUMBER() OVER (\n                PARTITION BY\n                    DET.IDPOLIZA\n\n                ORDER BY\n                    CASE\n                        WHEN CAST(\n                            DET.STATUS_PARTICIPACION\n                            AS STRING\n                        ) = '1'\n                            THEN 0\n                        ELSE 1\n                    END,\n                    DET.ID_PARTICIPACION DESC,\n                    DET.ID_TERCERO DESC\n            ) AS ORDEN_TOMADOR\n\n        FROM TERCEROS_POLIZA_DETALLE DET\n\n        WHERE DET.DESCRIPCION_ROL\n            LIKE '%TOMADOR%'\n    ")
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        TOMADOR_SATELITES AS\n\n        SELECT\n            IDPOLIZA,\n\n            IDENTIFICACION_TERCERO\n                AS IDENTIFICACION_TOMADOR,\n\n            NOMBRE_TERCERO\n                AS TOMADOR,\n\n            FECHA_NACIMIENTO_TERCERO\n                AS FECHA_NACIMIENTO_TOMADOR,\n\n            GENERO_TERCERO\n                AS GENERO\n\n        FROM TOMADOR_CANDIDATOS_SATELITES\n\n        WHERE ORDEN_TOMADOR = 1\n    ')
    spark.sql("\n        CREATE OR REPLACE TEMP VIEW\n        DIRECCION_TOMADOR_CANDIDATOS AS\n\n        SELECT\n            PP.AGREGATEDPARENTID\n                AS IDPOLIZA,\n\n            DIR.DEPARTAMENTOINPUT\n                AS DEPARTAMENTO_TOM,\n\n            DIR.CIUDADINPUT\n                AS CIUDAD_TOM,\n\n            CONCAT(\n                SUBSTRING(\n                    CAST(\n                        DIR.DEPARTAMENTOVALUE\n                        AS STRING\n                    ),\n                    1,\n                    GREATEST(\n                        LENGTH(\n                            CAST(\n                                DIR.DEPARTAMENTOVALUE\n                                AS STRING\n                            )\n                        ) - 2,\n                        0\n                    )\n                ),\n                LPAD(\n                    REGEXP_REPLACE(\n                        CAST(\n                            DIR.CIUDADVALUE\n                            AS STRING\n                        ),\n                        '\\.0$',\n                        ''\n                    ),\n                    3,\n                    '0'\n                )\n            ) AS DIVIPOL_TOM,\n\n            CAST(\n                DIR.DIRECCIONINPUT\n                AS STRING\n            ) AS DIRECION_TOM,\n\n            ROW_NUMBER() OVER (\n                PARTITION BY\n                    PP.AGREGATEDPARENTID\n\n                ORDER BY\n                    PP.AGREGATEDOBJECTID DESC,\n                    PP.THIRDPARTYID DESC,\n                    DIR.PK DESC\n            ) AS ORDEN_DIRECCION\n\n        FROM STPO_POLICYPARTICIPATION PP\n\n        INNER JOIN\n            STPO_POLICYPARTICIPATIONDCO\n            PPD\n\n            ON PPD.AGREGATEDOBJECTID =\n               PP.AGREGATEDOBJECTID\n\n        INNER JOIN STTS_ROLE ROL\n            ON ROL.ROL_ID =\n               PP.ROL_ID\n\n           AND ROL.ROL_ID = 25935\n\n        INNER JOIN PRETHIRDPARTY PT\n            ON PT.STATIC =\n               PP.THIRDPARTYID\n\n        INNER JOIN STTE_THIRDPARTY THP\n            ON THP.TPT_ID =\n               PT.STATIC\n\n        INNER JOIN\n            STTE_THIRDPARTYADDRESSBOOK\n            THPB\n\n            ON THPB.TPT_ID =\n               THP.TPT_ID\n\n           AND CAST(\n               THPB.ISDEFAULTADDRESS\n               AS STRING\n           ) = '1'\n\n        INNER JOIN DIRECCION DIR\n            ON DIR.PK =\n               THPB.IDDCO\n    ")
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        DIRECCION_TOMADOR_SATELITES AS\n\n        SELECT\n            IDPOLIZA,\n            DEPARTAMENTO_TOM,\n            CIUDAD_TOM,\n            DIVIPOL_TOM,\n            DIRECION_TOM\n\n        FROM DIRECCION_TOMADOR_CANDIDATOS\n\n        WHERE ORDEN_DIRECCION = 1\n    ')
    spark.sql("\n        CREATE OR REPLACE TEMP VIEW\n        PAGADOR_MAESTRO_SATELITES AS\n\n        SELECT\n            IDPOLIZA,\n\n            MAX(\n                CONCAT(\n                    COALESCE(\n                        IDENTIFICACION_TERCERO,\n                        ''\n                    ),\n                    '-',\n                    COALESCE(\n                        NOMBRE_TERCERO,\n                        ''\n                    )\n                )\n            ) AS INFORMACION_PAGADOR_MAESTRO\n\n        FROM TERCEROS_POLIZA_DETALLE\n\n        WHERE DESCRIPCION_ROL\n            LIKE '%MAESTRO%'\n\n          AND CAST(\n              STATUS_PARTICIPACION\n              AS STRING\n          ) = '1'\n\n        GROUP BY\n            IDPOLIZA\n    ")
    spark.sql("\n        CREATE OR REPLACE TEMP VIEW\n        SPONSOR_CANDIDATOS_SATELITES AS\n\n        SELECT\n            IDPOLIZA,\n            NOMBRE_TERCERO,\n\n            ROW_NUMBER() OVER (\n                PARTITION BY\n                    IDPOLIZA\n\n                ORDER BY\n                    ID_PARTICIPACION DESC,\n                    ID_TERCERO DESC\n            ) AS ORDEN_SPONSOR\n\n        FROM TERCEROS_POLIZA_DETALLE\n\n        WHERE DESCRIPCION_ROL =\n            'SPONSOR'\n    ")
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        SPONSOR_SATELITES AS\n\n        SELECT\n            IDPOLIZA,\n\n            NOMBRE_TERCERO\n                AS SPONSOR\n\n        FROM SPONSOR_CANDIDATOS_SATELITES\n\n        WHERE ORDEN_SPONSOR = 1\n    ')
    spark.sql("\n        CREATE OR REPLACE TEMP VIEW\n        AGENTE_CANDIDATOS_SATELITES AS\n\n        SELECT\n            IDPOLIZA,\n            NOMBRE_TERCERO,\n\n            ROW_NUMBER() OVER (\n                PARTITION BY\n                    IDPOLIZA\n\n                ORDER BY\n                    ID_PARTICIPACION DESC,\n                    ID_TERCERO DESC\n            ) AS ORDEN_AGENTE\n\n        FROM TERCEROS_POLIZA_DETALLE\n\n        WHERE DESCRIPCION_ROL\n            LIKE '%AGENTE%'\n    ")
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        AGENTE_SATELITES AS\n\n        SELECT\n            IDPOLIZA,\n\n            NOMBRE_TERCERO\n                AS AGENTE\n\n        FROM AGENTE_CANDIDATOS_SATELITES\n\n        WHERE ORDEN_AGENTE = 1\n    ')
    spark.sql("\n        CREATE OR REPLACE TEMP VIEW\n        ASEGURADO_SATELITES AS\n\n        SELECT\n            PPDCO.OPERATIONPK\n                AS NRO_OPERACION,\n\n            MAX(\n                PT.TIPODOCUMENTOINPUT\n            ) AS TIP_IDENT_ASEGURADO,\n\n            MAX(\n                PT.DOCUMENTOIDENTIDADINPUT\n            ) AS IDENT_ASEGURADO,\n\n            MAX(\n                PT.NOMBREPREDETERMINADOINPUT\n            ) AS ASEGURADO\n\n        FROM STPO_INSOBJPARTICIPATION PP\n\n        INNER JOIN\n            STPO_INSOBJPARTICIPATIONDCO\n            PPDCO\n\n            ON PPDCO.AGREGATEDOBJECTID =\n               PP.AGREGATEDOBJECTID\n\n           AND CAST(\n               PPDCO.STATUS\n               AS STRING\n           ) = '1'\n\n        INNER JOIN STTS_ROLE ROL\n            ON ROL.ROL_ID =\n               PP.ROL_ID\n\n           AND UPPER(\n               ROL.ROL_DESCRIPTION\n           ) LIKE '%ASEGURADO%'\n\n        INNER JOIN\n            AGREGATEDINSURANCEOBJECT AGO\n\n            ON AGO.AGREGATEDINSURANCEOBJECTID =\n               PP.AGREGATEDPARENTID\n\n        INNER JOIN PRETHIRDPARTY PT\n            ON PT.STATIC =\n               PP.THIRDPARTYID\n\n        GROUP BY\n            PPDCO.OPERATIONPK\n    ")
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        BASE_SATELITES_CON_TERCEROS AS\n\n        SELECT\n            BASE.*,\n\n            TOM.IDENTIFICACION_TOMADOR,\n            TOM.TOMADOR,\n\n            DIR.DEPARTAMENTO_TOM,\n            DIR.CIUDAD_TOM,\n            DIR.DIVIPOL_TOM,\n            DIR.DIRECION_TOM,\n\n            PAG.INFORMACION_PAGADOR_MAESTRO,\n\n            ASEG.TIP_IDENT_ASEGURADO,\n            ASEG.IDENT_ASEGURADO,\n            ASEG.ASEGURADO,\n\n            SP.SPONSOR,\n\n            TOM.FECHA_NACIMIENTO_TOMADOR\n                AS FECHA_NACER_ASEG,\n\n            TOM.GENERO,\n\n            AGE.AGENTE\n\n        FROM BASE_SATELITES_CON_PRODUCTOS\n            BASE\n\n        LEFT JOIN TOMADOR_SATELITES TOM\n            ON TOM.IDPOLIZA =\n               BASE.IDPOLIZA\n\n        LEFT JOIN\n            DIRECCION_TOMADOR_SATELITES\n            DIR\n\n            ON DIR.IDPOLIZA =\n               BASE.IDPOLIZA\n\n        LEFT JOIN\n            PAGADOR_MAESTRO_SATELITES\n            PAG\n\n            ON PAG.IDPOLIZA =\n               BASE.IDPOLIZA\n\n        LEFT JOIN ASEGURADO_SATELITES ASEG\n            ON ASEG.NRO_OPERACION =\n               BASE.NRO_OPERACION\n\n        LEFT JOIN SPONSOR_SATELITES SP\n            ON SP.IDPOLIZA =\n               BASE.IDPOLIZA\n\n        LEFT JOIN AGENTE_SATELITES AGE\n            ON AGE.IDPOLIZA =\n               BASE.IDPOLIZA\n    ')
    base = spark.table('BASE_SATELITES_CON_PRODUCTOS')
    resultado = spark.table('BASE_SATELITES_CON_TERCEROS')
    columnas_requeridas = {'IDENTIFICACION_TOMADOR', 'TOMADOR', 'DEPARTAMENTO_TOM', 'CIUDAD_TOM', 'DIVIPOL_TOM', 'DIRECION_TOM', 'INFORMACION_PAGADOR_MAESTRO', 'TIP_IDENT_ASEGURADO', 'IDENT_ASEGURADO', 'ASEGURADO', 'SPONSOR', 'GENERO', 'AGENTE'}
    faltantes = sorted(columnas_requeridas - set(resultado.columns))
    if faltantes:
        raise ValueError('Terceros Satelites sin columnas: ' + ', '.join(faltantes))
    total_base = base.count()
    total_resultado = resultado.count()
    if total_resultado != total_base:
        raise ValueError(f'Terceros alteraron la cardinalidad: base={total_base}, resultado={total_resultado}')
    metricas = {'con_tomador': resultado.filter(F.col('TOMADOR').isNotNull()).count(), 'con_direccion_tomador': resultado.filter(F.col('DIRECION_TOM').isNotNull()).count(), 'con_pagador_maestro': resultado.filter(F.col('INFORMACION_PAGADOR_MAESTRO').isNotNull()).count(), 'con_asegurado': resultado.filter(F.col('ASEGURADO').isNotNull()).count(), 'con_sponsor': resultado.filter(F.col('SPONSOR').isNotNull()).count(), 'con_agente': resultado.filter(F.col('AGENTE').isNotNull()).count()}
    return {'dataframe': resultado, 'total_base': total_base, 'total_resultado': total_resultado, 'metricas': metricas}

def preparar_contactos(spark):
    """
    Reemplaza las funciones Oracle de contacto con
    columnas físicamente disponibles.

    Tomador:
    - Rol 25935 o descripción TOMADOR.
    - Teléfono desde
      PRETHIRDPARTY.TELEFONOOFICINACOMPLETINPUT.
    - Correo desde PRETHIRDPARTY.EMAILINPUT.
    - Selección determinística por IDPOLIZA.

    Asegurado:
    - Participación de objeto asegurado.
    - PPDCO.STATUS = 1.
    - Rol con descripción ASEGURADO.
    - Correo desde PRETHIRDPARTY.EMAILINPUT.
    - Teléfono priorizado desde:
      1. PERSONANATURAL.TELEFONOCELULARINPUT.
      2. PERSONANATURAL.TELEFONOFIJOCOMPLETOINPUT.
      3. PERSONANATURAL.TELEFONOINPUT.
      4. PRETHIRDPARTY.TELEFONOOFICINACOMPLETINPUT.
    - Agregación por NRO_OPERACION.

    No se llama ACSELE_ALFA_BI desde Spark.
    """
    spark.sql("\n        CREATE OR REPLACE TEMP VIEW\n        CONTACTOS_TOMADOR_CANDIDATOS AS\n\n        SELECT\n            PP.AGREGATEDPARENTID\n                AS IDPOLIZA,\n\n            PP.AGREGATEDOBJECTID\n                AS ID_PARTICIPACION,\n\n            PP.THIRDPARTYID\n                AS ID_TERCERO,\n\n            PPD.STATUS\n                AS STATUS_PARTICIPACION,\n\n            PT.TELEFONOOFICINACOMPLETINPUT\n                AS TELEFONO_TOMADOR,\n\n            PT.EMAILINPUT\n                AS EMAIL_TOMADOR,\n\n            ROW_NUMBER() OVER (\n                PARTITION BY\n                    PP.AGREGATEDPARENTID\n\n                ORDER BY\n                    CASE\n                        WHEN CAST(\n                            PPD.STATUS\n                            AS STRING\n                        ) = '1'\n                            THEN 0\n                        ELSE 1\n                    END,\n\n                    PP.AGREGATEDOBJECTID DESC,\n                    PP.THIRDPARTYID DESC\n            ) AS ORDEN_CONTACTO_TOMADOR\n\n        FROM STPO_POLICYPARTICIPATION PP\n\n        INNER JOIN\n            STPO_POLICYPARTICIPATIONDCO\n            PPD\n\n            ON PPD.AGREGATEDOBJECTID =\n               PP.AGREGATEDOBJECTID\n\n        INNER JOIN STTS_ROLE ROL\n            ON ROL.ROL_ID =\n               PP.ROL_ID\n\n        INNER JOIN PRETHIRDPARTY PT\n            ON PT.STATIC =\n               PP.THIRDPARTYID\n\n        WHERE\n            ROL.ROL_ID = 25935\n\n            OR UPPER(\n                ROL.ROL_DESCRIPTION\n            ) LIKE '%TOMADOR%'\n    ")
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        CONTACTOS_TOMADOR_SATELITES AS\n\n        SELECT\n            IDPOLIZA,\n            TELEFONO_TOMADOR,\n            EMAIL_TOMADOR\n\n        FROM CONTACTOS_TOMADOR_CANDIDATOS\n\n        WHERE ORDEN_CONTACTO_TOMADOR = 1\n    ')
    spark.sql("\n        CREATE OR REPLACE TEMP VIEW\n        CONTACTOS_ASEGURADO_DETALLE AS\n\n        SELECT\n            PPDCO.OPERATIONPK\n                AS NRO_OPERACION,\n\n            PP.AGREGATEDOBJECTID\n                AS ID_PARTICIPACION,\n\n            PP.THIRDPARTYID\n                AS ID_TERCERO,\n\n            PT.EMAILINPUT\n                AS EMAIL_ASEGURADO,\n\n            COALESCE(\n                PTN.TELEFONOCELULARINPUT,\n                PTN.TELEFONOFIJOCOMPLETOINPUT,\n                PTN.TELEFONOINPUT,\n                PT.TELEFONOOFICINACOMPLETINPUT\n            ) AS TEL_ASEGURADO\n\n        FROM STPO_INSOBJPARTICIPATION PP\n\n        INNER JOIN\n            STPO_INSOBJPARTICIPATIONDCO\n            PPDCO\n\n            ON PPDCO.AGREGATEDOBJECTID =\n               PP.AGREGATEDOBJECTID\n\n           AND CAST(\n               PPDCO.STATUS\n               AS STRING\n           ) = '1'\n\n        INNER JOIN STTS_ROLE ROL\n            ON ROL.ROL_ID =\n               PP.ROL_ID\n\n           AND UPPER(\n               ROL.ROL_DESCRIPTION\n           ) LIKE '%ASEGURADO%'\n\n        INNER JOIN\n            AGREGATEDINSURANCEOBJECT AGO\n\n            ON AGO.AGREGATEDINSURANCEOBJECTID =\n               PP.AGREGATEDPARENTID\n\n        INNER JOIN PRETHIRDPARTY PT\n            ON PT.STATIC =\n               PP.THIRDPARTYID\n\n        LEFT JOIN PERSONANATURAL PTN\n            ON PTN.STATIC =\n               PT.STATIC\n    ")
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        CONTACTOS_ASEGURADO_SATELITES AS\n\n        SELECT\n            NRO_OPERACION,\n\n            MAX(\n                EMAIL_ASEGURADO\n            ) AS EMAIL_ASEGURADO,\n\n            MAX(\n                TEL_ASEGURADO\n            ) AS TEL_ASEGURADO\n\n        FROM CONTACTOS_ASEGURADO_DETALLE\n\n        GROUP BY\n            NRO_OPERACION\n    ')
    spark.sql('\n        CREATE OR REPLACE TEMP VIEW\n        BASE_SATELITES_CON_CONTACTOS AS\n\n        SELECT\n            BASE.*,\n\n            TOM.TELEFONO_TOMADOR,\n            TOM.EMAIL_TOMADOR,\n\n            ASEG.EMAIL_ASEGURADO,\n            ASEG.TEL_ASEGURADO\n\n        FROM BASE_SATELITES_CON_TERCEROS BASE\n\n        LEFT JOIN\n            CONTACTOS_TOMADOR_SATELITES\n            TOM\n\n            ON TOM.IDPOLIZA =\n               BASE.IDPOLIZA\n\n        LEFT JOIN\n            CONTACTOS_ASEGURADO_SATELITES\n            ASEG\n\n            ON ASEG.NRO_OPERACION =\n               BASE.NRO_OPERACION\n    ')
    base = spark.table('BASE_SATELITES_CON_TERCEROS')
    resultado = spark.table('BASE_SATELITES_CON_CONTACTOS')
    columnas_requeridas = {'TELEFONO_TOMADOR', 'EMAIL_TOMADOR', 'EMAIL_ASEGURADO', 'TEL_ASEGURADO'}
    faltantes = sorted(columnas_requeridas - set(resultado.columns))
    if faltantes:
        raise ValueError('Contactos Satelites sin columnas: ' + ', '.join(faltantes))
    total_base = base.count()
    total_resultado = resultado.count()
    if total_resultado != total_base:
        raise ValueError(f'Contactos alteraron la cardinalidad: base={total_base}, resultado={total_resultado}')
    duplicados_tomador = spark.table('CONTACTOS_TOMADOR_SATELITES').groupBy('IDPOLIZA').count().filter(F.col('count') > 1).count()
    duplicados_asegurado = spark.table('CONTACTOS_ASEGURADO_SATELITES').groupBy('NRO_OPERACION').count().filter(F.col('count') > 1).count()
    if duplicados_tomador or duplicados_asegurado:
        raise ValueError(f'Contactos agregados duplicados: tomador={duplicados_tomador}, asegurado={duplicados_asegurado}')
    metricas = {'telefono_tomador': resultado.filter(F.col('TELEFONO_TOMADOR').isNotNull()).count(), 'email_tomador': resultado.filter(F.col('EMAIL_TOMADOR').isNotNull()).count(), 'email_asegurado': resultado.filter(F.col('EMAIL_ASEGURADO').isNotNull()).count(), 'telefono_asegurado': resultado.filter(F.col('TEL_ASEGURADO').isNotNull()).count()}
    return {'dataframe': resultado, 'total_base': total_base, 'total_resultado': total_resultado, 'metricas': metricas, 'duplicados_tomador': duplicados_tomador, 'duplicados_asegurado': duplicados_asegurado}

def preparar_movimientos(spark):
    """
    Agrega THIRDPARTYMOVEMENTPOLICY una sola vez por:

        OPERATIONPK + POLICYID

    Implementa las doce reglas respaldadas directamente
    por E1 SATELITE VFF.sql.

    Las cuatro columnas de FN_VALORES_TRIBUTARIOS quedan
    NULL hasta contar con la definición Oracle oficial:

    - IVA_COMIS_AGE
    - RETEICA_AGENTE
    - RETEFTE_AGENTE
    - RETIVA_AGENTE

    No se reemplazan con cero porque cero sería un valor
    financiero válido y ocultaría una regla pendiente.
    """
    movimientos = spark.table('THIRDPARTYMOVEMENTPOLICY').withColumn('CONCEPT_NORMALIZADO', F.upper(F.col('CONCEPT'))).withColumn('MONTO_NORMALIZADO', F.coalesce(F.col('AMMOUNT').cast('decimal(38,8)'), F.lit(0).cast('decimal(38,8)'))).filter(F.col('OPERATIONPK').isNotNull() & F.col('POLICYID').isNotNull())
    prima = ['PRIMA', 'PRIMAREHAB', 'PRIMAANU', 'PRIMADEV', 'PRIMAPERIODOPROVIS', 'PRIMAEMITIDAIND', 'PRIMAREHABIND', 'PRIMAANUIND', 'PRIMADEVUELTAIND', 'PRIMAPERIODOPROVISIND', 'PRIMAEMITIDAPAGVIDAAP', 'PRIMAEMITIDAVIDAAP', 'PRIMAEMITIDAPAGDEVVIDAAP', 'PRIMAEMITIDAANUVIDAAP', 'PRIMAEMITIDADEVVIDAAP', 'PRIMAEMITIDAREHABVIDAAP', 'PRIMAVIDA', 'PRIMAVIDADEV', 'PRIMAVIDAPROVISDEV', 'PRIMAVIDAPROVIS', 'PRIMAEXEQ', 'PRIMAEXEQDEV', 'PRIMAVGR', 'PRIMAVGRDEV', 'PRIMAACC', 'PRIMAACCDEV']
    prima_negativos = ['PRIMAANU', 'PRIMAANUIND', 'PRIMAEMITIDADEVVIDAAP', 'PRIMAVIDADEV', 'PRIMADEV', 'PRIMADEVUELTAIND', 'PRIMAEMITIDAPAGDEVVIDAAP', 'PRIMAEMITIDAANUVIDAAP', 'PRIMAVIDAPROVISDEV', 'PRIMAEXEQDEV', 'PRIMAVGRDEV', 'PRIMAACCDEV']
    comision = ['COMISIONAGENTE', 'COMISIONAGENTEDEV', 'COMISIONVIDA', 'COMISIONVIDADEV', 'COMISIONVIDAIND', 'COMISIONVIDAINDDEV', 'COMISIONPAGVIDAAP', 'COMISIONPAGVIDAAPDEV', 'COMISIONVIDAAP', 'COMISIONVIDAAPDEV']
    comision_negativos = ['COMISIONAGENTEDEV', 'COMISIONVIDAINDDEV', 'COMISIONVIDADEV', 'COMISIONPAGVIDAAPDEV', 'COMISIONVIDAAPDEV']
    costo_recaudo = ['COSTORECAUDACION', 'COSTORECAUDACIONDEV', 'COSTORECAUDOPROVIS', 'COSTORECAUDOREHAB', 'COSTORECAUDOANU', 'COSTORECAUDACIONIND', 'COSTORECAUDACIONDEVIND', 'COSTORECAUDOPROVISIND', 'COSTORECAUDOREHABIND', 'COSTORECAUDOANUIND', 'COSTORECAUDO', 'COSTORECAUDACIONANUVIDAAP', 'COSTORECAUDACIONDEVVIDAAP', 'COSTORECAUDACIONPAGVIDAAP', 'COSTORECAUDACIONREHABVIDAAP', 'COSTORECAUDACIONVIDAAP', 'COMISIONRECAUDOVIDA', 'COMISIONRECAUDOVIDADEV', 'COMISIONRECAUDOVIDAPROVISDEV', 'COMISIONRECAUDOVIDAPROVIS', 'COMISIONRECAUDOEXEQ', 'COMISIONRECAUDOEXEQDEV', 'COMISIONRECAUDOVGR', 'COMISIONRECAUDOVGRDEV', 'COMISIONRECAUDOACC', 'COMISIONRECAUDOACCDEV']
    costo_recaudo_negativos = ['COSTORECAUDACIONDEV', 'COSTORECAUDACIONDEVIND', 'COSTORECAUDACIONDEVVIDAAP', 'COSTORECAUDOANU', 'COSTORECAUDOANUIND', 'COSTORECAUDACIONANUVIDAAP', 'COMISIONRECAUDOVIDADEV', 'COMISIONRECAUDOVIDAPROVISDEV', 'COMISIONRECAUDOEXEQDEV', 'COMISIONRECAUDOVGRDEV', 'COMISIONRECAUDOACCDEV']
    iva_recaudo = ['IVACOSTORECAUDACION', 'IVACOSTORECAUDACIONDEV', 'IVACOSTORECAUDOPROVIS', 'IVACOSTORECAUDOREHAB', 'IVACOSTORECAUDOANU', 'IVACOSTORECAUDACIONIND', 'IVACOSTORECAUDACIONDEVIND', 'IVACOSTORECAUDOPROVISIND', 'IVACOSTORECAUDOREHABIND', 'IVACOSTORECAUDOANUIND', 'IVACOSTORECAUDO', 'IVACOSTORECAUDACIONVIDAAP', 'IVACOSTORECAUDACIONPAGVIDAAP', 'IVACOSTORECAUDACIONDEVVIDAAP', 'IVACOSTORECAUDACIONANUVIDAAP', 'IVACOSTORECAUDACIONREHABVIDAAP', 'IVACOMISIONRECAUDOVIDA', 'IVACOMISIONRECAUDOVIDADEV', 'IVACOMISIONRECAUDOVIDAPROVISDEV', 'IVACOMISIONRECAUDOVIDAPROVIS', 'IVACOMISIONRECAUDOEXEQ', 'IVACOMISIONRECAUDOEXEQDEV', 'IVACOMISIONRECAUDOVGR', 'IVACOMISIONRECAUDOVGRDEV', 'IVACOMISIONRECAUDOACC', 'IVACOMISIONRECAUDOACCDEV']
    iva_recaudo_negativos = ['IVACOSTORECAUDACIONDEV', 'IVACOSTORECAUDACIONDEVIND', 'IVACOSTORECAUDACIONDEVVIDAAP', 'IVACOSTORECAUDOANU', 'IVACOSTORECAUDOANUIND', 'IVACOSTORECAUDACIONANUVIDAAP', 'IVACOMISIONRECAUDOVIDADEV', 'IVACOMISIONRECAUDOVIDAPROVISDEV', 'IVACOMISIONRECAUDOEXEQDEV', 'IVACOMISIONRECAUDOVGRDEV', 'IVACOMISIONRECAUDOACCDEV']
    iva_prima = ['IVAPRIMAVIDA', 'IVAPRIMAVIDADEV', 'IVAPRIMAVIDAPROVISDEV', 'IVAPRIMAVIDAPROVIS', 'IVAPRIMAEXEQ', 'IVAPRIMAEXEQDEV', 'IVAPRIMAVGR', 'IVAPRIMAVGRDEV']
    comision_neta = ['COMISIONNETAALFAVIDA', 'COMISIONNETAALFAVIDADEV', 'COMISIONNETAALFAVIDAPROVISDEV', 'COMISIONNETAALFAVIDAPROVIS', 'COMISIONNETAALFAVGR', 'COMISIONNETAALFAVGRDEV', 'COMISIONNETAALFAACC', 'COMISIONNETAALFAACCDEV', 'COMISIONNETAALFAEXEQ', 'COMISIONNETAALFAEXEQDEV']
    reaseguro = ['COMISIONREASEGUROSVIDA', 'COMISIONREASEGUROSVIDADEV', 'COMISIONREASEGUROSVIDAPROVISDEV', 'COMISIONREASEGUROSVIDAPROVIS', 'NETOREASEGUROSEXEQ', 'NETOREASEGUROSEXEQDEV', 'NETOREASEGUROSVGR', 'NETOREASEGUROSVGRDEV', 'NETOREASEGUROSACC', 'NETOREASEGUROSACCDEV', 'NETOREASEGUROSVIDA', 'NETOREASEGUROSVIDADEV']
    tarjeta = ['COMISIONTARJETAVIDA', 'COMISIONTARJETAVIDADEV', 'COMISIONTARJETAVIDAPROVIS', 'COMISIONTARJETAEXEQ', 'COMISIONTARJETAEXEQDEV', 'COMISIONTARJETAVGR', 'COMISIONTARJETAVGRDEV']

    def suma_regla(nombre, conceptos, negativos):
        concepto = F.col('CONCEPT_NORMALIZADO')
        monto = F.col('MONTO_NORMALIZADO')
        return F.round(F.sum(F.when(concepto.isin(*negativos) & (monto > 0), monto * F.lit(-1)).when(concepto.isin(*conceptos), monto).otherwise(F.lit(0).cast('decimal(38,8)'))), 8).alias(nombre)
    agregado = movimientos.groupBy('OPERATIONPK', 'POLICYID').agg(suma_regla('PRIMA', prima, prima_negativos), suma_regla('COMISION_AGENTE', comision, comision_negativos), suma_regla('COSTO_RECAUDACION', costo_recaudo, costo_recaudo_negativos), suma_regla('IVA_COSTO_RECAUDACION', iva_recaudo, iva_recaudo_negativos), suma_regla('GASTOS_EXPEDICION', ['GASTOSEXPEDICION', 'GASTOSEXPEDICIONDEV'], ['GASTOSEXPEDICIONDEV']), F.round(F.sum(F.when(F.col('CONCEPT_NORMALIZADO').isin('SUMAASEGURADAPERIODO', 'SUMAASEGPERIODO', 'TOTALSUMAASEGMUERTE'), F.col('MONTO_NORMALIZADO')).otherwise(F.lit(0).cast('decimal(38,8)'))), 8).alias('SUMA_ASEGURADA_PERIODO'), F.round(F.sum(F.when(F.col('DESCPROPERTY') == 'TotalSumaAsegAuxRepat', F.col('MONTO_NORMALIZADO')).otherwise(F.lit(0).cast('decimal(38,8)'))), 8).alias('SUMA_ASEG_EXEQ_AUX_REPATRIA'), F.round(F.sum(F.when(F.col('DESCPROPERTY') == 'TotalSumaAsegMuerte', F.col('MONTO_NORMALIZADO')).otherwise(F.lit(0).cast('decimal(38,8)'))), 8).alias('SUMA_ASEG_EXEQ_MUERTE'), suma_regla('IVA_PRIMA', iva_prima, ['IVAPRIMAVIDADEV', 'IVAPRIMAVIDAPROVISDEV', 'IVAPRIMAEXEQDEV', 'IVAPRIMAVGRDEV']), suma_regla('COMISION_NETA_ALFA', comision_neta, ['COMISIONNETAALFAVIDADEV', 'COMISIONNETAALFAVIDAPROVISDEV', 'COMISIONNETAALFAVGRDEV', 'COMISIONNETAALFAEXEQDEV', 'COMISIONNETAALFAACCDEV']), suma_regla('VALOR_NETO_REASEGURO_', reaseguro, ['COMISIONREASEGUROSVIDADEV', 'COMISIONREASEGUROSVIDAPROVISDEV', 'NETOREASEGUROSEXEQDEV', 'NETOREASEGUROSVGRDEV', 'NETOREASEGUROSACCDEV', 'NETOREASEGUROSVIDADEV']), suma_regla('COMISION_TARJETACR', tarjeta, ['COMISIONTARJETAVIDADEV', 'COMISIONTARJETAEXEQDEV', 'COMISIONTARJETAVGRDEV'])).withColumnRenamed('OPERATIONPK', 'NRO_OPERACION').withColumnRenamed('POLICYID', 'IDPOLIZA')
    agregado.createOrReplaceTempView('MOVIMIENTOS_AGREGADOS_SATELITES')
    spark.sql("\n        CREATE OR REPLACE TEMP VIEW\n        BASE_SATELITES_CON_MOVIMIENTOS AS\n\n        SELECT\n            BASE.*,\n\n            MOV.PRIMA,\n            MOV.COMISION_AGENTE,\n            MOV.COSTO_RECAUDACION,\n            MOV.IVA_COSTO_RECAUDACION,\n            MOV.GASTOS_EXPEDICION,\n            MOV.SUMA_ASEGURADA_PERIODO,\n            MOV.SUMA_ASEG_EXEQ_AUX_REPATRIA,\n            MOV.SUMA_ASEG_EXEQ_MUERTE,\n            MOV.IVA_PRIMA,\n            MOV.COMISION_NETA_ALFA,\n            MOV.VALOR_NETO_REASEGURO_,\n            MOV.COMISION_TARJETACR,\n\n            CAST(\n                NULL AS DECIMAL(38,8)\n            ) AS IVA_COMIS_AGE,\n\n            CAST(\n                NULL AS DECIMAL(38,8)\n            ) AS RETEICA_AGENTE,\n\n            CAST(\n                NULL AS DECIMAL(38,8)\n            ) AS RETEFTE_AGENTE,\n\n            CAST(\n                NULL AS DECIMAL(38,8)\n            ) AS RETIVA_AGENTE,\n\n            'PENDIENTE_DEFINICION_FN_VALORES_TRIBUTARIOS'\n                AS ESTADO_VALORES_TRIBUTARIOS\n\n        FROM BASE_SATELITES_CON_CONTACTOS BASE\n\n        LEFT JOIN\n            MOVIMIENTOS_AGREGADOS_SATELITES MOV\n\n            ON MOV.NRO_OPERACION =\n               BASE.NRO_OPERACION\n\n           AND MOV.IDPOLIZA =\n               BASE.IDPOLIZA\n    ")
    base = spark.table('BASE_SATELITES_CON_CONTACTOS')
    resultado = spark.table('BASE_SATELITES_CON_MOVIMIENTOS')
    total_base = base.count()
    total_resultado = resultado.count()
    if total_resultado != total_base:
        raise ValueError(f'Movimientos alteraron cardinalidad: {total_base} != {total_resultado}')
    duplicados = spark.table('MOVIMIENTOS_AGREGADOS_SATELITES').groupBy('NRO_OPERACION', 'IDPOLIZA').count().filter(F.col('count') > 1).count()
    if duplicados:
        raise ValueError('Movimientos agregados duplicados: ' + str(duplicados))
    return {'dataframe': resultado, 'total_base': total_base, 'total_resultado': total_resultado, 'duplicados': duplicados, 'tributarios_pendientes': ['IVA_COMIS_AGE', 'RETEICA_AGENTE', 'RETEFTE_AGENTE', 'RETIVA_AGENTE']}

def construir_salida_final(spark, runtime, job_run_id):
    """
    Cierra la salida Silver de Satelites.

    Fuentes físicamente disponibles: 49.
    Columnas funcionales: 125.
    Columnas SCD: 5.

    Las columnas cuya única fuente son objetos Oracle
    no accesibles quedan NULL tipado y trazable.
    """
    columnas_salida = ['IDPOLIZA', 'IDPRODUCTO', 'CODIGO_COMPANIA', 'COMPANIA', 'CODIGO_PRODUCTO', 'PRODUCTO', 'CODIGO_RAMO', 'RAMO', 'CODIGO_RAMO_CONTABLE', 'RAMO_CONTABLE', 'CODIGO_SUCURSAL', 'SUCURSAL', 'IDENTIFICACION_TOMADOR', 'TOMADOR', 'DEPARTAMENTO_TOM', 'CIUDAD_TOM', 'DIVIPOL_TOM', 'DIRECION_TOM', 'TELEFONO_TOMADOR', 'EMAIL_TOMADOR', 'INFORMACION_PAGADOR_MAESTRO', 'TIP_IDENT_ASEGURADO', 'IDENT_ASEGURADO', 'ASEGURADO', 'IDACUERDO', 'NUMERO_POLIZA_MATRIZ', 'NOMBRE_ACUERDO', 'ESTADO_ACUERDO', 'FECHAINI_ACUERDO', 'FECHAFIN_ACUERDO', 'PRODUCTO_DEL_ACUERDO', 'TIPO_POLIZA', 'FRECUENCIA_PAGO', 'NRO_POLIZA', 'CANAL_VENTA', 'PROMOTOR', 'FECHAEMISION', 'PERIODO_EMISION', 'FECHA_INCIAL_POL', 'FECHA_FINAL_POL', 'TIPO_PRODUCCION', 'UNIDAD_NEGOCIO', 'ESTADO_POLIZA', 'ORIGEN_DATO', 'NRO_OPERACION', 'LINEA_CREDITO', 'DESCRIPCION_EVENTO', 'TIPO_NEGOCIO', 'MONEDA_ACUERDO', 'UNIDAD_RIESGO', 'NUMERO_CREDITO', 'NUMERO_POL_GAS', 'NUMERO_CONTRATO', 'PLAN_GASERA', 'DESCRIP_PRODUCTO', 'DESCRIP_VENTA', 'CODIGO_VENTA', 'DPTO_SMARTFLEX', 'LOCALIDA_SMARTFLEX', 'CODIGO_MES_GAS', 'FECHA_INICIAL_UR', 'FECHA_FINAL_UR', 'NRO_OPERACION_POL', 'TIPO_ASEGURADO', 'MONTO_ASEGURADO', 'VLR_ASEGURADO_AUX_REPATRIACION', 'IDENTIF_ASEGURADO', 'FECHA_NACER_ASEG', 'SPONSOR', 'GENERO', 'MOTIVOCANCELACION', 'HIJOS', 'ESTADO_CIVIL', 'CAMPANA', 'COD_CAMPANA', 'NOMBRE_CAMPANA', 'COD_NOMBRE_CAMPANA', 'AGENTE', 'PRIMA_ANUAL', 'PRIMA_MENSUAL', 'PRIMA', 'COMISION_AGENTE', 'COSTO_RECAUDACION', 'IVA_COSTO_RECAUDACION', 'GASTOS_EXPEDICION', 'SUMA_ASEGURADA_PERIODO', 'SUMA_ASEG_EXEQ_AUX_REPATRIA', 'SUMA_ASEG_EXEQ_MUERTE', 'IVA_COMIS_AGE', 'RETEICA_AGENTE', 'RETEFTE_AGENTE', 'RETIVA_AGENTE', 'IVA_PRIMA', 'COMISION_NETA_ALFA', 'VALOR_NETO_REASEGURO_', 'COMISION_TARJETACR', 'ESTADO_FINAL_POL', 'FECHA_MOV_CANCELANUL', 'FECHA_EFECTIVA_CANCELANU', 'MOTIVO_CANCELANUL', 'PORC_COMIS_AGENTE', 'PORC_PART_AGENTE', 'GENERO_ASEGURADO', 'DPTO_ASEGURADO', 'CIUDAD_ASEGURADO', 'DIVIPOL_ASEGURADO', 'TIPO_MASCOTA', 'GENERO_MASCOTA', 'EDAD_MASCOTA', 'RAZA_MASCOTA', 'NOMBRE_MASCOTA', 'TIPO_MASCOTA_DOS_EXEQUIAS', 'NOMBRE_MASCOTA_DOS_EXEQUIAS', 'EMAIL_ASEGURADO', 'TEL_ASEGURADO', 'DESC_MOVIMIENTO', 'LLAVE_INTEGRAL_PROD', 'VIGENCIA_TECNICA', 'PORC_COMIS_RECAUDO', 'PORC_COMIS_REASEGURO', 'VALOR_COMISION_REASEGURO', 'VALOR_COMISION_REASEGURO_EXE', 'VALOR_COMISION_REASEGURO_AP', 'DIRE_ASEGURADO', 'PRIMERA_VIG_DSD_POL']
    columnas_sin_fuente = {'TIPO_ASEGURADO': 'STRING', 'MONTO_ASEGURADO': 'DECIMAL(38,8)', 'VLR_ASEGURADO_AUX_REPATRIACION': 'DECIMAL(38,8)', 'HIJOS': 'STRING', 'ESTADO_CIVIL': 'STRING', 'PRIMA_ANUAL': 'DECIMAL(38,8)', 'PRIMA_MENSUAL': 'DECIMAL(38,8)', 'GENERO_ASEGURADO': 'STRING', 'DPTO_ASEGURADO': 'STRING', 'CIUDAD_ASEGURADO': 'STRING', 'DIVIPOL_ASEGURADO': 'STRING', 'TIPO_MASCOTA_DOS_EXEQUIAS': 'STRING', 'NOMBRE_MASCOTA_DOS_EXEQUIAS': 'STRING', 'DIRE_ASEGURADO': 'STRING', 'VALOR_COMISION_REASEGURO_EXE': 'DECIMAL(38,8)', 'VALOR_COMISION_REASEGURO_AP': 'DECIMAL(38,8)'}
    tributarias_sin_funcion = {'IVA_COMIS_AGE': 'DECIMAL(38,8)', 'RETEICA_AGENTE': 'DECIMAL(38,8)', 'RETEFTE_AGENTE': 'DECIMAL(38,8)', 'RETIVA_AGENTE': 'DECIMAL(38,8)'}
    primera_vigencia = spark.table('POLICYDCO').groupBy(F.col('AGREGATEDOBJECTID').alias('IDPOLIZA')).agg(F.min(F.col('INITIALDATE')).alias('PRIMERA_VIG_DSD_POL'))
    agentes = (
        spark.table('STPO_POLICYPARTICIPATIONDCO').alias('PPD')
        .join(
            spark.table('STPO_POLICYPARTICIPATION').alias('PP'),
            F.col('PPD.AGREGATEDOBJECTID') == F.col('PP.AGREGATEDOBJECTID'),
            'inner',
        )
        .join(
            spark.table('PARTICIPACIONINTERMEDIARIOS').alias('PI'),
            F.col('PPD.DCOID') == F.col('PI.PK'),
            'inner',
        )
        .join(
            spark.table('STTS_ROLE').alias('ROL'),
            F.col('ROL.ROL_ID') == F.col('PP.ROL_ID'),
            'inner',
        )
        .filter(
            F.upper(F.coalesce(F.col('ROL.ROL_DESCRIPTION'), F.lit('')))
            .contains('AGENTE')
        )
        .groupBy(
            F.col('PP.AGREGATEDPARENTID').alias('IDPOLIZA'),
            F.col('PPD.OPERATIONPK').alias('NRO_OPERACION'),
        )
        .agg(
            F.max(F.col('PI.PORCENTAJECOMISIONINPUT'))
            .alias('PORC_COMIS_AGENTE'),
            F.max(F.col('PI.PORCENTAJEPARTICIPACVALUE'))
            .alias('PORC_PART_AGENTE'),
        )
    )
    base = spark.table('BASE_SATELITES_CON_MOVIMIENTOS').join(primera_vigencia, 'IDPOLIZA', 'left').join(agentes, ['IDPOLIZA', 'NRO_OPERACION'], 'left')
    if 'PRODUCTO_DEL_ACUERDO' not in base.columns:
        base = base.withColumn('PRODUCTO_DEL_ACUERDO', F.col('PRODUCTO'))
    if 'PERIODO_EMISION' not in base.columns:
        base = base.withColumn('PERIODO_EMISION', F.date_format(F.coalesce(F.col('FECHA_EMISION'), F.to_timestamp(F.lit('1999-01-01 00:00:00'))), 'yyyyMM'))
    for nombre, tipo in {**columnas_sin_fuente, **tributarias_sin_funcion}.items():
        if nombre not in base.columns:
            base = base.withColumn(nombre, F.lit(None).cast(tipo))
    faltantes_adicionales = [nombre for nombre in columnas_salida if nombre not in base.columns]
    for nombre in faltantes_adicionales:
        base = base.withColumn(nombre, F.lit(None).cast('string'))
    fecha_proceso = F.current_timestamp()
    final = base.select(*columnas_salida).withColumn('periodo_negocio', F.lit(str(runtime['periodo_negocio'])).cast('string')).withColumn('caso_uso', F.lit('satelites').cast('string')).withColumn('calidad_fuentes', F.lit(str(runtime.get('estado_validacion_tecnica') or runtime.get('estado_validacion') or 'SUCCESS')).cast('string')).withColumn('job_run_id', F.lit(str(job_run_id)).cast('string')).withColumn('fecha_proceso', fecha_proceso)
    columnas_finales = columnas_salida + ['periodo_negocio', 'caso_uso', 'calidad_fuentes', 'job_run_id', 'fecha_proceso']
    if final.columns != columnas_finales:
        raise ValueError('Orden final de columnas invalido')
    if len(final.columns) != 130:
        raise ValueError(f'Salida Satelites debe tener 130 columnas; tiene {len(final.columns)}')
    return {'dataframe': final, 'columnas_funcionales': columnas_salida, 'columnas_finales': columnas_finales, 'faltantes_adicionales': faltantes_adicionales, 'columnas_sin_fuente': sorted(columnas_sin_fuente), 'tributarias_sin_funcion': sorted(tributarias_sin_funcion)}

def actualizar_runtime(ruta_runtime, runtime, salida, total, informe):
    runtime.update(estado_preparacion_silver='SUCCESS', ruta_silver_preparada=salida, total_registros_silver_preparada=total, fecha_preparacion_silver=informe['fecha_preparacion'], modo_escritura_silver_preparada='errorifexists', silver_preparada_historica=False, silver_preparacion=informe)
    guardar_json(ruta_runtime, runtime)

def main():
    args = getResolvedOptions(sys.argv, ['JOB_NAME', 'RUTA_PARAMETROS_EXTRACCION', 'S3_SLV_PREP_PATH'])
    capa = opcional('CAPA_ENTRADA', 'SILVER').upper()
    if capa not in ('BRONZE', 'SILVER'):
        raise ValueError('CAPA_ENTRADA debe ser BRONZE o SILVER')
    runtime = cargar_json(args['RUTA_PARAMETROS_EXTRACCION'])
    if runtime.get('estado_extraccion') != 'SUCCESS' or str(runtime.get('nombre_caso') or '').lower() not in ('satelites', 'satélites'):
        raise ValueError('Runtime de Satelites invalido')
    sc = SparkContext.getOrCreate()
    gc = GlueContext(sc)
    spark = gc.spark_session
    spark.conf.set('spark.sql.caseSensitive', 'false')
    spark.conf.set('spark.sql.ansi.enabled', 'true')
    for key in ('spark.sql.parquet.datetimeRebaseModeInRead', 'spark.sql.parquet.int96RebaseModeInRead', 'spark.sql.parquet.datetimeRebaseModeInWrite', 'spark.sql.parquet.int96RebaseModeInWrite'):
        spark.conf.set(key, 'LEGACY')
    job = Job(gc)
    job.init(args['JOB_NAME'], args)
    cache = []
    try:
        _, cache = preparar_vistas(spark, runtime, capa)
        base_principal = construir_base_principal(spark).persist(StorageLevel.MEMORY_AND_DISK)
        total_base_principal = base_principal.count()
        if total_base_principal == 0:
            raise ValueError('BASE_PRINCIPAL_SATELITES no produjo registros')
        print('BASE_PRINCIPAL_SATELITES OK', total_base_principal)
        base_con_acuerdos = preparar_acuerdos(spark).persist(StorageLevel.MEMORY_AND_DISK)
        total_con_acuerdos = base_con_acuerdos.count()
        acuerdos_asignados = base_con_acuerdos.filter(F.col('IDACUERDO').isNotNull()).count()
        if total_con_acuerdos != total_base_principal:
            raise ValueError(f'Cardinalidad distinta despues de acuerdos: {total_con_acuerdos} != {total_base_principal}')
        print('ACUERDOS_SATELITES OK', json.dumps({'total_base': total_base_principal, 'total_con_acuerdos': total_con_acuerdos, 'acuerdos_asignados': acuerdos_asignados, 'sin_acuerdo': total_con_acuerdos - acuerdos_asignados}, ensure_ascii=False))
        resultado_eventos = preparar_eventos(spark)
        base_con_eventos = resultado_eventos['dataframe'].persist(StorageLevel.MEMORY_AND_DISK)
        total_con_eventos = base_con_eventos.count()
        if total_con_eventos != total_con_acuerdos:
            raise ValueError(f'Cardinalidad distinta despues de eventos: {total_con_eventos} != {total_con_acuerdos}')
        eventos_asignados = base_con_eventos.filter(F.col('ID_TIPO_EVENTO').isNotNull()).count()
        print('EVENTOS_SATELITES OK', json.dumps({'total_entrada': total_con_acuerdos, 'total_salida': total_con_eventos, 'eventos_asignados': eventos_asignados, 'eventos_no_encontrados': resultado_eventos['eventos_no_encontrados'], 'sin_evento_asignado': total_con_eventos - eventos_asignados, 'duplicados_eventdco': resultado_eventos['duplicados_eventdco'], 'duplicados_eventtype': resultado_eventos['duplicados_eventtype']}, ensure_ascii=False))
        resultado_cancelaciones = preparar_cancelaciones(spark)
        base_con_cancelaciones = resultado_cancelaciones['dataframe'].persist(StorageLevel.MEMORY_AND_DISK)
        total_con_cancelaciones = base_con_cancelaciones.count()
        if total_con_cancelaciones != total_con_eventos:
            raise ValueError(f'Cardinalidad distinta despues de cancelaciones: {total_con_cancelaciones} != {total_con_eventos}')
        print('CANCELACIONES_SATELITES OK', json.dumps({'total_entrada': total_con_eventos, 'total_salida': total_con_cancelaciones, 'con_cancelacion': resultado_cancelaciones['con_cancelacion'], 'sin_cancelacion': resultado_cancelaciones['sin_cancelacion'], 'resumen_fuentes': resultado_cancelaciones['resumen_fuentes'], 'duplicados_por_tabla': resultado_cancelaciones['duplicados_por_tabla']}, ensure_ascii=False))
        resultado_coberturas = preparar_coberturas(spark)
        base_con_coberturas = resultado_coberturas['dataframe'].persist(StorageLevel.MEMORY_AND_DISK)
        total_con_coberturas = base_con_coberturas.count()
        if total_con_coberturas != total_con_cancelaciones:
            raise ValueError(f'Cardinalidad distinta despues de coberturas: {total_con_coberturas} != {total_con_cancelaciones}')
        print('COBERTURAS_SATELITES OK', json.dumps({'total_entrada': total_con_cancelaciones, 'total_salida': total_con_coberturas, 'con_cobertura': resultado_coberturas['con_cobertura'], 'sin_cobertura': resultado_coberturas['sin_cobertura'], 'con_ramo_contable': resultado_coberturas['con_ramo_contable'], 'operaciones_multiples_ramos': resultado_coberturas['multiples_ramos'], 'duplicados_agregado': resultado_coberturas['duplicados_agregado'], 'duplicados_reinsurancekind': resultado_coberturas['duplicados_reinsurancekind']}, ensure_ascii=False))
        resultado_productos = preparar_productos_especificos(spark)
        base_con_productos = resultado_productos['dataframe'].persist(StorageLevel.MEMORY_AND_DISK)
        total_con_productos = base_con_productos.count()
        if total_con_productos != total_con_coberturas:
            raise ValueError(f'Cardinalidad distinta despues de productos específicos: {total_con_productos} != {total_con_coberturas}')
        print('PRODUCTOS_SATELITES OK', json.dumps({'total_entrada': total_con_coberturas, 'total_salida': total_con_productos, 'productos_especiales': resultado_productos['productos_especiales'], 'especiales_sin_ramo': resultado_productos['especiales_sin_ramo'], 'registros_sin_ramo_contable': resultado_productos['registros_sin_ramo_contable'], 'duplicados_por_fuente': resultado_productos['duplicados_por_fuente']}, ensure_ascii=False))
        resultado_terceros = preparar_terceros(spark)
        base_con_terceros = resultado_terceros['dataframe'].persist(StorageLevel.MEMORY_AND_DISK)
        total_con_terceros = base_con_terceros.count()
        if total_con_terceros != total_con_productos:
            raise ValueError(f'Cardinalidad distinta despues de terceros: {total_con_terceros} != {total_con_productos}')
        print('TERCEROS_SATELITES OK', json.dumps({'total_entrada': total_con_productos, 'total_salida': total_con_terceros, 'metricas': resultado_terceros['metricas']}, ensure_ascii=False))
        resultado_contactos = preparar_contactos(spark)
        base_con_contactos = resultado_contactos['dataframe'].persist(StorageLevel.MEMORY_AND_DISK)
        total_con_contactos = base_con_contactos.count()
        if total_con_contactos != total_con_terceros:
            raise ValueError(f'Cardinalidad distinta despues de contactos: {total_con_contactos} != {total_con_terceros}')
        print('CONTACTOS_SATELITES OK', json.dumps({'total_entrada': total_con_terceros, 'total_salida': total_con_contactos, 'metricas': resultado_contactos['metricas'], 'duplicados_tomador': resultado_contactos['duplicados_tomador'], 'duplicados_asegurado': resultado_contactos['duplicados_asegurado']}, ensure_ascii=False))
        resultado_movimientos = preparar_movimientos(spark)
        base_con_movimientos = resultado_movimientos['dataframe'].persist(StorageLevel.MEMORY_AND_DISK)
        total_con_movimientos = base_con_movimientos.count()
        if total_con_movimientos != total_con_contactos:
            raise ValueError(f'Cardinalidad distinta despues de movimientos: {total_con_movimientos} != {total_con_contactos}')
        print('MOVIMIENTOS_SATELITES OK', json.dumps({'total_entrada': total_con_contactos, 'total_salida': total_con_movimientos, 'duplicados': resultado_movimientos['duplicados'], 'tributarios_pendientes': resultado_movimientos['tributarios_pendientes']}, ensure_ascii=False))
        resultado_final = construir_salida_final(spark, runtime, (sys.argv[sys.argv.index('--JOB_RUN_ID') + 1] if '--JOB_RUN_ID' in sys.argv else ''))
        final = resultado_final['dataframe'].persist(StorageLevel.MEMORY_AND_DISK)
        total = final.count()
        llaves = ['NRO_OPERACION', 'IDPOLIZA', 'IDPRODUCTO', 'UNIDAD_RIESGO']
        faltantes_llave = [nombre for nombre in llaves if nombre not in final.columns]
        if faltantes_llave:
            raise ValueError('Llaves ausentes: ' + ', '.join(faltantes_llave))
        duplicados = final.groupBy(*llaves).count().filter(F.col('count') > 1).count()
        if duplicados:
            raise ValueError('Llaves duplicadas: ' + str(duplicados))
        operaciones = final.select('NRO_OPERACION').distinct().count()
        salida = args['S3_SLV_PREP_PATH'].rstrip('/') + '/ejecucion_preparacion=' + uuid.uuid4().hex + '/'
        final.write.mode('errorifexists').option('compression', 'snappy').parquet(salida)
        informe = {'estado': 'SUCCESS', 'nombre_caso': 'satelites', 'periodo_negocio': runtime['periodo_negocio'], 'lote_cargue_id': runtime['lote_cargue_id'], 'total_registros': total, 'operaciones': operaciones, 'duplicados_llave': duplicados, 'total_columnas': len(final.columns), 'columnas_funcionales': 125, 'columnas_scd': 5, 'columnas_sin_fuente': resultado_final['columnas_sin_fuente'], 'tributarias_sin_funcion': resultado_final['tributarias_sin_funcion'], 'faltantes_adicionales': resultado_final['faltantes_adicionales'], 'ruta_silver_preparada': salida, 'fecha_preparacion': datetime.now().isoformat()}
        ruta_control = args['S3_SLV_PREP_PATH'].rstrip('/') + '/controles/' + 'ejecucion_preparacion=' + salida.rstrip('/').split('=')[-1] + '.json'
        guardar_json(ruta_control, informe)
        actualizar_runtime(args['RUTA_PARAMETROS_EXTRACCION'], runtime, salida, total, informe)
        print('PREPARACION SATELITES OK', json.dumps(informe, ensure_ascii=False))
        final.unpersist()
        job.commit()
    finally:
        for df in cache:
            df.unpersist()
if __name__ == '__main__':
    main()
