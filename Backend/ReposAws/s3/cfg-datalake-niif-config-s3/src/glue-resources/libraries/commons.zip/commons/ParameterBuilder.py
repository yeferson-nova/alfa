import boto3
import json
import concurrent.futures
from typing import Dict, Any, Optional, List, Set, Union
from collections import defaultdict
from botocore.exceptions import ClientError
from .LogsHelper import LogsHelper
from boto3.dynamodb.conditions import Key

class ParameterBuilder():

    def __init__(self, table_names: Dict[str, str], dynamodb_client: Optional[boto3.resource] = None):

        self.dynamodb = dynamodb_client or boto3.resource('dynamodb')
        self.source_artefacto_table = self.dynamodb.Table(table_names['artefacto'])
        self.source_acn_table = self.dynamodb.Table(table_names['acn'])
        self.source_concepto_table = self.dynamodb.Table(table_names['concepto'])
        self.source_nota_table = self.dynamodb.Table(table_names['nota'])
        self._cache: Dict[str, Dict[str, Any]] = {}
        self.logger = LogsHelper().logger_conf()
    
    def _get_all_artefact_ids(self) -> List[str]:
        """
        Scans the main artefact table to get a list of all artefact IDs to be processed.
        Handles pagination for large tables.

        Returns:
            A list of strings, where each string is an 'idArtefacto'.
        """
        try:
            self.logger.info(f"Scanning table '{self.source_artefacto_table.name}' to discover all artefacts...")
            response = self.source_artefacto_table.scan(ProjectionExpression="idArtefacto")
            artefactos = response.get('Items', [])

            # Handle pagination if the table is large
            while 'LastEvaluatedKey' in response:
                self.logger.info(f"Paginating artefact table... Found {len(artefactos)} items so far.")
                response = self.source_artefacto_table.scan(
                    ProjectionExpression="idArtefacto",
                    ExclusiveStartKey=response['LastEvaluatedKey']
                )
                artefactos.extend(response.get('Items', []))
            
            self.logger.info(f"Scan complete. Found a total of {len(artefactos)} artefacts.")
            return [item['idArtefacto'] for item in artefactos]

        except ClientError as e:
            self.logger.error(f"Failed to scan artefact table: {e}")
            return []

    def _fetch_and_denormalize(self, artefacto_id: str) -> Optional[Dict[str, Any]]:
        """Fetches normalized data from multiple DynamoDB tables and assembles a single, denormalized configuration object.

        This private method orchestrates the retrieval of a complete parameter set for
        a specific `artefacto_id`. It performs the following steps:
        1.  Queries the Artefacto-Concepto-Nota (ACN) junction table using a GSI
            to find all related parameter entries.
        2.  Collects all unique 'concepto' and 'nota' IDs from the results.
        3.  Performs an efficient `batch_get_item` operation to retrieve all
            'concepto' and 'nota' items in bulk.
        4.  Fetches the main 'artefacto' item.
        5.  Combines all retrieved data into a single, denormalized dictionary
            structure, ready for caching and processing.

        Args:
            artefacto_id (str): The ID of the artefact to fetch and denormalize.

        Returns:
            Optional[Dict[str, Any]]: A dictionary containing the complete
                denormalized object if successful, otherwise None.
        """
        self.logger.info(f"CACHE MISS: Leyendo y denormalizando desde DynamoDB para artefacto_id: {artefacto_id}")
        
        try:
            response = self.source_acn_table.query(
                IndexName="artefactoId-index",
                KeyConditionExpression = Key('artefactoId').eq(artefacto_id)
            )
            acn_items = response.get('Items', [])
        except ClientError as e:
            self.logger.error(f"Error de GSI al buscar artefacto_id {artefacto_id}: {e}")
            return None

        if not acn_items:
            return None
            
        concepto_ids = list(set(item.get('conceptoId') for item in acn_items if item.get('conceptoId')))
        nota_ids = list(set(item.get('notaId') for item in acn_items if item.get('notaId')))

        if not (concepto_ids and nota_ids):
             return None # No hay nada que buscar en batch

        try:
            batch_response = self.dynamodb.batch_get_item(
                RequestItems={
                    self.source_concepto_table.name: {'Keys': [{'idConcepto': id} for id in concepto_ids]},
                    self.source_nota_table.name: {'Keys': [{'idNota': id} for id in nota_ids]}
                }
            )
            conceptos_data = {item['idConcepto']: item for item in batch_response['Responses'][self.source_concepto_table.name]}
            notas_data = {item['idNota']: item for item in batch_response['Responses'][self.source_nota_table.name]}
        except ClientError as e:
            self.logger.error(f"Error en batch_get_item para artefacto_id {artefacto_id}: {e}")
            return None

        artefacto_data = self.source_artefacto_table.get_item(Key={'idArtefacto': artefacto_id}).get('Item', {})
        
        parametros_list = [
            {
                "artefacto_concepto_nota": item.get('idArtefactoConceptoNota'),
                "concepto": conceptos_data.get(item.get('conceptoId'), {}),
                "nota": notas_data.get(item.get('notaId'), {})
            }
            for item in acn_items
        ]
        
        final_object = {
            "caso_de_uso": artefacto_id,
            "artefacto": artefacto_data,
            "parametros": parametros_list
        }
        return final_object

    def _find_notes_by_concept_id(self, parametros_list: List[Dict[str, Any]], concept_id: str) -> List[str]:

        """Finds all 'valorNota' values that match a given 'idConcepto'.

        This helper method filters a list of parameter objects to find all entries
        that match a specific concept ID. It extracts the associated 'valorNota'
        for each match, sorts them based on their corresponding 'idNota', and
        returns the note values in that sorted order.

        Args:
            parametros_list (List[Dict[str, Any]]): The list of denormalized
                parameter objects to search through.
            concept_id (str): The concept ID to filter by.

        Returns:
            List[str]: A list of 'valorNota' strings, sorted by their
                corresponding 'idNota'. Returns an empty list if no matches
                are found.
        """
        # A temporary list to store found pairs of (id, value)
        results = []

        # Iterate through each parameter dictionary in the input list
        for param_entry in parametros_list:
            # Safely get the nested 'concepto' and 'nota' dictionaries
            concepto = param_entry.get('concepto', {})
            nota = param_entry.get('nota', {})

            # Check if the concept ID in the current item matches the one we're looking for
            if concepto.get('idConcepto') == concept_id:
                valor_nota = nota.get('valorNota')
                nota_id = nota.get('idNota')
                
                # Ensure both the note value and its ID exist to form a valid pair
                if valor_nota and nota_id:
                    # Cast nota_id to int for correct numerical sorting
                    results.append((int(nota_id), valor_nota))

        # Sort the results list based on the note ID (the first element of the tuple)
        results.sort(key=lambda x: x[0])

        # Extract and return only the note values (the second element) from the sorted list
        return [valor for _, valor in results]
        
    def _get_params_drt(self, parametros_obj: Dict[str, Any],  tipos_artefacto_validos: List[str] = ["5", "9"], id_concepto_llave: str = "6",  id_concepto_valor: str = "7") -> Optional[Dict[str, str]]:

        """Builds a {key: value} dictionary from the notes of two specific concepts.

        This function processes a denormalized parameter object to create a specific
        key-value pair. It first validates that the artefact is of the correct type.
        It then uses a helper function to find the note value (`valorNota`) for a
        'key' concept and a 'value' concept.

        By default, it uses the note from concept '6' as the key and the note
        from concept '7' as the value.

        Args:
            parametros_obj (Dict[str, Any]): The complete denormalized parameter object.
            tipo_artefacto_id (str, optional): The artefact type ID to filter for.
                Defaults to "5".
            id_concepto_llave (str, optional): The concept ID whose note value
                will be used as the dictionary key. Defaults to "6".
            id_concepto_valor (str, optional): The concept ID whose note value
                will be used as the dictionary value. Defaults to "7".

        Returns:
            Optional[Dict[str, str]]: A single-entry dictionary of the format
                {key: value} if all conditions are met, otherwise None.
        """
        # Guard Clause: Validate the input is a dictionary.
        if not isinstance(parametros_obj, dict):
            self.logger.error("The input is not a valid dictionary.")
            return None
            
        artefacto = parametros_obj.get("artefacto", {})
        
        # Guard Clause: Validate the artefact type.
        # Silently return None if it's not the artefact type we are interested in.
        if str(artefacto.get("tipoArtefactoId")) not in tipos_artefacto_validos:
            return None

        # Use the helper function to find our two pieces of information.
        parametros_list = parametros_obj.get("parametros", [])
        key_notes = self._find_notes_by_concept_id(parametros_list, id_concepto_llave)
        value_notes = self._find_notes_by_concept_id(parametros_list, id_concepto_valor)
        
        # Build the result only if both the key and value parts were found.
        if key_notes and value_notes:            
            # Get the first found key and value.
            key = key_notes[0]
            value = value_notes[0]            
            # Use .lower() on the key to ensure consistent formatting, e.g., "{landing: ...}"
            if str(artefacto.get("tipoArtefactoId")) == '9':
                result = {f"{key.lower()}_bdd": value}                    
            else:
                result = {key.lower(): value}
                
            return result
        
        # If either the key or value was not found, log a warning before returning None.
        self.logger.error(
            f"Artefact '{artefacto.get('nombreArtefacto')}' was valid, but required concepts "
            f"for the key (ID {id_concepto_llave}) or value (ID {id_concepto_valor}) were not found."
        )
        return None

    def _get_params_ubi(self, parametros_obj: Dict[str, Any], tipo_artefacto_id: str = "6",  id_concepto_llave: str = "18", id_concepto_valor: str = "7") -> Optional[Dict[str, List[str]]]:

        """Builds a dictionary mapping a use case name to a list of its folder locations.

        This function processes a denormalized parameter object to extract a use case
        name and a corresponding list of folder locations (e.g., IN, OUT, ERROR).
        It first validates that the artefact is of the correct type (default '6').
        
        The dictionary key is derived from the note of one concept (e.g., 'Caso de uso',
        default ID '18'), and the value is a list of notes from another concept
        (e.g., 'Ubicación', default ID '7').
        
        A key piece of logic is that it filters out any folder location that is
        identical to the use case name itself.

        Args:
            parametros_obj (Dict[str, Any]): The complete denormalized parameter object.
            tipo_artefacto_id (str, optional): The artefact type ID to filter for.
                Defaults to "6".
            id_concepto_llave (str, optional): The concept ID whose note value will be
                the dictionary key. Defaults to "18".
            id_concepto_valor (str, optional): The concept ID whose note values will form
                the list of dictionary values. Defaults to "7".

        Returns:
            Optional[Dict[str, List[str]]]: A dictionary mapping the use case name
                to a cleaned list of folder locations, or None if conditions aren't met.
        """
        # 1. Guard Clauses: Validate input and artefact type.
        if not isinstance(parametros_obj, dict):
            self.logger.error("Input object is not a valid dictionary.")
            return None

        artefacto = parametros_obj.get("artefacto", {})
        if str(artefacto.get("tipoArtefactoId")) != tipo_artefacto_id:
            return None  # Not the artefact type we are interested in, exit silently.

        # 2. Fetch the key and the list of potential values using the helper function.
        parametros_list = parametros_obj.get("parametros", [])
        key_list = self._find_notes_by_concept_id(parametros_list, id_concepto_llave)
        values_list = self._find_notes_by_concept_id(parametros_list, id_concepto_valor)

        # 3. Build the final result if all necessary parts were found.
        if key_list and values_list:
            # The key is the first (and likely only) value found for the key concept.
            key = key_list[0]
            
            # Filter the values list to exclude any value that is identical to the key itself.
            final_values = [v for v in values_list if v != key]

            return {key: final_values}

        # If either the key or values were not found, log a warning.
        self.logger.error(
            f"Artefact '{artefacto.get('nombreArtefacto')}' was valid, but required concepts "
            f"for the key (ID {id_concepto_llave}) or values (ID {id_concepto_valor}) were not found."
        )
        return None    

    def _get_params_arch(self, parametros_obj: Dict[str, Any], tipo_artefacto_id: str = "1",  id_concepto_llave: str = "18", id_conceptos_valores: List[str] = ["6", "8", "19"]) -> Optional[Dict[str, Dict[str, str]]]:
        """Builds a dictionary mapping a use case name to a structured dict of file properties.

        This function processes a parameter object to extract file-related properties
        for a specific use case. It validates the artefact type (default '1').
        
        The main key is derived from one concept's note (ID '18'). The value is a
        structured dictionary containing file properties ('file', 'ext', 'sheet'),
        which are derived from the notes of a list of other concept IDs
        (defaults to ['6', '8', '19']). The function assumes a fixed order for these
        value concepts.

        Args:
            parametros_obj (Dict[str, Any]): The complete denormalized parameter object.
            tipo_artefacto_id (str, optional): The artefact type ID to filter for.
                Defaults to "1".
            id_concepto_llave (str, optional): The concept ID for the main dictionary key.
                Defaults to "18".
            id_conceptos_valores (List[str], optional): A list of concept IDs whose notes will be
                fetched in order to build the structured value dictionary.
                Defaults to ["6", "8", "19"].

        Returns:
            Optional[Dict[str, Dict[str, str]]]: A dictionary mapping the use case
                to its file properties, or None if any required part is missing.
        """
        # 1. Guard Clauses: Validate input and artefact type.
        if not isinstance(parametros_obj, dict):
            self.logger.error("Input object is not a valid dictionary.")
            return None

        artefacto = parametros_obj.get("artefacto", {})
        if str(artefacto.get("tipoArtefactoId")) != tipo_artefacto_id:
            return None  # Not the artefact type we are interested in, exit silently.

        # 2. Fetch the main key for the dictionary.
        parametros_list = parametros_obj.get("parametros", [])
        key_list = self._find_notes_by_concept_id(parametros_list, id_concepto_llave)
        
        # 3. Sequentially fetch the values for the structured inner dictionary.
        collected_values = []
        for concept_id in id_conceptos_valores:
            # Find the note for the current concept ID
            found_value = self._find_notes_by_concept_id(parametros_list, concept_id)
            if not found_value:
                # If any component is missing, we cannot build the final object.
                self.logger.error(f"Artefact '{artefacto.get('nombreArtefacto')}' is missing required value for concept ID {concept_id}.")
                return None
            collected_values.append(found_value[0])

        # 4. Build the final result if the key and all value components were found.
        #    The original 'if llave and valor' was buggy; this is the correct check.
        if key_list and len(collected_values) == len(id_conceptos_valores):
            key = key_list[0]
            
            # Assemble the structured dictionary, assuming a fixed order.
            structured_value = {
                "file": collected_values[0],
                "ext": collected_values[1],
                "sheet": collected_values[2]
            }
            return {key: structured_value}

        if not key_list:
            self.logger.error(
                f"Artefact '{artefacto.get('nombreArtefacto')}' was valid, but the key (ID {id_concepto_llave}) "
                f"or one of the required values (IDs {id_conceptos_valores}) was not found."
            )
            return None
    
    def _get_params_stru(self, parametros_obj: Dict[str, Any], tipo_artefacto_id: str = "2", id_concepto_llave: str = "18", id_concepto_valor: str = "10") -> Optional[Dict[str, str]]:
        """Builds a simple key-value pair dictionary from the notes of two specific concepts.

        This function processes a parameter object to extract a simple key-value pair,
        typically representing a use case and its associated main value (e.g., a
        structure definition or a table name). It validates the artefact type
        (default '2').

        The dictionary key is derived from one concept's note (ID '18'), and the value
        is from another (ID '10').

        Args:
            parametros_obj (Dict[str, Any]): The complete denormalized parameter object.
            tipo_artefacto_id (str, optional): The artefact type ID to filter for.
                Defaults to "2".
            id_concepto_llave (str, optional): The concept ID whose note value will be
                the dictionary key. Defaults to "18".
            id_concepto_valor (str, optional): The concept ID whose note value will be
                the dictionary value. Defaults to "10".

        Returns:
            Optional[Dict[str, str]]: A single-entry dictionary of the format
                {key: value} if successful, otherwise None.
        """
        # 1. Guard Clauses: Validate input and artefact type.
        if not isinstance(parametros_obj, dict):
            self.logger.error("Input object is not a valid dictionary.")
            return None

        artefacto = parametros_obj.get("artefacto", {})
        if str(artefacto.get("tipoArtefactoId")) != tipo_artefacto_id:
            return None  # Not the correct artefact type, exit silently.

        codigo = artefacto.get("codigoArtefacto")

        # 2. Fetch the key and value using the helper function.
        parametros_list = parametros_obj.get("parametros", [])
        key_list = self._find_notes_by_concept_id(parametros_list, id_concepto_llave)
        value_list = self._find_notes_by_concept_id(parametros_list, id_concepto_valor)

        # 3. Build the final result if both parts were found.
        if key_list and value_list:
            return {key_list[0]: value_list[0]}
        if not key_list: 
            self.logger.error(
                f"Artefact '{artefacto.get('nombreArtefacto')}' was valid, but required concepts "
                f"for the key (ID {id_concepto_llave}) or value (ID {id_concepto_valor}) were not found."
            )
            return None

    def _get_params_atr(self, parametros_obj: Dict[str, Any], tipo_artefacto_id: str = "3") -> Optional[Dict[str, str]]:
        """Extracts all parameters for a given artefact into a single dictionary.

        This function processes a parameter object for a specific artefact type
        (default '3') and aggregates all its associated parameters into a single
        key-value dictionary. The keys are the 'nombreConcepto' values (with spaces
        replaced by underscores), and the values are the corresponding 'valorNota' values.

        Note: If multiple parameters share the same 'nombreConcepto', the last one
        encountered after sorting by 'notaId' will be used.

        Args:
            parametros_obj (Dict[str, Any]): The complete denormalized parameter object.
            tipo_artefacto_id (str, optional): The artefact type ID to filter for.
                Defaults to "3".

        Returns:
            Optional[Dict[str, str]]: A dictionary containing all extracted
                key-value parameters, or None if the artefact type does not match.
        """
        # 1. Guard Clauses: Validate input and artefact type.
        if not isinstance(parametros_obj, dict):
            self.logger.error("Input object is not a valid dictionary.")
            return None

        artefacto = parametros_obj.get("artefacto", {})
        if str(artefacto.get("tipoArtefactoId")) != tipo_artefacto_id:
            return None  # Not the correct artefact type.

        # 2. Extract all valid parameters into a list of tuples.
        parametros_list = parametros_obj.get("parametros", [])
        
        # This list will hold tuples of (nota_id, nombre_concepto, valor_nota)
        # to be sorted and aggregated.
        all_params = []
        for param in parametros_list:
            concepto = param.get("concepto", {})
            nota = param.get("nota", {})
            
            nombre_concepto = concepto.get("nombreConcepto")
            valor_nota = nota.get("valorNota")
            nota_id = nota.get("idNota")

            if nombre_concepto and valor_nota and nota_id:
                all_params.append((int(nota_id), nombre_concepto, valor_nota))
        
        # Sort by nota_id to ensure a consistent order.
        all_params.sort(key=lambda x: x[0])

        # 3. Build the final dictionary using a dictionary comprehension.
        #    This flattens the list into a dict. If keys are duplicated, the last
        #    one in the sorted list wins.
        final_params_dict = {
            nombre.replace(" ", "_"): valor for _, nombre, valor in all_params
        }
        
        return final_params_dict

    def _get_params_func_arch(self, parametros_obj: Dict[str, Any], tipo_artefacto_id: str = "8") -> Optional[Dict[str, Union[str, List[str]]]]:
        """Extracts verification parameters for file or structure checks.

        This function handles functional artefacts (type '8') related to file and
        structure verification. It validates that the artefact's 'codigoArtefacto'
        contains specific keywords ('VERIFICAR_ARCHIVO' or 'VERIFICAR_ESTRUCTURA').

        Based on the available parameters, it returns either a list of attributes
        or a constructed file path, keyed by the use case name.

        Args:
            parametros_obj (Dict[str, Any]): The complete denormalized parameter object.
            tipo_artefacto_id (str, optional): The artefact type ID to filter for.
                Defaults to "8".

        Returns:
            Optional[Dict[str, Union[str, List[str]]]]: A dictionary containing the
                processed parameters, or None if the artefact does not match the criteria.
        """
        # 1. Guard Clause: Validate input and perform a complex artefact check.
        if not isinstance(parametros_obj, dict):
            self.logger.error("La entrada no es un diccionario válido.")
            return None

        artefacto = parametros_obj.get("artefacto", {})       
        if not (str(artefacto.get("tipoArtefactoId")) == tipo_artefacto_id and any(keyword in str(artefacto.get("codigoArtefacto", "")) for keyword in ["VERIFICAR_ARCHIVO", "VERIFICAR_ESTRUCTURA"])):
            return None  # Exit if it's not the correct type OR code.

        # 2. Directly extract the required parameters instead of flattening everything.
        parametros_list = parametros_obj.get("parametros", [])                       
        
        resultados = []

        for param in parametros_list:
            concepto = param.get("concepto", {})
            nota = param.get("nota", {})

            nombre_concepto = concepto.get("nombreConcepto")
            valor_nota = nota.get("valorNota")
            nota_id = nota.get("idNota")                        
            id_artefacto_concepto_nota = param.get("artefacto_concepto_nota", {})
            if nombre_concepto and valor_nota and nota_id:
                resultados.append((int(id_artefacto_concepto_nota), nombre_concepto, valor_nota))
        
        resultados.sort(key=lambda x: x[0])

        # 3. Check for the 'Lista_Atributos' parameter to decide the return format.
        resultado_final = {nombre.replace(" ", "_"): valor for _, nombre, valor in resultados}                
        
        caso_de_uso = resultado_final.get('Caso_de_uso')
        lista_atributos = resultado_final.get('Lista_Atributos')

        if not caso_de_uso:
            self.logger.error(f"Artefacto '{artefacto.get('nombreArtefacto')}' was valid but missing required components ")
            return None

        if lista_atributos:
            return {
                caso_de_uso: lista_atributos
            }
        else:
            ubicacion = resultado_final.get('Ubicación', '')
            nombre = resultado_final.get('Nombre', '')
            extension = resultado_final.get('Extensión', '')
            return {
                caso_de_uso: f"{ubicacion}/{nombre}{extension}"
            }

    def _get_params_func_nul(self, parametros_obj: Dict[str, Any], tipo_artefacto_id: str = "8") -> Optional[Dict[str, str]]:
        """Generates a string of nullity check rules for a specific use case.

        This function handles functional artefacts (type '8') designed for nullity
        verification ('VERIFICAR_NULIDAD'). It extracts all 'Nombre' (Name) and
        'Regla' (Rule) parameters, pairs them up, and formats them into a single,
        comma-separated string, keyed by the 'Caso de uso' (Use Case) name.

        Args:
            parametros_obj (Dict[str, Any]): The complete denormalized parameter object.
            tipo_artefacto_id (str, optional): The artefact type ID to filter for.
                Defaults to "8".

        Returns:
            Optional[Dict[str, str]]: A dictionary mapping the use case name to the
                formatted string of nullity rules, or None if conditions are not met.
        """
        # 1. Guard Clauses: Validate input and the specific artefact code.
        if not isinstance(parametros_obj, dict):
            self.logger.error("Input object is not a valid dictionary.")
            return None

        artefacto = parametros_obj.get("artefacto", {})       
        if not (str(artefacto.get("tipoArtefactoId")) == tipo_artefacto_id and any(keyword in str(artefacto.get("codigoArtefacto", "")) for keyword in ["VERIFICAR_NULIDAD"])):
            return None  # Not the correct functional artefact, exit silently.

        # 2. Directly extract and map the required parameters.
        #    This is more robust than creating intermediate lists.
        parametros_list = parametros_obj.get("parametros", [])                       
        
        resultados = []

        for param in parametros_list:
            concepto = param.get("concepto", {})
            nota = param.get("nota", {})

            nombre_concepto = concepto.get("nombreConcepto")
            valor_nota = nota.get("valorNota")
            nota_id = nota.get("idNota")                        

            if nombre_concepto and valor_nota and nota_id:
                resultados.append((int(nota_id), nombre_concepto, valor_nota))
        
        resultados.sort(key=lambda x: x[0])    

        # 3. Build the formatted string from the extracted 'Regla' and 'Nombre' params.
        #    This approach is safer than positional pairing with zip.
        #    It assumes one 'Regla' and one 'Nombre' for this specific logic.
        nombres = [valor for _, tipo, valor in resultados if tipo == 'Nombre']
        reglas = [valor for _, tipo, valor in resultados if tipo == 'Regla']  
        caso_de_uso = next((valor for _, tipo, valor in resultados if tipo == 'Caso de uso'), '')

        resultado_formateado = ','.join(
            f'{regla} "{nombre}"' for regla, nombre in zip(reglas, nombres)
        )

        if not resultado_formateado:             
            self.logger.error(f"Artefact '{artefacto.get('nombreArtefacto')}' was valid but was missing 'Regla' or 'Nombre' parameters.")
            return None        

        return {caso_de_uso: resultado_formateado}     

    def _get_params_func_space(self, parametros_obj: Dict[str, Any], tipo_artefacto_id: str = "8") -> Optional[Dict[str, str]]:
        """Generates a string of space verification rules for a use case.

        This function handles functional artefacts (type '8') for space verification
        ('VERIFICAR_ESPACIO'). It extracts all 'Nombre', 'Regla', and 'Expresion'
        parameters and combines them into a formatted, multiline string, keyed by
        the 'Caso de uso' name.

        Args:
            parametros_obj (Dict[str, Any]): The complete denormalized parameter object.
            tipo_artefacto_id (str, optional): The artefact type ID to filter for.
                Defaults to "8".

        Returns:
            Optional[Dict[str, str]]: A dictionary mapping the use case name to the
                formatted string of rules, or None if conditions are not met.
        """
        # 1. Guard Clauses: Validate input and the specific artefact code.
        if not isinstance(parametros_obj, dict):
            self.logger.error("Input object is not a valid dictionary.")
            return None

        artefacto = parametros_obj.get("artefacto", {})
        codigo_artefacto = str(artefacto.get("codigoArtefacto", ""))

        if not (str(artefacto.get("tipoArtefactoId")) == tipo_artefacto_id and "VERIFICAR_ESPACIO" in codigo_artefacto):
            return None

        # 2. Extract components into separate, reliable lists.
        parametros_list = parametros_obj.get("parametros", [])                       
        
        resultados = []

        for param in parametros_list:
            concepto = param.get("concepto", {})
            nota = param.get("nota", {})

            nombre_concepto = concepto.get("nombreConcepto")
            valor_nota = nota.get("valorNota")
            nota_id = nota.get("idNota")                    

            if nombre_concepto and valor_nota and nota_id:
                resultados.append((int(nota_id), nombre_concepto, valor_nota))
        
        resultados.sort(key=lambda x: x[0])                
                
        
        # Separar nombres y reglas
        nombres = [valor for _, tipo, valor in resultados if tipo == 'Nombre']
        reglas = [valor for _, tipo, valor in resultados if tipo == 'Regla'] 
        expresion = next((valor for _, tipo, valor in resultados if tipo == 'Expresion'), '') 
        caso_de_uso = next((valor for _, tipo, valor in resultados if tipo == 'Caso de uso'), '')


        # 3. Check if we have all the required parts.
        #    This logic assumes a specific structure for the 'Regla' list.
        if not (nombres and len(reglas) >= 4 and expresion and caso_de_uso):
            self.logger.error(f"Artefact '{artefacto.get('nombreArtefacto')}' was valid but missing required components (Nombres, Reglas, Expresion, or Caso de uso).")
            return None
        
        # 4. Build the final rule strings using f-strings for clarity.
        reglas_finales = []
        for atributo in nombres:
            # Construct the rule string safely without relying on fragile indices.
            # This assumes the 'reglas' list contains the rule parts in a fixed order.
            rule_string = (
                f'{reglas[0]} \"{atributo}\" {reglas[1]} {expresion}'
                f'{reglas[2]} "{atributo} {reglas[3]}"'
            )
            reglas_finales.append(rule_string)

        resultado_formateado = ', \n'.join(reglas_finales)
        return {caso_de_uso: resultado_formateado}

    def _get_params_func_type(self, parametros_obj: Dict[str, Any], tipo_artefacto_id: str = "8") -> Optional[Dict[str, str]]:

        """Generates data type verification rules for a specific use case.

        This function handles functional artefacts (type '8') for data type
        verification ('VERIFICAR_TIPO'). It reliably pairs 'Nombre' and 'Tipo Dato'
        parameters and formats them into a rule string.

        Args:
            parametros_obj (Dict[str, Any]): The complete denormalized parameter object.
            tipo_artefacto_id (str, optional): The artefact type ID to filter for.
                Defaults to "8".

        Returns:
            Optional[Dict[str, str]]: A dictionary mapping the use case name to the
                formatted string of rules, or None if conditions are not met.
        """
        # 1. Guard Clauses: Validate input and artefact type.
        if not isinstance(parametros_obj, dict):
            self.logger.error("Input object is not a valid dictionary.")
            return None

        artefacto = parametros_obj.get("artefacto", {})
        if not (str(artefacto.get("tipoArtefactoId")) == tipo_artefacto_id and any( keyword in str(artefacto.get("codigoArtefacto", "")) for keyword in ["VERIFICAR_TIPO"] )):
            return None
            
        # 2. Group parameters by a common ID to create reliable pairs.
        #    This avoids the fragile positional matching problem of the original code.
        parametros_list = parametros_obj.get("parametros", [])
        resultados = []    

        for param in parametros_list:
            concepto = param.get("concepto", {})
            nota = param.get("nota", {})
            nombre_concepto = concepto.get("nombreConcepto")
            valor_nota = nota.get("valorNota")
            nota_id = nota.get("idNota")
            id_artefacto_concepto_nota = param.get("artefacto_concepto_nota", {})
            if nombre_concepto and valor_nota and nota_id:            
                resultados.append((int(id_artefacto_concepto_nota), nombre_concepto, valor_nota))
        
        resultados.sort(key=lambda x: x[0])       
                
        # 3. Extract components and build the final rule string.
        nombres = [valor for _, tipo, valor in resultados if tipo == 'Nombre']
        reglas = [valor for _, tipo, valor in resultados if tipo == 'Regla']
        tipo_dato = [valor for _, tipo, valor in resultados if tipo == 'Tipo Dato']
        restriccion = [valor for _, tipo, valor in resultados if tipo == 'Restricción']
        caso_de_uso = next((valor for _, tipo, valor in resultados if tipo == 'Caso de uso'), '')

        reglas_final = []

        if not nombres or not tipo_dato or not reglas or not caso_de_uso:
            return None
        
        # Extract the keywords for rule formatting (e.g., 'where', operators).
        for idx, atributo in enumerate(nombres):        
            if idx < len(tipo_dato):
                if any('where' in r.lower() for r in reglas):

                    regla_final = f'{reglas[0]} \"{atributo}\" = "{tipo_dato[idx]}" {reglas[1]} "{atributo} {reglas[2]}"'
                    reglas_final.append(str(regla_final))
                else:
                    regla_final = f'{reglas[0]} {atributo} = "{tipo_dato[idx]}"'                    
                    reglas_final.append(str(regla_final))
            else:
                if any('where' in r.lower() for r in reglas):
                    regla_final = f"{reglas[3]} {atributo} {restriccion[idx - len(tipo_dato)]}"                
                    reglas_final.append(str(regla_final))        
                else:
                    regla_final = f"{reglas[1]} {atributo} {restriccion[idx - len(tipo_dato)]}"                
                    reglas_final.append(str(regla_final))


        if not caso_de_uso or not reglas_final:            
            self.logger.error (f"Artefacto '{artefacto.get('nombreArtefacto')}' no es válido, pero no se ")         
            return None

        resultado_formateado = ', \n'.join(reglas_final)
                  

        return {caso_de_uso: resultado_formateado}

    def _get_params_func_dom(self, parametros_obj: Dict[str, Any], tipo_artefacto_id: str = "8") -> Optional[Dict[str, str]]:
        """Generates a string of domain verification rules for a use case.

        This function handles functional artefacts (type '8') for domain verification
        ('VERIFICAR_DOMINIO'). It extracts all 'Regla' and 'Dominio' parameters
        and formats them into a single, multiline string keyed by the 'Caso de uso' name.

        Args:
            parametros_obj (Dict[str, Any]): The complete denormalized parameter object.
            tipo_artefacto_id (str, optional): The artefact type ID to filter for.
                Defaults to "8".

        Returns:
            Optional[Dict[str, str]]: A dictionary mapping the use case name to the
                formatted string of domain rules, or None if conditions are not met.
        """
        # 1. Guard Clauses: Validate input and the specific artefact code.
        if not isinstance(parametros_obj, dict):
            self.logger.error("Input object is not a valid dictionary.")
            return None

        artefacto = parametros_obj.get("artefacto", {})
        codigo_artefacto = str(artefacto.get("codigoArtefacto", ""))
        
        if not (str(artefacto.get("tipoArtefactoId")) == tipo_artefacto_id and "VERIFICAR_DOMINIO" in codigo_artefacto):
            return None  # Not the correct functional artefact, exit silently.

        # 2. Directly extract the necessary components into lists.
        parametros_list = parametros_obj.get("parametros", [])
        
        # Use list comprehensions for efficient and safe extraction.
        reglas = [p.get("nota", {}).get("valorNota") for p in parametros_list if p.get("concepto", {}).get("nombreConcepto") == 'Regla' and p.get("nota", {}).get("valorNota")]
        dominios = [p.get("nota", {}).get("valorNota") for p in parametros_list if p.get("concepto", {}).get("nombreConcepto") == 'Dominio' and p.get("nota", {}).get("valorNota")]
        caso_de_uso_list = [p.get("nota", {}).get("valorNota") for p in parametros_list if p.get("concepto", {}).get("nombreConcepto") == 'Caso de uso' and p.get("nota", {}).get("valorNota")]

        # 3. Check if we have the minimum required components.
        #    This logic assumes one 'Regla' keyword and multiple 'Dominio' values.
        if not (reglas and dominios and caso_de_uso_list):
            self.logger.error(f"Artefact '{artefacto.get('nombreArtefacto')}' was valid but missing required components (Regla, Dominio, or Caso de uso).")
            return None

        caso_de_uso = caso_de_uso_list[0]
        regla_base = reglas[0]
        
        # 4. Build the final formatted string.
        #    Create a rule string for each domain found.
        reglas_finales = [f"{regla_base} {dominio}" for dominio in dominios]
        
        resultado_formateado = ', \n'.join(reglas_finales)
        
        return {caso_de_uso: resultado_formateado}

    def _get_params_func_sim(self, parametros_obj: Dict[str, Any], tipo_artefacto_id: str = "8") -> Optional[Dict[str, str]]:

        """Generates a string of symbol verification rules for a use case.

        This function handles functional artefacts (type '8') for symbol verification
        ('VERIFICAR_SIMBOLO'). It extracts 'Nombre', 'Regla', and 'Expresion'
        parameters and combines them into a formatted, multiline string.

        Args:
            parametros_obj (Dict[str, Any]): The complete denormalized parameter object.
            tipo_artefacto_id (str, optional): The artefact type ID to filter for.
                Defaults to "8".

        Returns:
            Optional[Dict[str, str]]: A dictionary mapping the use case name to the
                formatted string of symbol rules, or None if conditions are not met.
        """
        # 1. Guard Clauses: Validate input and the specific artefact code.
        if not isinstance(parametros_obj, dict):
            self.logger.error("Input object is not a valid dictionary.")
            return None

        artefacto = parametros_obj.get("artefacto", {})
        codigo_artefacto = str(artefacto.get("codigoArtefacto", ""))

        if not (str(artefacto.get("tipoArtefactoId")) == tipo_artefacto_id and "VERIFICAR_SIMBOLO" in codigo_artefacto):
            return None

        # 2. Extract components into separate, reliable lists.
        parametros_list = parametros_obj.get("parametros", [])


        resultados = []                
                

        for param in parametros_list:
            concepto = param.get("concepto", {})
            nota = param.get("nota", {})

            nombre_concepto = concepto.get("nombreConcepto")
            valor_nota = nota.get("valorNota")
            nota_id = nota.get("idNota")        
            id_artefacto_concepto_nota = param.get("artefacto_concepto_nota", {})
            
            if nombre_concepto and valor_nota and nota_id:
                resultados.append((int(id_artefacto_concepto_nota), nombre_concepto, valor_nota))                
        
        resultados.sort(key=lambda x: x[0])                                        
                
        # Separar nombres y reglas
        
        nombres = [valor for _, tipo, valor in resultados if tipo == 'Nombre'] 
        reglas = [valor for _, tipo, valor in resultados if tipo == 'Regla']         
        expresiones = [valor for _, tipo, valor in resultados if tipo == 'Expresion'] 
                        
        caso_de_uso = next((valor for _, tipo, valor in resultados if tipo == 'Caso de uso'), '')
        
        
        # 3. Check if we have all the required parts.
        #    This logic assumes the 'reglas' list contains parts of the rule in a fixed order.
        if not (nombres and len(reglas) >= 4 and expresiones and caso_de_uso):
            self.logger.error(f"Artefact '{artefacto.get('nombreArtefacto')}' was valid but missing required components (Nombres, Reglas, Expresion, or Caso de uso).")
            return None

        # 4. Build the final rule strings using f-strings for clarity and safety.
        reglas_finales = []
        for atributo in nombres:
            # Construct the rule string, assuming the 'reglas' list contains rule parts in a fixed order.
            rule_string = (
                f"{reglas[0]} {atributo} {reglas[1]} {expresiones[0]} "
                f'{reglas[2]} "{atributo} {reglas[3]}"'
            )
            reglas_finales.append(rule_string)

        resultado_formateado = ', \n'.join(reglas_finales)
        
        return {caso_de_uso: resultado_formateado}
    
    def _get_params_func_hist_params(self, parametros_obj: Dict[str, Any], tipo_artefacto_id: str = "8") -> Optional[Dict[str, List[str]]]:
        """
        Dynamically extracts and structures the operational parameters for the 
        Historical Premium (HIST_PRM) ETL artifact.

        The function validates the artifact type/code and processes the denormalized list 
        of parameters to reconstruct the configuration logic (source table, pivot attributes, etc.).

        Args:
            parametros_obj: Denormalized dictionary containing the complete artifact 
                            configuration (e.g., from DynamoDB).
            tipo_artefacto_id: ID of the artifact type to validate (default is "8").

        Returns:
            A structured dictionary mapping the primary function name to its 
            full configuration map, or None if the artifact is invalid or key 
            concepts (like 'Tabla' or 'Función') are missing.
        """

        # 1. Guard Clauses: Validate input and the specific artefact code.
        if not isinstance(parametros_obj, dict):
            self.logger.error("La entrada no es un diccionario válido.")
            return None
                
        artefacto = parametros_obj.get("artefacto", {})       
        if not (str(artefacto.get("tipoArtefactoId")) == tipo_artefacto_id and any(keyword in str(artefacto.get("codigoArtefacto", "")) for keyword in ["HIST_PRM"])):
            return None # No es el tipo de artefacto que nos interesa, salimos.

        # 2. Extract components into separate, reliable lists.                    
        
        parametros_list = parametros_obj.get("parametros", [])                       
        
        resultados = []                        
                

        for param in parametros_list:
            concepto = param.get("concepto", {})
            nota = param.get("nota", {})

            nombre_concepto = concepto.get("nombreConcepto")
            valor_nota = nota.get("valorNota")
            nota_id = nota.get("idNota")        
            id_artefacto_concepto_nota = param.get("artefacto_concepto_nota", {})
            
            if nombre_concepto and valor_nota and nota_id:
                resultados.append((int(id_artefacto_concepto_nota), nombre_concepto, valor_nota))                
        
        resultados.sort(key=lambda x: x[0])                                                
                
        # Split on concepts for functions
        
        funcion = [valor for _, tipo, valor in resultados if tipo == 'Función']        
        tabla = [valor for _, tipo, valor in resultados if tipo == 'Tabla']         
        pivote = [valor for _, tipo, valor in resultados if tipo == 'Lista Atributos Pivote']                 
        periodo = [valor for _, tipo, valor in resultados if tipo == 'Lista Atributos Periodo']         
        inactivar = [valor for _, tipo, valor in resultados if tipo == 'Lista Atributos Inactivar']                                                  
        info = [valor for _, tipo, valor in resultados if tipo == 'Lista Atributos']
        activo = [valor for _, tipo, valor in resultados if tipo == 'Dict Atributos activo']
                        
        caso_de_uso = next((valor for _, tipo, valor in resultados if tipo == 'Caso de uso'), '')
        
        if tabla and funcion and activo and (pivote or periodo or inactivar or info):                   
            return {funcion[0]: {"tabla_source":tabla[0] ,"pivote": pivote[0] if pivote else [], "activo":activo[0], "periodo": periodo[0] if periodo else [], "inactivar": inactivar[0] if inactivar else [], "info": info[0] if info else []}}                                            
        else:
            
            self.logger.warning(f"Artefacto '{artefacto.get('nombreArtefacto')}' era válido, pero no se "
                        f"encontró el concepto para la llave (ID {caso_de_uso}) o no había valores (ID {caso_de_uso}).")
        return None
                
    def _get_config(self, artefacto_id: str) -> Dict[str, Any]:
        """
        Gets the denormalized configuration for a given artefact_id, using an
        in-memory cache to avoid redundant database calls.

        If the configuration is not in the cache, it calls the private
        _fetch_and_denormalize method to retrieve it from DynamoDB.

        Args:
            artefacto_id (str): The ID of the artefact whose configuration is needed.

        Returns:
            The complete denormalized configuration object as a dictionary.

        Raises:
            ConfigNotFoundException: If the configuration cannot be fetched.
        """
        # Check the cache first to avoid expensive I/O
        if artefacto_id not in self._cache:
            # If not in cache, call the heavy-lifter method
            denormalized_obj = self._fetch_and_denormalize(artefacto_id)
            
            if denormalized_obj is None:
                raise ValueError (f"Could not find or build config for artefact_id: {artefacto_id}")
            
            # Store the result in the cache for future use
            self._cache[artefacto_id] = denormalized_obj
            
        return self._cache[artefacto_id]   
        
    def filtrar_y_agrupar_resultados(self, json_final: Dict[str, Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
        """
        Filters a consolidated results dictionary to keep only 'SUCCESS' statuses,
        and then groups them by the primary key within the 'params' dictionary.

        Args:
            json_final (Dict[str, Dict[str, Any]]): The final JSON output from the
                parallel processing.

        Returns:
            Dict[str, List[Dict[str, Any]]]: A dictionary where keys are the parameter
                types (e.g., 'attributes', 'func_domain') and values are lists of
                the corresponding 'params' objects.
        """
        # Use defaultdict(list) to automatically create an empty list for new group keys.
        grupos = defaultdict(list)
        
        # Iterate through each artefact's result in the input dictionary.
        for artefacto_id, resultado in json_final.items():
            
            # 1. Filter: Keep only the entries with 'SUCCESS' status.
            if resultado.get('status') == 'SUCCESS':
                
                # Safely get the 'params' dictionary for this artefact.
                params = resultado.get('params', {})
                
                # Ensure the params dictionary is not empty.
                if params:
                    # 2. Group: Determine the group key (the first key inside 'params').
                    #    Example: For {'attributes': {...}}, the group key is 'attributes'.
                    group_key = list(params.keys())[0]
                    
                    # Append the entire params object to the correct group list.
                    grupos[group_key].append(params)
                    
        # Convert defaultdict back to a regular dict for the final output.
        return dict(grupos)
        
    def process_and_build_all(self, max_workers: int = 10) -> Dict[str, Any]:

        """
        Discovers all artefacts, processes them in parallel, and returns a single
        consolidated dictionary with all built parameters. This is the main
        entry point for a Glue job.
        """
        self.logger.info("Starting the full parameter building process...")
        
        # Step 1: Discover all artefacts to be processed.
        artefacto_ids = self._get_all_artefact_ids()
        if not artefacto_ids:
            self.logger.error("No artefacts found to process.")
            return {}

        # Step 2: Process the discovered artefacts in parallel.
        final_results = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_artefact_id = {
                executor.submit(self.build_params_for_artefact, aid): aid
                for aid in artefacto_ids
            }
            
            for future in concurrent.futures.as_completed(future_to_artefact_id):
                artefact_id = future_to_artefact_id[future]
                try:
                    result_data = future.result()
                    if result_data:
                        final_results[artefact_id] = {"status": "SUCCESS", "params": result_data}
                    else:
                        final_results[artefact_id] = {"status": "NO_PARAMS_GENERATED"}
                except Exception as exc:
                    self.logger.error(f"Artefact {artefact_id} generated an exception: {exc}")
                    final_results[artefact_id] = {"status": "ERROR", "reason": str(exc)}
                    
        self.logger.info("Full parameter building process finished.")
        return json.dumps(self.filtrar_y_agrupar_resultados(final_results), indent=2, ensure_ascii=False) 
    
    def build_params_for_artefact(self, artefacto_id: str) -> Optional[Dict[str, Any]]:
            """
            The "worker" method. For a single artefact, it exhaustively tries to
            build every possible type of parameter set.
            """
            try:
                # The worker first gets all the data for its assigned artefact.
                config = self._get_config(artefacto_id)
            except ValueError as e:
                self.logger.error(e)
                return None
            
            # Then, the worker tries to run every builder function.
            # Each builder function is responsible for checking if it applies.
            all_params = {
                "directory": self._get_params_drt(config),
                "location": self._get_params_ubi(config),
                "file": self._get_params_arch(config),
                "structure": self._get_params_stru(config),
                "attributes": self._get_params_atr(config),
                "func_file": self._get_params_func_arch(config),
                "func_null": self._get_params_func_nul(config),
                "func_spaces": self._get_params_func_space(config),
                "func_type": self._get_params_func_type(config),
                "func_domain": self._get_params_func_dom(config),
                "func_symbol": self._get_params_func_sim(config),
                "historic": self._get_params_func_hist_params(config),
            }            
            # The worker returns a clean package of only the results that were generated.
            return {key: value for key, value in all_params.items() if value is not None}
        
    def group_and_unify_structures(self, data: List[Dict[str, Any]], artefact: str) -> Dict[str, List[str]]:

        resultado_agrupado = defaultdict(list)

        for item in data[artefact]:
            structure_dict = item.get(artefact, {})
            for clave, valor_interno in structure_dict.items():
                try:
                  if isinstance(structure_dict, dict):
                      resultado_agrupado[clave].append(valor_interno)
                  else:
                      resultado_agrupado[clave].add(valor_interno)
                except json.JSONDecodeError:
                    print(f"Advertencia: Se encontró un string de JSON mal formado para '{clave}' y fue omitido.")
                    continue

        resultado_final = {}
        for clave, valor_set in resultado_agrupado.items():
            if len(valor_set) == 1:
                # Si el set solo tiene un elemento, lo extraemos ("desempaquetamos").
                # .pop() saca y devuelve el único elemento del set.
                resultado_final[clave] = valor_set.pop()
            elif isinstance(valor_set, dict): 
                resultado_final = resultado_agrupado
            else:
                # Si hay más de un elemento, lo dejamos como una lista ordenada.
                try:
                    resultado_final[clave] = sorted(list(valor_set))
                except TypeError:
                    resultado_final[clave] = list(valor_set)
        # --- FIN DE LA MODIFICACIÓN CLAVE ---

        return resultado_final

    def group_and_transform_attributes(self,data: List[Dict[str, Any]],artefact: str) -> Dict[str, List[Dict[str, str]]]:

        # Usamos defaultdict(list) para agrupar fácilmente los atributos por caso de uso.
        resultado_agrupado = defaultdict(list)

        # 1. Iterar sobre cada diccionario en la lista de datos de entrada.
        for item in data[artefact]:
            # Obtener el diccionario de propiedades interno de forma segura.
            item_attr = item[artefact]
            # 2. Extraer los datos necesarios.
            caso_de_uso = item_attr.get('Caso_de_uso')
            nombre = item_attr.get('Nombre')
            tipo_dato = item_attr.get('Tipo_Dato')            
            # Procesar solo si tenemos la información mínima requerida.
            if caso_de_uso and nombre and tipo_dato:
                # 3. Transformar al nuevo formato con claves 'NAME' y 'TYPE'.
                nuevo_atributo = {
                    'NAME': nombre,
                    'TYPE': tipo_dato
                }
                # 4. Agregar el nuevo atributo a la lista de su caso de uso.
                resultado_agrupado[caso_de_uso].append(nuevo_atributo)

        # 5. Ordenar las listas de atributos para cada caso de uso.
        resultado_final_ordenado = {}
        for caso, lista_atributos in resultado_agrupado.items():
            # Ordenamos la lista de diccionarios usando el valor de la clave 'NAME'.
            resultado_final_ordenado[caso] = sorted(lista_atributos, key=lambda x: x.get('NAME', ''))

        return resultado_final_ordenado

    def create_rules(self, data: List[Dict[str, Any]], artefact: list) -> Dict[str, List[Dict[str, str]]]:
        """
        it finds comma-separated rule strings, splits them into individual rules, and groups them into a
        list under their corresponding use case name.

        Args:
            data (List[Dict[str, Any]]): The input data structure, expected to be a
                dictionary where keys are artefact types.
            artefact (list): A list of artefact keys (e.g., 'func_null', 'func_domain')
                to be processed.
        Returns:
            Dict[str, List[Dict[str, str]]]: A dictionary where each key is a use
                case name and the value is a consolidated list of all its
                associated rule strings.
        """
        # Group rules
        reglas_por_caso_de_uso = defaultdict(list)

        # 1. Iterate over each dictionary in the input data list.
        for item_tipo in data:
            if item_tipo in artefact:
                for item in data[item_tipo]:
                    structure_dict = item.get(item_tipo, {})
                    for caso_de_uso, reglas_string in structure_dict.items():
                        # Split the comma-separated string into individual rules
                        reglas_individuales = [
                            regla.strip() 
                            for regla in reglas_string.split(',') 
                            if regla.strip()  # Ensures empty strings are not added
                        ]

                        # 7. Consolidate: add the list of rules to the corresponding use case.
                        reglas_por_caso_de_uso[caso_de_uso].extend(reglas_individuales)

        return dict(reglas_por_caso_de_uso)
    