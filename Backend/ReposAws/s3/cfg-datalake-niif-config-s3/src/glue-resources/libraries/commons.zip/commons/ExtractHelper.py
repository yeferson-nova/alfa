"""
Create common libreries to use in glue.
"""
import boto3
from awsglue import DynamicFrame
from datetime import datetime
from .LogsHelper import LogsHelper
import pandas as pd
from pyspark.sql.functions import col, concat, lit, date_format, to_date
from pyspark.sql.types import TimestampType
class ExtractHelper():
    def __init__(self, glue_context, spark, *args):
        """
        Initialice Extract Class.
        """
        self._glue_context = glue_context
        self._spark = spark
        self.DB_SCHEMA, self.BUCKET_NAME, self.DB_NAME = args
        self.obtain_date()
        self.logger = LogsHelper().logger_conf()
        
    def obtain_date(self)->None:
        """
        Funtion to obtain current date
        """
        self.current_date = datetime.now()
        self.day = self.current_date.day
        self.month = self.current_date.month
        self.year = self.current_date.year 

    def get_column_partition(self, input_dataframe, partition):
        """
        Adds a partition column to a DataFrame based on the data type of the partition column.

        Args:
            input_dataframe (DataFrame): The input DataFrame containing the data.
            partition (str): The name of the column to be used for creating the partition column.

        Returns:
            DataFrame: The input DataFrame with a new partition column added.
        """
        if isinstance(input_dataframe.schema[partition].dataType, TimestampType):
        # Case when partition is timestamp
            df_with_partition = input_dataframe.withColumn(f"{partition}_partition", date_format(col(partition), "yyyy-MM"))
        else:
            # Case when partitio isn't timestamp 
            df_with_partition = input_dataframe.withColumn(f"{partition}_partition", date_format(to_date(concat(col(partition).cast("string"), lit("01")), 'yyyyMMdd'), 'yyyy-MM'))

        return df_with_partition
    
    def delete_s3_folder(self, bucket_name, prefix):
        """
        Deletes all objects within a specified folder in an S3 bucket.

        Args:
            bucket_name (str): The name of the S3 bucket.
            prefix (str): The prefix (folder path) of the objects to delete.

        Returns:
            bool: Returns True if the deletion was initiated successfully.
        """

        s3 = boto3.resource('s3')     
        bucket = s3.Bucket(bucket_name)     
        bucket.objects.filter(Prefix=prefix).delete()    

        return True

    def save_files_s3(self, frame_save, s3_path, partition):
        """
        This function save df in parquet files.

        arg:
            df: Dataframe to save in parquet files.
            tb_name: Name of table to save (save in path s3)
            path: path to save files.
            partition: partition of table
        retunr:
            response: response of the execution
        """
        amazon_s3 = self._glue_context.write_dynamic_frame.from_options(
            frame=frame_save, 
            connection_type="s3", 
            format="glueparquet", 
            connection_options={"path": s3_path, "partitionKeys": partition}, 
            format_options={"compression": "snappy"}, 
            transformation_ctx="AmazonS3")                          

        return amazon_s3



    def execute_data(self, table_name, partition:str = "-", sql_script:str = "-", connectname:str = "-") -> str:
        """
        Function that allows extracting data from an Oracle DB.

        Args:
            table_name (str): Name of the table to extract.            
            partition (str): Column name to be used for partitioning. Defaults to "-".
            sql_script (str): SQL script for data extraction, required if any logical transformation is needed. Defaults to "-".
            connectname (str): Name of the connection. Defaults to "-".

        Returns:
            str: A message indicating the response of the operation.
        """
        self._spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
        self._spark._jsc.hadoopConfiguration().set("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false")

        # Define the connection options
        connect_option = {
            "useConnectionProperties": "true",
            "dbtable": f"{self.DB_SCHEMA}.{table_name}",
            "connectionName": connectname
        }

        # Add sampleQuery if sql_script is not "-"
        if sql_script != "-":
            connect_option["sampleQuery"] = sql_script

        # Log the beginning of extraction
        self.logger.info(f"start to extract info {table_name}")

        # Log the connection options
        self.logger.info(connect_option)


        try:
            
            tabla_to_extract = self._glue_context.create_dynamic_frame.from_options(
            connection_type = "oracle",
            connection_options = connect_option,
                transformation_ctx = "TablaExtract"
            )                        

            if partition == '-':          
                frame_save =  tabla_to_extract     
                self.logger.info(f"Without partition")
                partition_keys = []

            else: 
                self.logger.info(f"Col partition: {partition}")
                tabla_to_df = tabla_to_extract.toDF()                    
                frame_save = self.get_column_partition(tabla_to_df, partition)                        
                frame_save = DynamicFrame.fromDF(frame_save, self._glue_context, "frame_save_dynamic")       
                partition_keys = [f"{partition}_partition"]         
            
            s3_prefix = f"{self.DB_NAME}/{self.DB_SCHEMA}/{table_name}/"
            
            s3_path = f"s3://{self.BUCKET_NAME}/{s3_prefix}"

            self.delete_s3_folder(self.BUCKET_NAME, s3_prefix)        

            self.save_files_s3(frame_save, s3_path, partition_keys)
            
            self.logger.info(f"File saved in : {s3_path}" )

        except Exception as e:

            self.logger.error(f"Se ha producido un error: {e}")        
                        
