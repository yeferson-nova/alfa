import logging

class LogsHelper:

    def logger_conf(self):

        """
        Configures and returns a logger object for managing log messages.

        - Defines the log message format (MSG_FORMAT), which includes:
        * The timestamp of the log (%(asctime)s).
        * The severity level of the log message (%(levelname)s).
        * The name associated with the logger (%(name)s).
        * The actual log message (%(message)s).
        - Specifies the date and time format (DATETIME_FORMAT) for the logs as 'YYYY-MM-DD HH:MM:SS'.
        - Sets up the logger with the name 'log message' and assigns the log level to INFO.

        Returns:
            logger (logging.Logger): Configured logger object for logging messages.
        """

        MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
        DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'

        logger = logging.getLogger('log message')
        logger.setLevel(logging.INFO)

        logger.handlers.clear()

        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(MSG_FORMAT, DATETIME_FORMAT))
        logger.addHandler(handler)

        return logger
